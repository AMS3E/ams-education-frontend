<?php

/* Template Name: Latest News */


?>

<?php get_header(); ?>


<?php

?>
<div class="col-lg-12 panel-latest-news">
    <div class="d-flex justify-content-between">
        <h2 class="section-title">ព្រឹត្តិការណ៍ប្រចាំថ្ងៃ</h2>
        <a class="btnTodayNews txtSectionNews" href="javascript:void(0);"style="font-weight:bold;">ថ្ងៃនេះ</a>
        <a class="btnYesterdayNews txtSectionNews" href="javascript:void(0);">ម្សិលមិញ</a>
        <a class="btnBeforeYesterday txtSectionNews" href="javascript:void(0);">ម្សិលម្ងៃ</a>
    </div>
    <div class="today-news">
    <?php
        $episodes = array(
            'post_type' => 'post',
            'post_status' => 'publish',
            'order' => 'DESC',
            'posts_per_page' => 5,
            // 'date_query' => array(
            //     array(
            //     'before' => '1 days ago',
            //       )
            //   )
        );
        
        $loop = new WP_Query($episodes);
        
        if($loop->have_posts()) :
            while($loop->have_posts()) : $loop->the_post();
                ?>
                    <div class="container-latest-news">
                        <a class="latest-news" href="<?= the_permalink();?>">
                            <?php the_post_thumbnail(); ?>
                            <p><?php the_title(); ?></p>
                                <p class="category"><?php echo get_the_category_list(', '); ?></p>
                                <!--<p class="date"><?php echo get_the_date(); ?></p>-->
                        </a>
                    </div>
                <?php
            endwhile;
        endif;
        
        wp_reset_query();
    ?>
    

    
    </div>
    
    
    <div class="yesterday-news" style="display:none;">
        <?php
        $episodes = array(
            'post_type' => 'post',
            'post_status' => 'publish',
            'order' => 'DESC',
            'posts_per_page' => 5,
            'date_query' => array(
                array(
                'before' => '1 days ago',
                  )
              )
        );
        
        $loop = new WP_Query($episodes);
        
        if($loop->have_posts()) :
            while($loop->have_posts()) : $loop->the_post();
                ?>
                    <div class="container-latest-news">
                        <a class="latest-news" href="<?= the_permalink();?>">
                            <?php the_post_thumbnail(); ?>
                            <p><?php the_title(); ?></p>
                                <p class="category"><?php echo get_the_category_list(', '); ?></p>
                                <!--<p class="date"><?php echo get_the_date(); ?></p>-->
                            
                        </a>
                    </div>
                <?php
            endwhile;
        endif;
        
        wp_reset_query();
    ?>
    </div>
    
    

    
    <div class="before-yesterday-news" style="display:none;">
        <?php
        $episodes = array(
            'post_type' => 'post',
            'post_status' => 'publish',
            'order' => 'DESC',
            'posts_per_page' => 5,
            'date_query' => array(
                array(
                'before' => '2 days ago',
                  )
              )
        );
        
        $loop = new WP_Query($episodes);
        
        if($loop->have_posts()) :
            while($loop->have_posts()) : $loop->the_post();
                ?>
                    <div class="container-latest-news">
                        <a class="latest-news" href="<?= the_permalink();?>">
                            <?php the_post_thumbnail(); ?>
                            <p><?php the_title(); ?></p>
                                <p class="category"><?php echo get_the_category_list(', '); ?></p>
                                <!--<p class="date"><?php echo get_the_date(); ?></p>-->
                            
                        </a>
                    </div>
                <?php
            endwhile;
        endif;
        
        wp_reset_query();
        
        
    ?>
    
    
    </div>
    
    <script>
        jQuery(document).ready(function($){
            $('.btnTodayNews').on('click', function(){
                $('.txtSectionNews').css('font-weight', 'normal', 'color', 'black');
                $(this).css('font-weight', 'bold', 'color', 'blue');
                $('.today-news').css('display', 'block'); 
                $('.before-yesterday-news').css('display', 'none'); 
                $('.yesterday-news').css('display', 'none');
            });
            
            $('.btnYesterdayNews').on('click', function(){
                $('.txtSectionNews').css('font-weight', 'normal', 'color', 'black');
                $(this).css('font-weight', 'bold', 'color', 'blue');
                $('.yesterday-news').css('display', 'block');
                $('.today-news').css('display', 'none'); 
                $('.before-yesterday-news').css('display', 'none'); 
              
            });
            
            $('.btnBeforeYesterday').on('click', function(){
                $('.txtSectionNews').css('font-weight', 'normal', 'color', 'black');
                $(this).css('font-weight', 'bold', 'color', 'blue');
                $('.before-yesterday-news').css('display', 'block');
                $('.yesterday-news').css('display', 'none');
                $('.today-news').css('display', 'none'); 
                
            });
        });
    </script>
</div>
<?php


echo do_shortcode('[ams-top]');

get_footer( 'episode' );



?>

