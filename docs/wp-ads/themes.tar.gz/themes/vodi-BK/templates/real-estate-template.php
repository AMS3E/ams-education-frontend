<?php

/*
* Template Name: អចលនទ្រព្យ-Article Block
* Template Post Type: post
*/


get_header();

    do_action( 'vodi_before_main_content' ); ?>

    <div id="primary" class="content-area">
        <main id="main" class="site-main" role="main">
        
        <?php while ( have_posts() ) : the_post();

            do_action( 'vodi_single_post_before' );

        ?>
        <article id="post-<?php the_ID(); ?>" <?php post_class( 'single-article' ); ?>>

        <?php
        do_action( 'vodi_single_post_top' );
    
        /**
         * Functions hooked into vodi_single_post add_action
         *
         * @hooked vodi_post_header          - 10
         * @hooked vodi_post_content         - 30
         */
        do_action( 'vodi_single_post' );
    
        /**
         * Functions hooked in to vodi_single_post_bottom action
         *
         * @hooked vodi_post_nav         - 10
         * @hooked vodi_display_comments - 20
         */
         
         echo do_shortcode("[reblex id='24267']");
         
         
        do_action( 'vodi_single_post_bottom' );
        ?>
    
    </article><!-- #post-## -->
    
<?php
            
            do_action( 'vodi_single_post_after' );
            
        endwhile; // End of the loop. ?>
        
        </main><!-- #main -->
        
        
    </div><!-- #primary --><?php
    
    do_action( 'vodi_after_main_content' );
    
get_footer();