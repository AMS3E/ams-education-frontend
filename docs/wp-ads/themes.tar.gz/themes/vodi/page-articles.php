<?php

/* Template Name: Hot Topic */

?>

<?php get_header(); ?>


<?php

$page = (get_query_var('paged')) ? absint(get_query_var('paged')) : 1;
$args = array(
    'post_type' => 'episode',
    'post_status' => 'publish',
    'order' => 'DESC',
    'posts_per_page' => 1,
    'paged' => $page,
    'meta_query' => array(
        'relation' => 'AND',
		array(
			'key' => '_tv_show_id',
			'value' => 76126
		)
	)
);

$loop = new WP_Query($args);

if($loop->have_posts()) :
    while($loop->have_posts()) : $loop->the_post();
    
        ?>
            <div class="col-lg-12">
                <p><a href="https://economy.ams.com.kh">ទំព័រដើម</a>  ><a href="https://economy.ams.com.kh/hot-topic">Hot Topic</a> > <span><?php the_title(); ?></span> </p>
                
                <div class="post-content" style="flex-direction:flex;justify-content:center;">
                        
                        <p><?php $meta = get_post_meta(get_the_ID(), '_episode_url_link', true); 
                        
                            $getIdVimeo = substr($meta,18);
                               
                            ?>
                            
                        
                        </p>
                        
                        
                        
                        <div class="row">
                            <div class="col-md-2">
                                <?php
                                previous_posts_link( __( '<div class="episode__player--prev-episode"><span class="row episode__player--prev-episode__label">
វីដេអូមុន</span><a style="display:none;"></a></div>', 'textdomain' ) );
                                ?>

                                
                                
                            </div>
                            <div class="col-md-8">
                                <iframe title="<?php the_title(); ?>" src="https://player.vimeo.com/video/<?= $getIdVimeo; ?>" width="990" height="557" frameborder="0" allow="autoplay; fullscreen; picture-in-picture" allowfullscreen>
                                </iframe>                                
                            </div>
                            <div class="col-md-2">
                                <?php                             	next_posts_link( __( '<div class="episode__player--next-episode"><span class="row episode__player--next-episode__label">
វីដេអូបន្ទាប់</span><a style="display:none;"></a></div>', 'textdomain' ), $loop->max_num_pages );
                                ?>
                            </div>
                        </div>
                    
                        

                        
                </div>
                <p><?php the_title(); ?></p>
                <!--<p><?php the_excerpt(); ?></p>-->
                <p>ផ្សព្វផ្សាយថ្ងៃទី <?php echo get_the_date(); ?></p>
                <h4>ការពិព័ណ៌នា</h4>
                <div class="col-md-12">
                     <p>កម្មវិធី "ព័ត៌មានទាន់ហេតុការណ៍-Hot Topics" បង្ហាញព្រឹត្តិការណ៍ព័ត៌មានថ្មីៗទាន់សភាពការណ៍ ដោយមានអ្នកវិភាគ និងប្រភពព័ត៌មាន ប្រកបដោយចំណេះដឹង ច្បាស់លាស់ និងគ្រប់ជ្រុងជ្រោយ។</p>               
                </div>

            </div>
        <?php
    endwhile;
endif;

wp_reset_query();




?>
<div class="col-lg-12 resable-block row">
    
    <?php echo do_shortcode("[reblex id='75020']"); ?>
    

</div>
<?php



get_footer( 'episode' );



?>

