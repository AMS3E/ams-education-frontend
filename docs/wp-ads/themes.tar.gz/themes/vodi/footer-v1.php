<?php
/**
 * The template for displaying the footer v1.
 *
 * Contains the closing of the #content div and all content after
 *
 * @package vodi
 */

?>
            </div><!-- /.site-content-inner -->

        <?php do_action( 'vodi_content_bottom' ); ?>
        
    </div><!-- #content -->

    <?php do_action( 'vodi_before_footer' ); ?>

    <footer id="colophon" class="site-footer site__footer--v1 desktop-footer <?php echo esc_attr( apply_filters( 'vodi_footer_theme', 'dark' ) ); ?>" role="contentinfo">

            <?php
            /**
             * Functions hooked in to vodi_footer_v1 action
             *
             * @hooked vodi_container_start          - 10
             * @hooked vodi_footer_top_bar_open      - 20
             * @hooked vodi_footer_logo              - 30
             * @hooked vodi_footer_top_bar_social    - 40
             * @hooked vodi_footer_top_bar_close     - 50
             * @hooked vodi_footer_widgets           - 60
             * @hooked vodi_container_end            - 70
             * @hooked vodi_footer_bottom_bar_open   - 80
             * @hooked vodi_footer_credit            - 90
             * @hooked vodi_footer_quick_links       - 100
             * @hooked vodi_footer_bottom_bar_close  - 110
             */
            do_action( 'vodi_footer_v1' );
            ?>
            
    </footer><!-- #colophon -->

    <?php do_action( 'vodi_after_footer' ); ?>

</div><!-- #page -->

<!--<div class="img-logo">-->
<!--    <a href="https://economy.ams.com.kh/inclusive-business/">-->
<!--        <img id="img-logo-100k" style="width: 120px; height: 120px !important;" src="https://economy.ams.com.kh/wp-content/uploads/2024/02/ធុរកិច្ចបរិយាបន្ន​_២០២៤_Inclusive_Business_icon_150x150.svg">-->
<!--    </a>-->
<!--</div>-->



<!--START::Form-Profile Setting-->
    <div id="modal-profile-settings" class="modal" aria-hidden="true">

  <!-- Modal content -->
  <div class="modal-content" style="width:40%;height:520px;">
    <div class="modal-body">
    <div style="float:right;cursor:pointer;"><span class="close_modal">×</span></div>
    <h5>Account Setting</h5>
        <div class="section-account-setting">
            <div class="menu-section" style="width:35%">
               <div class="profile-pic">
                   <div class="img-pro" id="img-pro"><?php echo $current_user['profile_image']; ?></div>
               </div>
                <ul id="menu-account-setting">
                    <li><a id="btn-account" class="acc-setting" href="javascript:void(0);"><img src="https://infotainment.ams.com.kh/wp-content/uploads/2023/06/account.png"></img>Account</a></li>
                    <li><a id="btn-security" class="acc-setting" href="javascript:void(0);"><img src="https://infotainment.ams.com.kh/wp-content/uploads/2023/06/security.png"></img>Security</a></li>
                    <li><a id="btn-fav" class="acc-setting" href="javascript:void(0);"><img src="https://infotainment.ams.com.kh/wp-content/uploads/2023/06/favourite.png"></img>Favourite Content</a></li>
                    
                </ul>
            </div>
            
            <div class="panel-section">
                <div class="section-account">
                    <h1 class="title-account">
                        Account Information
                    </h1>
                    <div class="status-bar" style="display:none;margin-bottom:10px;"></div>
                    <form id="form-account-setting">
                        <div class="row-section">
                            <div class="username">
                                <label>First Name</label>
                                <input type="text" name="fname" value="<?php echo $current_user['first_name']; ?>" class="fname" id="fname">
                            </div>
                            <div class="lname">
                                <label>Last Name</label>
                                <input type="text" name="lname" value="<?php echo $current_user['last_name']; ?>" class="lname" id="lname">
                            </div>
                        </div>
                        
                        <div class="row-section">
                            <div class="gender">
                                <label>Gender</label>
                                <select class="gender" name="gender" id="gender">
                                    <option value="male" <?php if ($current_user['gender'] === 'male') echo 'selected'; ?>>Male</option>
                                    <option value="female" <?php if ($current_user['gender'] === 'female') echo 'selected'; ?>>Female</option>
                                </select>
                            </div>
                            <div class="dob">
                                <label>Date of Birth</label>
                                <input type="date" name="dob" value="<?php echo $current_user['dob']; ?>" class="dob" id="dob">
                            </div>
                        </div>
                        
                        <div class="row-section">
                            <div class="email">
                                <label>Email</label>
                                <input type="text" name="email" value="<?php echo $current_user['email']; ?>" class="email" id="edit_email" > <br>
                                <div class="vify-otp-field" style="display:none;">
                                    <input type="text" id="verify_otp" style="padding:5px 10px 5px 10px;width:100px;">
                                    <button style="width:100px;margin-left:10px;height:38px;" id="btn-verify-otp">Verify</button>
                                    <span style="margin-left:10px;margin-top:10px;" id="countdown">60 វិនាទី</span>
                                </div>
                            </div>
                            <div class="phone_number">
                                <label>Phone Number</label>
                                <input type="text" name="phone_number" value="<?php echo $current_user['phone_number']; ?>" class="phone_number" id="phone_number" >
                            </div>
                        </div>
                        
                        <div class="subscribe-email">
                            <label class="toggle">
                                <input type="checkbox" id="subscribe-email">
                                <span class="slider"></span>
                                
                              </label>
                              <span id="alow-email">Allow send email</span>
                        </div>
                        
                        
                        <div class="row-section-edit">
                            <button type="submit" id="btn_edit_acc">Edit</button>
                        </div>
                    </form>
                </div> 
                
                <div class="section-security" style="display:none;">
                    <h1 class="title-account">
                        Security
                    </h1>
                    <div class="status-bar" style="display:none;margin-bottom:10px;"></div>
                    <form id="form-acc-security">
                        <div class="row-section">
                            <div class="password">
                                <label>Current Password</label>
                                <input type="text" name="c_password" class="c_password" id="c_password">
                            </div>
                            <div class="lname">
                                <label>New Password</label>
                                <input type="text" name="n_password" class="n_password" id="n_password" >
                            </div>
                        </div>
                        
                        <div class="row-section-edit">
                            <input type="submit" id="btn_edit_acc" value="Change Password" >
                        </div>
                    </form>
                </div>
                
                <div class="section-fav" style="display:none;">
                    <h1 class="title-account">
                        Favourite Content
                    </h1>
                    <div class="status-bar" style="display:none;margin-bottom:10px;"></div>
                    <form id="form-acc-favourite">
                        <div class="row-section">
                            <div class="fav-author">
                                <label>Select Your Favourite Author</label>
                                <select name="acc_author" id="acc_author" class="acc_author" style="width:100%;" multiple>
                                   
                                </select>
                            </div>
                            <div class="keyword">
                                <label>Select by special keyword</label>
                                <input type="keyword" name="keyword" class="keyword" id="keyword_fav" data-role="tagsinput">
                            </div>
                        </div>
                        
                        <div class="row-section-edit">
                            <input type="submit" id="btn_edit_fav" value="Edit">
                        </div>
                    </form>
                </div>
                
                
            </div>
            
        </div>
  </div>
  </div>
    
</div>
<!--END::Form Prfile Setting-->

<!--START::Login Account-->
    <div id="modal-login-account" class="modal" aria-hidden="true">

  <!-- Modal content -->
  <div class="modal-content" style="width:25%;padding-bottom:30px;background-image: url(https://economy.ams.com.kh/wp-content/uploads/2021/12/ECO_BACKGROUND.jpg);">
    <div class="modal-body">
    <div style="float:right;cursor:pointer;"><span class="close_modal">×</span></div>
        <form id="form-account-login" method="post">
            <div class="login-title" style="text-align:center;margin-top:20px;">
                <h3 style="font-size:22px;color:lightgray;">ចូលគណនី</h3>
            </div>
            <div class="form-group" style="margin-bottom:10px;margin-top:30px;">
                <label for="uname_login" style="color:lightgray;font-size:14px;">អ៊ីមែល ឬឈ្មោះគណនី <span style="color:red;"> *</span></label>
                <input type="text" id="uname_login" name="uname_login" class="form-control" required style="color:white;">
            </div>
            <div class="form-group" style="margin-bottom:10px;">
                <label for="upass" style="color:lightgray;font-size:14px;">លេខសំងាត់ <span style="color:red;"> *</span></label>
                <input type="password" id="upass" name="upass" class="form-control" required style="background-color: transparent;color:white;">
            </div>
            <div class="form-group" style="margin-bottom:10px;display:flex;justify-content:center;align-items:center;">
                <input type="submit" style="width:100%;margin-top:10px;background:white;color:black;border:none;font-family:Battambang;" id="input-login-account" value="ចូលគណនី" class="btn btn-primary">
            </div>
            
            <p style="margin-top:40px;margin-bottom:30px;text-align:center;display:flex;justify-content:center;align-self:center;color:lightgray;">
                ឬចូលតាមរយៈគណនី
            </p>
            
            <?php echo do_shortcode('[nextend_social_login]'); ?>
          
            
            
        </form>  
  </div>
  </div>
    
</div>
<!--END::Login Account-->

<!--START::Author Modal Container-->
<div id="modal-ams-profile" class="modal" aria-hidden="true">


  <div class="modal-content" id="m-content">
    <div class="modal-body">
        <div style="float:right;cursor:pointer;"><span class="close_modal">×</span></div>
  
        <div id="modal-container-author">
            <div id="author_img"></div>
            <div id="author_desc"></div>
        </div>
  
        
    </div>
  </div>
    
</div>
<!--END::Author Modal Container-->

<?php
    $user_ip = getUserIP();
    ?>
        <input type="hidden" id="text_ip_user" value="<?php echo $user_ip; ?>">
    <?php
?>


<?php wp_footer(); ?>




</body>

</html>