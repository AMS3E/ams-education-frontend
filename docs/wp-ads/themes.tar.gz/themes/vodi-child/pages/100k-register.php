<?php

/* Template Name: 100K Register Form */

?>

<?php get_header(); ?>

<?php

    ?>
    
    <div class="col-lg-12" id="panel-100k-register">
        
        
        
        <section class="register-form" style="max-width:900px;">
            
            <div class="header">
                <div class="row">
                    <div class="left-side">
                        <img src="https://economy.ams.com.kh/wp-content/uploads/2024/02/T01.png" alt="">
                    </div>
                    
                    <div class="right-side">
                        <img src="https://economy.ams.com.kh/wp-content/uploads/2024/02/022-2.png" class="logo-100k">
                    </div>
                    
                </div>
            </div>
            
            <div class="register-message" style="color:white;padding:8px 15px 8px 18px; margin-top:15px;display:none;">
                <p style="font-family:Kantumruy;text-align:center;font-size:13px;">សូមអរគុណសម្រាប់ការចំណាយពេលវេលារបស់លោកអ្នក។ យើងខ្ញុំបានផ្ញើប័ណ្ណទឹកប្រាក់ 100 ដុល្លារចំពោះសេវាកម្ម AMS។ សូមពិនិត្យទៅលើប្រអប់អ៊ីមែលរបស់លោកអ្នក។</p>
                <p style="text-align:center;font-size:13px;">We thank you for taking the time to fill out our form. We have just sent you a $100 voucher via email. Please check your inbox to take advantage of your offer.</p>
                <div class="panel-action">
                    <a class="btnBackEnterpriceBussiness" href='https://economy.ams.com.kh/inclusive-business'>Inclusive Business</a>
                </div>
            </div>
            
            <div class="message-error" style="color:white;padding:8px 15px 8px 18px; margin-top:15px;display:none;"></div>
            
            
            <div class="section-content">
                <form id="frmRegister">
                    <div class="panel-entries">
                        <div class="row">
                            <div class="col-gender">
                                <label for="gender">Gender</label>
                                <select id="gender" class="gender" required>
                                    <option value="Mr">Mr</option>
                                    <option value="Mrs">Mrs</option>
                                    <option value="Miss">Miss</option>
                                    <option value="Ms">Ms</option>
                                </select>
                            </div>
                            <div class="col-fname">
                                <label for="first-name">First Name</label>
                                <input type="text" class="first-name" id="first-name" placeholder="Insert Here" required>
                            </div>
                            <div class="col-lname">
                                <label for="last-name">Last Name</label>
                                <input type="text" class="last-name" id="last-name" placeholder="Insert Here" required>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-email">
                                <label for="email">Email</label>
                                <input type="email" class="email" id="email" placeholder="Insert Here" required>
                            </div>
                            <div class="col-phone-number">
                                <label for="phone-number">Phone Number</label>
                                <input type="tel" class="phone-number" id="phone-number" pattern="[0-9]{3}-[0-9]{2}-[0-9]{3}" placeholder="85512345678" required>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-company">
                                <label for="company">Company</label>
                                <input type="text" class="company" id="company" placeholder="Insert Here" required>
                            </div>
                            
                            <div class="col-submit">
                                <label></label>
                                <button class="btn-submit">
                                Submit 
<svg xmlns="http://www.w3.org/2000/svg" width="50" height="50" fill="currentColor" class="bi bi-arrow-right-short" viewBox="0 0 16 16" id="IconChangeColor"> <path fill-rule="evenodd" d="M4 8a.5.5 0 0 1 .5-.5h5.793L8.146 5.354a.5.5 0 1 1 .708-.708l3 3a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708-.708L10.293 8.5H4.5A.5.5 0 0 1 4 8z" id="mainIconPathAttribute" fill="#ffffff" stroke-width="0" stroke="#ff0000"></path> </svg>

                            </button>
                            </div>

                            
                        </div>
                        
                        
                    </div>
                </form>
            </div>
            
            <div class="footer">
                <a href="https://economy.ams.com.kh/privacy-policy" class="policy">Privacy Policy</a>
                <p class="copy-right">@Copyright-2024 AMS</p>
            </div>
            
        </section>
    
    
    </div>
    
    

    
    
    <script>
        jQuery(document).ready(function($){
            
            function clear_form() {
                $("#gender").val('');
                $("#first-name").val('');
                $("#last-name").val('');
                $("#company").val('');
                $("#email").val('');
                $("#phone-number").val('');
            }
            
            $('.btn-submit').on("click", function(e){
                e.preventDefault();
                
                let formData = {
                    'gender': $("#gender").val(),
                    'fname': $("#first-name").val(),
                    'lname': $("#last-name").val(),
                    'company_name': $("#company").val(),
                    'email': $("#email").val(),
                    'phone_number': $("#phone-number").val()
                }
                
                $.ajax({
                  url: "/wp-json/api/v1/save-100k-user",
                  type: "POST",
                  data: formData,
                  success: function(res) {
                    if(res.status == "OK"){
                        clear_form();
                        $(".message-error").css({"display": "none"});
                        $(".register-message").css({"display": "block"});
                        $("#frmRegister").css({"display": "none"});
                    }
                  },
                  error: function(xhr, status, error) {
                    let res = JSON.parse(xhr.responseText);
                        $(".register-message").css({"display": "none"});
                        $("#frmRegister").css({"display": "block"});
                        $(".message-error").html(res.message).css({
                            "display": "block",
                            "background-color": "#dc3545"
                        });
                  }
                });
            
            });

        });
    </script>    
     
    
    <?php


?>


<?php get_footer(); ?>

