<?php
/*
Template Name: AMS Socal Link
*/





?>

<script>
window.onload = function() {
  window.location.href = 'https://ams-economy.ig.pulse.is/';
}
</script>


<?php

