<?php

/* Template Name: Dashboard */

?>



<?php get_header(); ?>

<?php

if (is_user_logged_in()){
    
    $c_user = get_current_user_details();

    
    ?>
    
        <div class="container-fluid section-reports-news">
            <div class="section-username">
                <div>Good morning, </div><br>
                <div class="uname">
                    <div id="username"><?php echo $c_user['display_name']; ?></div>
                    
                    <div class="fav-panel">
                        <div class="highest-view-vdo">
                            <a href="javascript:void(0);">
                                <img src="https://infotainment.ams.com.kh/wp-content/uploads/2023/06/favorite-svgrepo-com.svg"></img>
                                វីដេអូមើលច្រើនជាងគេ
                            </a>
                        </div>
                        
                        <div class="watch-latter">
                            <a href="javascript:void(0);">
                                <img src="https://infotainment.ams.com.kh/wp-content/uploads/2023/06/time-past-svgrepo-com.svg"></img>
                               ទស្សនានៅពេលក្រោយ
                            </a>
                        </div>
                        
                    </div>
                </div>
                
            </div>
            <div class="title-dashboard">
                <!--<div class="title-head">-->
                <!--    <h5 class="text-overview">Filter by menu</h5>-->
                <!--</div>  -->
                
                <div class="row-filter">
                    
                    <div class="d-block">
                        <label for="filter-category">ស្វែងរកតាមរយៈមាតិកា</label>
                        <select name="filter-category" id="filter-category">
                            <option value="1">តារាល្បីៗ</option>
                            <option value="2">ភាពយន្តនិងតន្រ្តី</option>
                            <option value="3">ស្តូឌីយ៉ូ ១១</option>
                            <option value="3">ចង់ដឹងរឿងគេ</option>
                            <option value="3">ព័ត៌មានកម្សាន្តប្លែកៗ</option>
                            <option value="3">អាហារនិងដើរលេង</option>
                            <option value="3">ស្នេហានិងទំនាក់ទំនង</option>
                            <option value="3">DIY</option>
                            <option value="3">សុខភាពនិងសម្រស់</option>
                            <option value="3">បែបផែនជីវិត</option>
                        </select>
                    </div>
                    
                    <span style="width:30px;"></span>
                    
                    <div class="d-block">
                        <label for="filter-author">ស្វែងរកតាមរយៈអ្នកនិពន្ធ</label>
                        <select name="filter-author" id="filter-author" >
                        </select>
                    </div>
                    
                    <span style="width:30px;"></span>
                    
                    <div class="input-group m-5">
                        <div class="d-block">
                            <label for="filter-search">ស្វែងរកតាមរយៈពាក្យពិសេស ឬ Keyword</label>
                            <input type="text" name="filter-search" id="filter-search" class="form-control" data-role="tagsinput">
                        </div>
                    </div>
                    
                    <span style="width:30px;"></span>
                    
                    <div class="d-block">
                        <label for="filter-tv-program">កំណត់ការស្វែងរក</label>
                        <select name="filter-tv-program" id="filter-tv-program" >
                            <option value=""></option>
                            <option value="post">ព័ត៌មាន</option>
                            <option value="episode">កម្មវិធីពិសេស</option>
                            <option value="video">វីដេអូ</option>
                        </select>
                    </div>
                    
                    <span style="width:30px;"></span>
                    <div class="d-block">
                        <label></label>
                        <button id="clear-search-filter" style="background:none;"><img src="https://infotainment.ams.com.kh/wp-content/uploads/2023/06/close.png" class="img-close"></img></button>
                    </div>
                    

                    
                </div>
                
            </div>
        </div>

        
        <div id="search-section">
            <!--<div class="spinner">-->
            <!--    <span class="ball-1"></span>-->
            <!--    <span class="ball-2"></span>-->
            <!--    <span class="ball-3"></span>-->
            <!--    <span class="ball-4"></span>-->
            <!--    <span class="ball-5"></span>-->
            <!--    <span class="ball-6"></span>-->
            <!--    <span class="ball-7"></span>-->
            <!--    <span class="ball-8"></span>-->
            <!--</div>-->
        </div>
        
        <div class="container-fluid section-reports-news" id="top-section-dashboard">
            <div class="section-reports-news">
                <section class="report-news">
                    <div class="col-lg-12 panel-report-news">
                        <div class="d-flex justify-content-between" style="padding-top:50px;">
                            <h2 class="section-title">
                                ព័ត៌មានថ្មីៗ
                            </h2>
                            <a class="btnTodayNews txtSectionNews" href="<?php echo $atts['href']; ?>"style="font-weight:bold;">មើលទាំងអស់ ➧</a>
                        </div>
                       
                        <div class="popular-news">
                
                        <?php
                    
                            $user_id = get_current_user_id();
                            $fav_author = get_user_meta($user_id, 'fav_author', true);
                            $fav_keyword = get_user_meta($user_id, 'fav_keyword', true);
                            $author_ids = array_map('intval', $fav_author);
                            
                            if($fav_keyword){
                                $keywords = explode(',', $fav_keyword);
                                $options = array(
                                    'post_type'      => 'post',
                                    'post_status'    => 'publish',
                                    'orderby'        => 'ID',
                                    'order'          => 'DESC',
                                    'posts_per_page' => 8,
                                    'author__in'     => $author_ids,
                                    'tax_query'      => array(
                                        array(
                                            'taxonomy' => 'post_tag',
                                            'field'    => 'slug',
                                            'terms'    => $keywords,
                                            'operator' => 'IN',
                                        ),
                                    ),
                                );
                            }else{
                                $options = array(
                                    'post_type' => 'post',
                                    'post_status' => 'publish',
                                    //'category__in' => $category__in,
                                    'orderby'        => 'ID',
                                    'order'          => 'DESC',
                                    'posts_per_page' => 8,
                                    'author__in'     => $author_ids,
                                );
                            }
                            
                            
                            
                            $loop = new WP_Query( $options );
                                
                            if($loop->have_posts()) :
                                while($loop->have_posts()) : $loop->the_post();
                                    ?>
                                        <div class="container-report-news">
                                            <a class="report-news" href="<?= the_permalink();?>">
                                                <?php the_post_thumbnail(); ?>
                                                <div class="article">
                                                    <p><?php the_title(); ?></p>
                                                    <div class="row">
                                                        <p class="category"><?php echo get_the_category_list(', '); ?> 
                                                        </p>
                                                        <p class="date"> • <?php echo get_the_date(); ?></p> 
                                                    </div>
                                                    <p class="article-except"><?php echo get_the_excerpt(); ?></p>
                                                </div>
                                            </a>
                                        </div>
                                    <?php
                                endwhile;
                                
                                
                        		
                            endif;
                            
                            wp_reset_query();
                        ?>
                    
                    
                    </div>
                   
                </section>
            </div>
            
        </div>
        
        
        <div class="container-fluid section-dashboard">
            <h1 class="title-the-fact">Recent Released</h1>
            <div class="section-daily-feed">
                <?php echo do_shortcode('[greenbox-epi-single title="ប្រអប់បៃតង" href="https://infotainment.ams.com.kh/tv-show/green-box/" post_type="episode" post_status="publish" tv_show_num=14616 season=1]'); ?>
            </div>
            
        </div>
        
        <div class="container-fluid section-dashboard">
            <h1 class="title-dail-feed">Daily Feed</h1>
            <div class="container">
                <div class="section-daily-feed">
                    <?php echo do_shortcode('[epsode-carousel title="រដូវកាលទី ១" href="https://infotainment.ams.com.kh/tv-show/daily-feed" post_type="episode" post_status="publish" tv_show_num=84591 season=1]'); ?>
                </div>
            </div>
            
        </div>
        
        <div class="container-fluid section-dashboard">
            <h1 class="title-the-fact">The Fact</h1>
            <div class="section-daily-feed">
                <?php echo do_shortcode('[epsode-carousel-multiple title="រដូវកាលទី ១" href="https://infotainment.ams.com.kh/tv-show/the-fact/" post_type="episode" post_status="publish" tv_show_num=84589 season=1]'); ?>
            </div>
            
        </div>
      
    
        
       
        
        
        
    
    
    <?php

}

?>




<?php get_footer(); ?>

