<?php

/* Template Name: Author Page */

?>

<?php get_header(); ?>

<?php


?>

<div class="col-lg-12">

    <h1 class="title-page">ក្រុមការងារ APSARA MEDIA SERVICES (AMS)</h1>
    <section class="section-author">
        <div id="top-management"></div>
        
        
        <section id="episode-carousel-top-management">
    	
        	<div class="epi-header">
        		<h5 class="epi-title-header">
        		    គណៈគ្រប់គ្រង AMS
        		</h5>
        		<p class="epi-link-header"><a href="/">មើលទាំងអស់ ➧</a></p>
        	 </div>
        	  
        	  <div class="tabs">
        
        		  <div id="tabs-nav-carousel-top-management">
        			  
        			<div id="tabSingle" class="tab-content-carousel-top-management">
        				<div class="swiper-container">
        			
        					<div class="swiper-wrapper" id="top-management-carousel">
        	   
        						
        
        				    </div>  
        			
            				<div class="swiper-button-prev"><img src="https://infotainment.ams.com.kh/wp-content/uploads/2023/04/left-arrow-1.png"></div>
            				<div class="swiper-button-next"><img src="https://infotainment.ams.com.kh/wp-content/uploads/2023/04/arrow-right.png"></div>
        			    </div>
        			</div>
        		  
        		  </div>
        	</div>
        </section>


    </section>
    
    <section class="section-translator">
        <div id="top-author"></div>


        <section id="episode-carousel-top-management">
    	
        	<div class="epi-header">
        		<h5 class="epi-title-header">
        		    អំពីអ្នកនិពន្ធ AMS INFOTAINMENT
        		</h5>
        		<p class="epi-link-header"><a href="/">មើលទាំងអស់ ➧</a></p>
        	 </div>
        	  
        	  <div class="tabs">
        
        		  <div id="tabs-nav-carousel-top-management">
        			  
        			<div id="tabSingle" class="tab-content-carousel-top-management">
        				<div class="swiper-container">
        			
        					<div class="swiper-wrapper" id="author-episode-carousel">
        	   
        				    </div>  
        			
            				<div class="swiper-button-prev"><img src="https://infotainment.ams.com.kh/wp-content/uploads/2023/04/left-arrow-1.png"></div>
            				<div class="swiper-button-next"><img src="https://infotainment.ams.com.kh/wp-content/uploads/2023/04/arrow-right.png"></div>
        			    </div>
        			</div>
        		  
        		  </div>
        	</div>
        </section>
        
    </section>    
    
    <section class="section-producer">
        <div id="top-producer"></div>

        <section id="episode-carousel-producer">
    	
        	<div class="epi-header">
        		<h5 class="epi-title-header">
        		    អំពីផលិតករ
        		</h5>
        		<p class="epi-link-header"><a href="/">មើលទាំងអស់ ➧</a></p>
        	 </div>
        	  
        	  <div class="tabs">
        
        		  <div id="tabs-nav-carousel-top-management">
        			  
        			<div id="tabSingle" class="tab-content-carousel-top-management">
        				<div class="swiper-container">
        			
        					<div class="swiper-wrapper" id="producer-episode-carousel">
        	   
        				    </div>  
        			
            				<div class="swiper-button-prev"><img src="https://infotainment.ams.com.kh/wp-content/uploads/2023/04/left-arrow-1.png"></div>
            				<div class="swiper-button-next"><img src="https://infotainment.ams.com.kh/wp-content/uploads/2023/04/arrow-right.png"></div>
        			    </div>
        			</div>
        		  
        		  </div>
        	</div>
        </section>
    </section> 
   
    
    
    
    <section class="section-digital">
        <div id="top-digital"></div>
        
        <section id="episode-carousel-producer">
    	
        	<div class="epi-header">
        		<h5 class="epi-title-header">
        		    អំពីក្រុមឌីជីថល
        		</h5>
        		<p class="epi-link-header"><a href="/">មើលទាំងអស់ ➧</a></p>
        	 </div>
        	  
        	  <div class="tabs">
        
        		  <div id="tabs-nav-carousel-top-management">
        			  
        			<div id="tabSingle" class="tab-content-carousel-top-management">
        				<div class="swiper-container">
        			
        					<div class="swiper-wrapper" id="digital-episode-carousel">
        	   
        				    </div>  
        			
            				<div class="swiper-button-prev"><img src="https://infotainment.ams.com.kh/wp-content/uploads/2023/04/left-arrow-1.png"></div>
            				<div class="swiper-button-next"><img src="https://infotainment.ams.com.kh/wp-content/uploads/2023/04/arrow-right.png"></div>
        			    </div>
        			</div>
        		  
        		  </div>
        	</div>
        </section>

    </section>    
    
    <section class="section-designer">
        <div id="top-designer"></div>
        
        
        <section id="episode-carousel-producer">
    	
        	<div class="epi-header">
        		<h5 class="epi-title-header">
        		    ក្រុមការងាររចនា(UI/UX DESIGN)
        		</h5>
        		<p class="epi-link-header"><a href="/">មើលទាំងអស់ ➧</a></p>
        	 </div>
        	  
        	  <div class="tabs">
        
        		  <div id="tabs-nav-carousel-top-management">
        			  
        			<div id="tabSingle" class="tab-content-carousel-top-management">
        				<div class="swiper-container">
        			
        					<div class="swiper-wrapper" id="designer-episode-carousel">
        	   
        				    </div>  
        			
            				<div class="swiper-button-prev"><img src="https://infotainment.ams.com.kh/wp-content/uploads/2023/04/left-arrow-1.png"></div>
            				<div class="swiper-button-next"><img src="https://infotainment.ams.com.kh/wp-content/uploads/2023/04/arrow-right.png"></div>
        			    </div>
        			</div>
        		  
        		  </div>
        	</div>
        </section>
        
    </section>
    
    
    <section class="section-developer">
        <h1>ក្រុមការងារអភិវឌ្ឍន៍គេហទំព័រ</h1>
        <div id="developer-team"></div>
    </section>
    
        
    

</div>


<?php



?>


<?php get_footer(); ?>

