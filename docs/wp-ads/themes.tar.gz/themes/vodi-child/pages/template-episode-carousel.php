<?php



function episode_carousel($atts){
    
    ob_start();
    
    ?>
    
    <div class="swiper-container">
		<div class="swiper-wrapper">
		    <?php
		        extract(shortcode_atts( array(
                    'post_type' => 'post_type',
                    'post_status' => 'post_status',
                    'category__in' => 'category__in'
                ), $atts));
                
                
                $options = array(
                    'post_type' => $post_type,
                    'post_status' => $post_status,
                    'category__in' => $category__in
                );
                
                $loop = new WP_Query( $options );
                
                if($loop->have_posts()) :
                    while($loop->have_posts()) : $loop->the_post();
                        ?>
                            <div class="swiper-slide">Slide 1</div>
                        <?php
                    endwhile;
                    
                    
            		
                endif;
                
                wp_reset_query();
                
		    ?>
			 
		</div>
        <!-- If we need pagination -->
        <div class="swiper-pagination"></div>
 
        <!-- If we need navigation buttons -->
        <div class="swiper-button-prev"></div>
        <div class="swiper-button-next"></div>
	</div>
    
    <?php
        $myvariable = ob_get_clean();

        return $myvariable;
    ?>
            	
    <?php



}

add_shortcode('epsode-carousel', 'episode_carousel');


?>