<?php

/* Template Name: Author Detail Page */

?>

<?php get_header(); ?>

<?php

    $authorId = $_GET['authorId'];
    $id = $_GET['id'];

    ?>
    
    <div class="col-lg-12">
        
        <input type="hidden" value="<?php echo $id; ?>" id="author_id">
    
        <section class="section-author">
    
        </section>
        
        <section class="news-article">
            
            <?php echo do_shortcode('[author-article post_type="post" post_status="publish" author="' . $authorId . '" order="DESC" posts_per_page=5]'); ?>
            
        </section>
    
    
    </div>
    
    <section class="author-team">
            
        <div id="top-author"></div>


        <section id="episode-carousel-top-management">
    	
        	<div class="epi-header">
        		<h5 class="epi-title-header">
        		    អំពីអ្នកនិពន្ធ AMS INFOTAINMENT
        		</h5>
        		<p class="epi-link-header"><a href="/">មើលទាំងអស់ ➧</a></p>
        	 </div>
        	  
        	  <div class="tabs">
        
        		  <div id="tabs-nav-carousel-top-management">
        			  
        			<div id="tabSingle" class="tab-content-carousel-top-management">
        				<div class="swiper-container">
        			
        					<div class="swiper-wrapper" id="author-detail-episode-carousel">
        	   
        				    </div>  
        			
            				<div class="swiper-button-prev"><img src="https://infotainment.ams.com.kh/wp-content/uploads/2023/04/left-arrow-1.png"></div>
            				<div class="swiper-button-next"><img src="https://infotainment.ams.com.kh/wp-content/uploads/2023/04/arrow-right.png"></div>
        			    </div>
        			</div>
        		  
        		  </div>
        	</div>
     
        
    </section>  
    </section>
    
    
     

    
    
        
        
    
    <?php


?>


<?php get_footer(); ?>

