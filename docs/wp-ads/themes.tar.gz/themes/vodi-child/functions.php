<?php
/**
 * Vodi Child
 *
 * @package vodi-child
 */

/**
 * Include all your custom code here
 */







  //include watch movie 
  include('video-page/watch-functions.php');
  



  // include shortcode
  
  include('shortcode/custom-shortcode.php');
  include('shortcode/popular-news.php');
  include('shortcode/report-news.php');
  include('shortcode/latest-article-you-should-know.php');
  
  include('shortcode/read-news-videos-left.php');
  include('shortcode/read-news-videos_right.php');
  include('shortcode/read-news-videos.php');
  
  include('shortcode/popular-news-text.php');
  include('shortcode/economy-article-text.php');
  include('shortcode/general-knowledge-text.php');
  
  include('shortcode/impression-articles.php');
  include('shortcode/start-up-innovation.php');
  include('shortcode/real-estate-articles.php');
  include('shortcode/bussiness-articles.php');
  include('shortcode/finance-articles.php');
  include('shortcode/interview-and-report-articles.php');
  include('shortcode/pr-articles.php');
  include('shortcode/latest-articles.php');
  include('shortcode/new-articles.php');
  include('shortcode/general-news.php');
  include('shortcode/author-article.php');
  
  
  
  include('shortcode/episode-carousel.php');
  include('shortcode/episode-carousel-multiple.php');
  
  
  include('shortcode/cambodia360-epi-single.php');
  include('shortcode/cambodia360-epi-multiple.php');
  include('shortcode/khmer-insider-epi-single.php');
  include('shortcode/khmer-insider-epi-multiple.php');
  
  include('shortcode/economy-author-carousel.php');
  include('shortcode/producer-carousel.php');
  include('shortcode/production-carousel.php');
  include('shortcode/digital-team-carousel.php');
  include('shortcode/top-management-carousel.php');
  include('shortcode/designer-team-carousel.php');
  include('shortcode/developer-team-carousel.php');
  include('shortcode/inclusive-bussiness.php');
  
  
  // Author
  include('backend/authors/author.php');
  
  
  include('functions/update-user.php');
  
  
  function getUserIP() {
        // Check for shared internet/ISP IP
        if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
            $ip = $_SERVER['HTTP_CLIENT_IP'];
        }
        // Check for IPs passing through proxies
        elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
        }
        // Check for the remote address
        else {
            $ip = $_SERVER['REMOTE_ADDR'];
        }
    
        // Return the IP address
        return $ip;
    }
  
  
  
   function admin_enqueues() {
       $current_page = isset( $_GET['page'] ) ? $_GET['page'] : '';
       
       
       if ( $current_page === 'admin-author' ) {
           	wp_enqueue_style( 'select2-css', 'https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/css/select2.min.css' );
           	
       		wp_enqueue_style( 'author-css', get_stylesheet_directory_uri() . '/backend/authors/css/style.css');
               		
         	wp_enqueue_style( 'bootstrap-css', 'https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css' );
     	
        	wp_enqueue_style( 'datatables-css', 'https://cdn.datatables.net/1.10.25/css/jquery.dataTables.min.css' );
        	
        	wp_enqueue_style( 'toggle-css', 'https://gitcdn.github.io/bootstrap-toggle/2.2.2/css/bootstrap-toggle.min.css' );
        	
        	wp_enqueue_script( 'sweetalert-js', 'https://cdn.jsdelivr.net/npm/sweetalert2@11.0.19/dist/sweetalert2.min.js', array( 'jquery' ), '4.3.1', true );
        	
        	wp_enqueue_style( 'sweetalert-css', 'https://cdn.jsdelivr.net/npm/sweetalert2@11.0.19/dist/sweetalert2.min.css' );
        	
        	wp_enqueue_script( 'select2-js', 'https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/js/select2.min.js', array( 'jquery' ), '4.3.1', true );
        	
            wp_enqueue_script( 'bootstrap-js', 'https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js', array( 'jquery' ), '4.3.1', true );
    
        	wp_enqueue_script( 'datatables-js', 'https://cdn.datatables.net/1.11.3/js/jquery.dataTables.min.js', array( 'jquery' ), '1.10.25', true );
        	
        	wp_enqueue_script( 'datatables-js', 'https://cdn.datatables.net/1.11.3/js/dataTables.jqueryui.min.js', array( 'jquery' ), '1.10.25', true );
        	
        	wp_enqueue_script( 'toggle-js', 'https://gitcdn.github.io/bootstrap-toggle/2.2.2/js/bootstrap-toggle.min.js', array( 'jquery' ), '1.10.25', true );
        	
    		wp_enqueue_script( 'author-js', get_stylesheet_directory_uri() . '/backend/authors/js/script.js', array ( 'jquery' ), 1.1, true);

    
       }
    	
  }
  
  add_action( 'admin_enqueue_scripts', 'admin_enqueues' );
  

  
  
function custom_feed_rss() {
    load_template(get_stylesheet_directory_uri() . '/custom-rss.php');
}

add_action('do_feed_custom_feed', 'custom_feed_rss', 10, 1);

  
  
  
  
 
 function child_enqueue_styles() {
    wp_enqueue_style( 'global', get_stylesheet_directory_uri() . '/styles/global/global.css', array(), 105 );
    
    if (is_singular('post')) {
        wp_enqueue_style( 'template-post-article', get_stylesheet_directory_uri() . '/styles/template/post-article.css', array(), 110);
    }
    
    // 18747 = The Legacy
    // 75013 = Hot Topic
    
    // START::Template
    // Khmer Insider , The Lagazy, Cam 360, Financial Street
    if (get_queried_object_id()==2930 || get_queried_object_id()==18747 || get_queried_object_id()==24747 || get_queried_object_id()==88073) {
        wp_enqueue_style( 'template-tvshow', get_stylesheet_directory_uri() . '/styles/template/khmer-insider-template.css', array(), 100 );
    }
    if (get_queried_object_id()==75013) {
        wp_enqueue_style( 'template-hot-topic', get_stylesheet_directory_uri() . '/styles/template/hot-news-template.css', array(), 100 );
    }
    
    // END::Template
    
    
    // START::Single
    if (get_queried_object_id()==77456) {
        wp_enqueue_style( 'homepage', get_stylesheet_directory_uri() . '/styles/single/homepage.css', array(), 100 );
    }
    
    if (get_queried_object_id()==161479) {
        wp_enqueue_style( 'homepage', get_stylesheet_directory_uri() . '/styles/single/homepage.css', array(), 100 );
        wp_enqueue_style( 'homepage_opion2', get_stylesheet_directory_uri() . '/styles/single/homepage_opion2.css', array(), 156);
    }
    
    
   if (get_queried_object_id()==167505) {
        wp_enqueue_style( 'homepage', get_stylesheet_directory_uri() . '/styles/single/homepage.css', array(), 102 );
        wp_enqueue_style( 'homepage_opion2', get_stylesheet_directory_uri() . '/styles/single/homepage_opion2.css', array(), 145 );
       
     
    }
    
    if (get_queried_object_id()==167924) {
        wp_enqueue_style( 'homepage', get_stylesheet_directory_uri() . '/styles/single/homepage.css', array(), time() );
        wp_enqueue_style( 'ams-report-news.css', get_stylesheet_directory_uri() . '/styles/single/ams-report-news.css', array(), time() );
        wp_enqueue_style( 'homepage_opion2', get_stylesheet_directory_uri() . '/styles/single/homepage_opion2.css', array(), time());
    }
    //  if (get_queried_object_id()==167949) {
    //     wp_enqueue_style( 'homepage', get_stylesheet_directory_uri() . '/styles/single/homepage.css', array(), 121);
    //     wp_enqueue_style( 'homepage_opion2', get_stylesheet_directory_uri() . '/styles/single/homepage_opion2.css', array(), 111 );
        
        
    // }
    // 8913 = ECONOMY
    if (is_page('economic')) {
        wp_enqueue_style( 'economic-single', get_stylesheet_directory_uri() . '/styles/single/economic-single.css', array(), time() );
    }
    // 9181 = Finance
    if (is_page('finance')) {
        wp_enqueue_style( 'finance-single', get_stylesheet_directory_uri() . '/styles/single/finance-single.css', array(), 100 );
    }
    // 9079 = Real Estate
    if (is_page('real-estate')) {
        wp_enqueue_style( 'real-estate-single', get_stylesheet_directory_uri() . '/styles/single/real-estate-single.css', array(), 110 );
    }
    // 9083 = business
    if (is_page('business')) {
        wp_enqueue_style( 'business-single', get_stylesheet_directory_uri() . '/styles/single/business-single.css', array(), 100 );
    }
    // 9097 = pr
    if (is_page('pr')) {
        wp_enqueue_style( 'pr-single', get_stylesheet_directory_uri() . '/styles/single/pr-single.css', array(), 100 );
    }
    // 9089 = start-up-innovation
    if (is_page('start-up-innovation')) {
        wp_enqueue_style( 'start-up-innovation-single', get_stylesheet_directory_uri() . '/styles/single/start-up-innovation-single.css', array(), 100 );
    }
    
    // 2930 = khmer-insider-single
    if (get_queried_object_id()==2930) {
        wp_enqueue_style( 'khmer-insider-single', get_stylesheet_directory_uri() . '/styles/single/khmer-insider-single.css', array(), 100 );
    }
    // 18747 = the-legacy-single
    if (get_queried_object_id()==18747) {
        wp_enqueue_style( 'the-legacy-single', get_stylesheet_directory_uri() . '/styles/single/the-legacy-single.css', array(), 100 );
    }
    // 24747 = cambodia-360-single
    if (get_queried_object_id()==24747) {
        wp_enqueue_style( 'cambodia-360-single', get_stylesheet_directory_uri() . '/styles/single/cambodia-360-single.css', array(), 100 );
    }
    // 75013 = Hot Topic
    if (get_queried_object_id()==75013) {
        wp_enqueue_style( 'hot-topic-single', get_stylesheet_directory_uri() . '/styles/single/hot-topic-single.css', array(), 100 );
    }
    // 56696 = Read News
        if (get_queried_object_id()==56696) {
        wp_enqueue_style( 'read-news-single', get_stylesheet_directory_uri() . '/styles/single/read-news-single.css', array(), 100 );
    }
    
    // END::Single CSS
    
    // Script Author Page
    if (get_queried_object_id()==84517) {
        wp_enqueue_script( 'author-js', get_stylesheet_directory_uri() . '/js/author.js', array ( 'jquery' ), 1.1, true);
    }
    if (get_queried_object_id()==85122) {
        wp_enqueue_script( 'author-detail-js', get_stylesheet_directory_uri() . '/js/author-detail.js', array ( 'jquery' ), 1.1, true);
    }
    
    // ads revine
    wp_enqueue_style( 'ads-css', get_stylesheet_directory_uri() . '/ads.css', array(),100);
    wp_enqueue_script( 'ads-script', get_stylesheet_directory_uri() . '/ads.js', array ( 'jquery' ),100, true);
    
    
    wp_enqueue_style( 'sw-css', 'https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css' );
    wp_enqueue_script( 'sw-js', 'https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js', array( 'jquery' ), '1.10.25', true );
            

	wp_enqueue_style( 'child-theme', get_stylesheet_directory_uri() . '/style.css', array(), time() );
	wp_enqueue_style( 'shortcode-styles', get_stylesheet_directory_uri() . '/shortcode-styles.css', array(), time());
	wp_enqueue_style( 'ams-latest-news', get_stylesheet_directory_uri() . '/latest-news.css', array(), time() );

// 	wp_enqueue_script( 'child-script', get_stylesheet_directory_uri() . '/script.js', array ( 'jquery' ), 1.1, true);
    wp_enqueue_script( 'child-script', get_stylesheet_directory_uri() . '/script.js', array ( 'jquery' ), time(), true);
	wp_enqueue_script( 'darkmode-script', get_stylesheet_directory_uri() . '/darkmode.js', array ( 'jquery' ), 1.1, true);
	
    //START::Login Dashboard 	
    if (get_queried_object_id()==87325) {
    	wp_enqueue_script( 'login-js', get_stylesheet_directory_uri() . '/js/login.js', array ( 'jquery' ), 1.1, true);
    }
    //END::Login Dashboard
	

}
add_action( 'wp_enqueue_scripts', 'child_enqueue_styles' );
 
 
  /* Limit the number of sitemap entries for Yoast SEO */
function max_entries_per_sitemap() {
    return 100;
}

add_filter( 'wpseo_sitemap_entries_per_page', 'max_entries_per_sitemap' );




//Remove change post type
add_action('init', 'change_post_type');

function change_post_type(){

	if(!is_admin()){

		$url = 'https://' . $_SERVER['SERVER_NAME'] . $_SERVER['REQUEST_URI'];

		if (strpos($url,'post_type=video')) {
			$get_link = str_replace('&post_type=video', '', $url);
			?>
				<script>
					let reload_link = '<?=$get_link?>';
					window.location.href = reload_link;
				</script>
			<?php
		}
	}
	
}


//Change role user registration
if ( ! function_exists( 'vodi_child_modify_new_user_data' ) ) {
    function vodi_child_modify_new_user_data( $args ) {
        $args['role'] = 'subscriber';
        return $args;
    }
}
add_filter( 'masvideos_new_user_data', 'vodi_child_modify_new_user_data', 10 );


// API
//domain.com/wp-json/wp/v2/latest-posts?category_id=

add_action('rest_api_init', function() {

	register_rest_route('wp/v2', 'latest-posts', array(
		'methods' => 'GET',
		'callback' => 'get_latest_posts_by_category'
	));
	
	register_rest_route('wp/v2', 'get-post-text', array(
		'methods' => 'GET',
		'callback' => 'get_post_text'
	));

	register_rest_route('wp/v2', 'post-details', array(
		'methods' => 'GET',
		'callback' => 'get_post_by_id'
	));
	
	register_rest_route('wp/v2', 'khmer-insider', array(
    	'methods' => 'GET',
    	'callback' => 'get_latest_posts_tv_show'
	));
	
	//Get episode by id
	register_rest_route('wp/v2', 'post-details-episode', array(
		'methods' => 'GET',
		'callback' => 'get_post_by_episode_id'
	));
	
	
	

});

function get_latest_posts_by_category($request){

	$args = array(
	    'post_status' => 'publish',
		'category' => $request['category_id'],
		'paged' => $request['page_no'] ? $request['page_no'] : 1,
		'posts_per_page' => $request['page_size']
	);

	$posts = get_posts($args);

	if(empty($posts)){
		return new WP_Error('empty_category', 'there is no post in this category', array('status' => 404));
	}

	$post_list = [];

	foreach($posts as $post) {
		$post_categories = wp_get_post_categories($post->ID);
		$cats = array();

		foreach($post_categories as $c){
			$cat = get_category($c);
			$cats[] = $cat->name;
		}

		$post_list[] = (object) [
			"id" => $post->ID,
			"post_date" => date('d-m-Y', strtotime($post->post_date)),
			"title" => $post->post_title,
			// "category_name" => array_values($cats)[0],
// 			"category_name" => get_the_category($post->ID),
			'author' => get_the_author_meta('display_name', $posts[0]->post_author),
			'description' => $post->post_excerpt,
			"image_url" => get_post_feature_image($post->ID),
// 			"post_content" => $post->post_content,
// 			"post_content" => apply_filters('the_content', $post->post_content),
		];
	}
	
	$total_posts = wp_count_posts()->publish;
	$total_pages = ceil($total_posts / $request['page_size']);
    
    $response = new WP_REST_Response([
        'status'=>'OK',
        "page" => $request['page_no'] ? $request['page_no'] : 1,
        "per_page" => $request['page_size'],
        "total" => count($posts), // Total number of posts in the current page.
        "total_pages" => $total_pages, // Calculate total pages.
        'data' => $post_list
    ]);

    return $response;

// 	$response = new WP_REST_Response(['status'=>'OK', 'data' => $post_list]);
// 	$response->set_status(200);

// 	return $response;

}

function get_post_text($request){

	$args = array(
	    'post_status' => 'publish',
		'category' => $request['category_id'],
		'paged' => $request['page_no'] ? $request['page_no'] : 1,
		'posts_per_page' => $request['page_size']
	);

	$posts = get_posts($args);

	if(empty($posts)){
		return new WP_Error('empty_category', 'there is no post in this category', array('status' => 404));
	}

	$post_list = [];

	foreach($posts as $post) {
		$post_categories = wp_get_post_categories($post->ID);
		$cats = array();

		foreach($post_categories as $c){
			$cat = get_category($c);
			$cats[] = $cat->name;
		}

		$post_list[] = (object) [
			"id" => $post->ID,
			"title" => $post->post_title,
		];
	}
	
	$total_posts = wp_count_posts()->publish;
	$total_pages = ceil($total_posts / $request['page_size']);
    
    $response = new WP_REST_Response([
        'status'=>'OK',
        "page" => $request['page_no'] ? $request['page_no'] : 1,
        "per_page" => $request['page_size'],
        "total" => count($posts), // Total number of posts in the current page.
        "total_pages" => $total_pages, // Calculate total pages.
        'data' => $post_list
    ]);

    return $response;


}


function get_post_by_id($request){
	
	$post = get_post($request["id"]);
	$post_categories = wp_get_post_categories($post->ID);

	$post_output = (object) [
		"id" => $post->ID,
		"post_date" => date('d-m-Y', strtotime($post->post_date)),
		"title" => $post->post_title,
		"category_name" => get_category($post_categories[0])->name,
		'author' => get_author_name($post->ID),
// 		"post_content" => $post->post_content,
		"post_content" => apply_filters('the_content', $post->post_content),
		"image_url" => get_post_feature_image($post->ID),
	];

	$response = new WP_REST_Response($post_output);
	$response->set_status(200);

	return $response;

}


function get_latest_posts_tv_show($request){
    $args = array(
        'post_type' => 'episode',
        'post_status' => 'publish',
        'order' => 'DESC',
        'posts_per_page' => 1,
        'paged' => $request['page_no'] ? $request['page_no'] : 1,
        'meta_query' => array(
            'relation' => 'AND',
    		array(
    			'key' => '_tv_show_id',
    			'value' => 21395
    		)
    	)
	
	);

	$posts = get_posts($args);

	if(empty($posts)){
		return new WP_Error('empty_episode', 'there is no post in this episode', array('status' => 404));
	}

	$post_list = [];

	foreach($posts as $post) {

		$post_list[] = (object) [
			"id" => $post->ID,
			"post_date" => $post->post_date,
			"title" => $post->post_title,
			"image_url" => get_post_feature_image($post->ID),
		];
	}

	$response = new WP_REST_Response(['status'=>'OK', 'data' => $post_list]);
	$response->set_status(200);

	return $response;
}


function get_post_by_episode_id($request){
	
	$post = get_post($request["id"]);
	$post_categories = wp_get_post_categories($post->ID);
	
	$meta = get_post_meta($request["id"], '_episode_url_link', true);

	$post_output = (object) [
		"id" => $post->ID,
		"post_date" => $post->post_date,
		"title" => $post->post_title,
// 		"category_name" => get_category($post_categories[0])->name,
		'author' => get_author_name($post->ID),
// 		"post_content" => $post->post_content,
		"image_url" => get_post_feature_image($post->ID),
		"vimeo_id" => substr($meta,18)
	];

	$response = new WP_REST_Response($post_output);
	$response->set_status(200);

	return $response;

}

function get_post_feature_image($post_id){
	$args = array(
		'posts_per_page' => 1,
		'order' => 'ASC',
		'post_mime_type' => 'image',
		'post_parent' => $post_id,
		'post_type' => 'attachment'
	);
	$attachments = get_children($args);

	return wp_get_attachment_image_src(array_values($attachments)[0]->ID,'app-thumb')[0];
}






// START::Login
 function generate_user_token_login($user_id) {
    // Generate a unique token for the user
    $token = wp_generate_password(256, false);

    // Calculate the token expiration timestamp (1 month from now)
    $expiration = strtotime('+1 month');

    // Store the token and expiration timestamp in user meta
    update_user_meta($user_id, 'user_token', $token);
    update_user_meta($user_id, 'user_token_expiration', $expiration);

    return $token;
}

function login_enqueue_style() {
	wp_enqueue_script( 'custom-login-script', get_stylesheet_directory_uri() . '/js/login.js', array ( 'jquery' ), 1.1, true);
    wp_localize_script( 'custom-login-script', 'customLogin', array(
        'ajaxUrl' => admin_url( 'admin-ajax.php' ),
        'loginAction' => 'custom_login' // Replace with your actual login action
    ) );
}
add_action( 'wp_enqueue_scripts', 'login_enqueue_style' );

// Login AJAX handler
function custom_login_handler() {
    $username = isset( $_POST['uname'] ) ? sanitize_user( $_POST['uname'] ) : '';
    $password = isset( $_POST['upass'] ) ? $_POST['upass'] : '';

    // Perform server-side validation
    if ( empty( $username ) || empty( $password ) ) {
        wp_send_json_error( array( 'status' => 'ERROR', 'message' => 'Please enter both username and password.') );
    }

    $credentials = array(
        'user_login'    => $username,
        'user_password' => $password,
        'remember'      => true
    );
    $user = wp_signon( $credentials, false );

    if ( is_wp_error( $user ) ) {
        wp_send_json_error( array( 'status' => 'ERROR', 'message' => 'Username or Email not correct.') );
    } else {
        $token = generate_user_token_login( $user->ID );
        $user_data = get_userdata( $user->ID );
        $role = $user_data->roles[0];

        $response = array(
            'username' => $username,
            'token' => $token,
            'role' => $role
        );
        wp_send_json_success( array( 'status' => 'OK', 'message' => 'Login Success', 'data' => $response ) );
    }
}
add_action( 'wp_ajax_custom_login', 'custom_login_handler' );
add_action( 'wp_ajax_nopriv_custom_login', 'custom_login_handler' );
// END::Login



function get_current_user_details() {
    // Get the current user's information
    $current_user = wp_get_current_user();

    // Initialize an array to store the user details
    $user_details = array();

    // Check if the user is logged in
    if ( $current_user->ID != 0 ) {
        // User is logged in
        $user_details['id'] = $current_user->ID;
        $user_details['email'] = $current_user->user_email;
        $user_details['profile_image'] = get_avatar( $current_user->ID);
        $user_details['first_name'] = $current_user->first_name;
        $user_details['last_name'] = $current_user->last_name;
        $user_details['display_name'] = $current_user->display_name;
        $user_details['phone_number'] = $current_user->phone_number;
        $user_details['dob'] = $current_user->dob;
        $user_details['gender'] = $current_user->gender;
    } else {
        // User is not logged in
        $user_details['id'] = '';
        $user_details['email'] = '';
        $user_details['profile_image'] = '';
        $user_details['first_name'] = '';
        $user_details['last_name'] = '';
        $user_details['display_name'] = '';
        $user_details['phone_number'] = '';
        $user_details['dob'] = '';
        $user_details['gender'] = '';
    }

    return $user_details;
}


class Custom_Multi_Level_Walker extends Walker_Nav_Menu {
    function start_lvl(&$output, $depth = 0, $args = null) {
        $output .= '<ul class="sub-menu-b">';
    }

    function start_el(&$output, $item, $depth = 0, $args = null, $id = 0) {
        $indent = ($depth) ? str_repeat("\t", $depth) : '';
    
        $toggle_icon = '';
    
        if ($args->walker->has_children) {
            $toggle_icon = '<span class="toggle-icon"><i class="fa fa-angle-up"></i></span>';
        }
    
        $icon_menu = wp_get_attachment_url($item->thumbnail_id);
        
        $icon = '';
        
        if (!empty($icon_menu)) {
            $icon = '<img src="' . $icon_menu . '" alt="' . $item->title . '" class="menu-icon" style="height:18px;margin-right:10px;" />';
        }
    
        $output .= $indent . '<li>';
        $output .= '<a href="' . $item->url . '">' . $icon . $item->title . '</a>';
        $output .= $toggle_icon;
    }
    
    
    

    function end_el(&$output, $item, $depth = 0, $args = null) {
        $output .= '</li>';
    }

    function end_lvl(&$output, $depth = 0, $args = null) {
        $output .= '</ul>';
    }
}




// START::ADD Secondary Thumbnail Image

function add_secondary_thumbnail_episode() {
    add_meta_box(
        'episode-featured-image',
        'Landscape Thumbnail',
        'add_secondary_episode_image',
        'episode',
        'side',
        'default'
    );
}

function add_secondary_thumbnail_tvshow() {
    add_meta_box(
        'tvshow-featured-image',
        'TV Show Icon',
        'add_secondary_tvshow_image',
        'tv_show', // Change 'episode' to 'tvshow'
        'side',
        'default'
    );
}

add_action('add_meta_boxes', 'add_secondary_thumbnail_episode');

add_action('add_meta_boxes', 'add_secondary_thumbnail_tvshow');


function add_secondary_episode_image($post) {
    wp_nonce_field(basename(__FILE__), 'episode_featured_image_nonce');
    $featured_image_id = get_post_meta($post->ID, '_episode_featured_image_secondary', true);
    $featured_image_url = wp_get_attachment_url($featured_image_id);
    ?>
    <div id="custom-featured-image-container">
        <img id="custom-featured-image" src="<?php echo esc_url($featured_image_url); ?>" style="max-width: 100%;" />
        <div style="display:flex;margin-top:10px;">
            <p>
                <label for="custom-featured-image-upload">
                    <input type="button" id="custom-featured-image-upload" class="button" value="<?php echo $featured_image_url ? 'Replace' : 'Upload Image'; ?>" />
                </label>
            </p>
            <p>
                <label for="custom-featured-image-remove">
                    <input type="button" id="custom-featured-image-remove" class="button" value="Remove" style="border:none;color:#cc1818;background:none;" />
                </label>
            </p>
        </div>
        <input type="hidden" name="episode_featured_image" id="episode_featured_image" value="<?php echo esc_attr($featured_image_id); ?>" />
    </div>
    <script>
    jQuery(document).ready(function($) {
        // Media Uploader
        var custom_uploader;
        var $customFeaturedImageUpload = $('#custom-featured-image-upload');

        // Check if a featured image URL is available
        if (<?php echo $featured_image_url ? 'true' : 'false'; ?>) {
            $customFeaturedImageUpload.val('Replace');
        }

        $customFeaturedImageUpload.click(function(e) {
            e.preventDefault();
            if (custom_uploader) {
                custom_uploader.open();
                return;
            }
            custom_uploader = wp.media({
                title: 'Upload Featured Image',
                button: {
                    text: 'Set Featured Image'
                },
                multiple: false
            });
            custom_uploader.on('select', function() {
                var attachment = custom_uploader.state().get('selection').first().toJSON();
                $('#custom-featured-image').attr('src', attachment.url);
                $('#episode_featured_image').val(attachment.id);
                $customFeaturedImageUpload.val('Update Image'); // Change the button text
                $('#custom-featured-image-remove').show(); // Show the remove button
            });
            custom_uploader.open();
        });

        // Remove Featured Image
        $('#custom-featured-image-remove').click(function() {
            $('#custom-featured-image').attr('src', '');
            $('#episode_featured_image').val('');
            $customFeaturedImageUpload.val('Upload Image'); // Change the button text back to "Upload Image"
            $('#custom-featured-image-remove').hide(); // Hide the remove button
        });

        // Show or hide the remove button initially
        if (!$('#episode_featured_image').val()) {
            $('#custom-featured-image-remove').hide();
        }
    });
    </script>
    <?php
}

function custom_save_episode_featured_image($post_id) {
    if (!isset($_POST['episode_featured_image']) || !wp_verify_nonce($_POST['episode_featured_image_nonce'], basename(__FILE__))) {
        return;
    }

    $featured_image_id = sanitize_text_field($_POST['episode_featured_image']);
    update_post_meta($post_id, '_episode_featured_image_secondary', $featured_image_id);
}
add_action('save_post', 'custom_save_episode_featured_image');
// END::ADD Secondary Thumbnail Image

// START::Set Icon TV Show
function add_secondary_tvshow_image($post) {
    wp_nonce_field(basename(__FILE__), 'tvshow_featured_image_nonce'); // Update nonce field
    $featured_image_id = get_post_meta($post->ID, '_tvshow_featured_image_secondary', true); // Update meta key
    $featured_image_url = wp_get_attachment_url($featured_image_id);
    ?>
    <div id="custom-featured-image-container">
        <img id="custom-featured-image" src="<?php echo esc_url($featured_image_url); ?>" style="max-width: 100%;" />
        <div style="display:flex;margin-top:10px;">
            <p>
                <label for="custom-featured-image-upload">
                    <input type="button" id="custom-featured-image-upload" class="button" value="<?php echo $featured_image_url ? 'Replace' : 'Upload Image'; ?>" />
                </label>
            </p>
            <p>
                <label for="custom-featured-image-remove">
                    <input type="button" id="custom-featured-image-remove" class="button" value="Remove" style="border:none;color:#cc1818;background:none;" />
                </label>
            </p>
        </div>
        <input type="hidden" name="tvshow_featured_image" id="tvshow_featured_image" value="<?php echo esc_attr($featured_image_id); ?>" /> <!-- Update field name -->
    </div>
    <script>
    jQuery(document).ready(function($) {
        // Media Uploader
        var custom_uploader;
        var $customFeaturedImageUpload = $('#custom-featured-image-upload');

        // Check if a featured image URL is available
        if (<?php echo $featured_image_url ? 'true' : 'false'; ?>) {
            $customFeaturedImageUpload.val('Replace');
        }

        $customFeaturedImageUpload.click(function(e) {
            e.preventDefault();
            if (custom_uploader) {
                custom_uploader.open();
                return;
            }
            custom_uploader = wp.media({
                title: 'Upload Featured Image',
                button: {
                    text: 'Set Featured Image'
                },
                multiple: false
            });
            custom_uploader.on('select', function() {
                var attachment = custom_uploader.state().get('selection').first().toJSON();
                $('#custom-featured-image').attr('src', attachment.url);
                $('#tvshow_featured_image').val(attachment.id); // Update field name
                $customFeaturedImageUpload.val('Update Image'); // Change the button text
                $('#custom-featured-image-remove').show(); // Show the remove button
            });
            custom_uploader.open();
        });

        // Remove Featured Image
        $('#custom-featured-image-remove').click(function() {
            $('#custom-featured-image').attr('src', '');
            $('#tvshow_featured_image').val(''); // Update field name
            $customFeaturedImageUpload.val('Upload Image'); // Change the button text back to "Upload Image"
            $('#custom-featured-image-remove').hide(); // Hide the remove button
        });

        // Show or hide the remove button initially
        if (!$('#tvshow_featured_image').val()) { // Update field name
            $('#custom-featured-image-remove').hide();
        }
    });
    </script>
    <?php
}

function custom_save_tvshow_featured_image($post_id) {
    if (!isset($_POST['tvshow_featured_image']) || !wp_verify_nonce($_POST['tvshow_featured_image_nonce'], basename(__FILE__))) { // Update nonce field
        return;
    }

    $featured_image_id = sanitize_text_field($_POST['tvshow_featured_image']); // Update field name
    update_post_meta($post_id, '_tvshow_featured_image_secondary', $featured_image_id); // Update meta key
}
add_action('save_post', 'custom_save_tvshow_featured_image');
// END::Set Icon TV Show






function ams_get_sites_api() {
    $apiurl = 'https://searchapi.amscloud.cc/sites';

    $response = wp_remote_get($apiurl, [
        'timeout' => 15,
        'headers' => [
            'Accept' => 'application/json',
        ],
    ]);

    // Check WP error
    if (is_wp_error($response)) {
        return false;
    }

    // Check HTTP status
    $status = wp_remote_retrieve_response_code($response);
    if ($status !== 200) {
        return false;
    }

    // Get response body
    $body = wp_remote_retrieve_body($response);
    if (empty($body)) {
        return false;
    }

    // Decode JSON
    $data = json_decode($body, true);
    if (json_last_error() !== JSON_ERROR_NONE) {
        return false;
    }

    return $data;
}
 // GET KHMER SLUGS
function get_khmer_slugs($slug)
{
    $label_kh = [
        'central'  => 'សង់ត្រាល',
        'chivilize' => 'អរិយធម៌',
        'economy'  => 'សេដ្ឋកិច្ច',
        'education' => 'អប់រំ',
        'infotainment'  => 'ព័ត៌មានកម្សាន្ត',
        'radio'  => 'វិទ្យុអប្សរា',
        'sport'  => 'កីឡា',
    ];
    return $label_kh[$slug];
}
add_action('rest_api_init', function () {
    register_rest_route('myapi/v1', '/search', [
        'methods'             => 'GET',
        'callback'            => 'my_search_api',
        'permission_callback' => '__return_true',
    ]);
});

function my_search_api(WP_REST_Request $request) {
    $query = sanitize_text_field($request->get_param('s'));

    $posts = get_posts([
        's'              => $query,          // full-text search title + content
        'post_type'      => 'post',          // change to 'page' or custom CPT
        'post_status'    => 'publish',
        'posts_per_page' => 10,
    ]);

    $results = array_map(fn($p) => [
        'id'       => $p->ID,
        'label'    => $p->post_title,        // article title
        'sublabel' => get_the_excerpt($p),   // short excerpt
        'url'      => get_permalink($p->ID), // link to article
        'date'     => get_the_date('d M Y', $p),
        'category' => implode(', ', wp_get_post_categories($p->ID, ['fields' => 'names'])),
    ], $posts);

    return rest_ensure_response($results);
}
// search 

add_action('wp_ajax_ams_search_suggest', 'ams_search_suggest');
add_action('wp_ajax_nopriv_ams_search_suggest', 'ams_search_suggest');

function ams_search_suggest() {
    $q = isset($_GET['q']) ? sanitize_text_field(wp_unslash($_GET['q'])) : '';
    $limit = isset($_GET['limit']) ? intval($_GET['limit']) : 8;

    if (empty($q)) {
        wp_send_json_success([
            'suggestions' => []
        ]);
    }

    $limit = max(1, min(20, $limit));

    $api_url = add_query_arg([
        'q'     => $q,
        'limit' => $limit,
    ], 'https://searchapi.amscloud.cc/search/suggest');

    $response = wp_remote_get($api_url, [
        'timeout' => 15,
        'headers' => [
            'Accept' => 'application/json',
        ],
    ]);

    if (is_wp_error($response)) {
        wp_send_json_error([
            'message' => $response->get_error_message()
        ], 500);
    }

    $code = wp_remote_retrieve_response_code($response);
    $body = wp_remote_retrieve_body($response);
    $data = json_decode($body, true);

    if ($code !== 200) {
        wp_send_json_error([
            'message' => 'API request failed',
            'status'  => $code,
            'body'    => $body,
        ], $code);
    }

    if (!is_array($data)) {
        wp_send_json_error([
            'message' => 'Invalid JSON response'
        ], 500);
    }

    wp_send_json_success($data);
}

add_action('wp_enqueue_scripts', 'ams_enqueue_search_assets');
function ams_enqueue_search_assets() {
    if (is_search() || is_page()) {
        wp_enqueue_script(
            'ams-search-suggest',
            get_stylesheet_directory_uri() . '/ajax_search.js',
            [],
            filemtime(get_stylesheet_directory() . '/ajax_search.js'),
            true
        );

        wp_localize_script('ams-search-suggest', 'amsSearch', [
            'ajaxurl' => admin_url('admin-ajax.php'),
        ]);
    }
}



// Auto slug to url 30/03/2026
// function tsp_update_custom_permalink($post_id, $post, $update)
// {
//     // Skip auto-drafts, revisions, and autosaves
//     if ($post->post_status === 'auto-draft')             return;
//     if (wp_is_post_revision($post_id))                   return;
//     if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE)     return;

//     // Run for draft, publish, private, future
//     $allowed = ['draft', 'publish', 'private', 'future'];
//     if (! in_array($post->post_status, $allowed, true))  return;

//     // Get post_name fresh from DB (may have been updated by slug hook at priority 20)
//     $post_slug = get_post_field('post_name', $post_id);
//     if (empty($post_slug)) return;

//     // Resolve deepest sub-category, excluding 'top-news'
//     $cat_slug   = '';
//     $categories = get_the_category($post_id);

//     if (! empty($categories)) {
//         $filtered = array_values(array_filter(
//             $categories,
//             fn($c) => $c->slug !== 'top-news'
//         ));
//         $pool = ! empty($filtered) ? $filtered : $categories;

//         $best  = null;
//         $depth = -1;
//         foreach ($pool as $c) {
//             $d = count(get_ancestors($c->term_id, 'category'));
//             if ($d > $depth) {
//                 $depth = $d;
//                 $best  = $c;
//             }
//         }

//         $cat_slug = ($best ?? $pool[0])->slug;
//     }

//     $parts     = array_filter([$cat_slug, $post_slug]);
//     $url_parts = implode('/', $parts);

//     update_post_meta($post_id, 'custom_permalink', $url_parts);
// }
// add_action('wp_after_insert_post', 'tsp_update_custom_permalink', 35, 3);



// function tsp_update_custom_permalink($post_id, $post, $update)
// {
//     // Skip auto-drafts, revisions, and autosaves
//     if ($post->post_status === 'auto-draft')              return;
//     if (wp_is_post_revision($post_id))                   return;
//     if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE)     return;

//     // Run for draft, publish, private, future
//     $allowed = ['draft', 'publish', 'private', 'future'];
//     if (! in_array($post->post_status, $allowed, true))  return;

//     // Get post_name fresh from DB (may have been updated by slug hook at priority 20)
//     $post_slug = get_post_field('post_name', $post_id);
//     if (empty($post_slug)) return;

//     // Resolve deepest sub-category, excluding 'top-news'
//     $cat_slug   = '';
//     $categories = get_the_category($post_id);

//     if (! empty($categories)) {
//         $filtered = array_values(array_filter(
//             $categories,
//             fn($c) => $c->slug !== 'top-news'
//         ));
//         $pool = ! empty($filtered) ? $filtered : $categories;

//         $best  = null;
//         $depth = -1;
//         foreach ($pool as $c) {
//             $d = count(get_ancestors($c->term_id, 'category'));
//             if ($d > $depth) {
//                 $depth = $d;
//                 $best  = $c;
//             }
//         }

//         $cat_slug = ($best ?? $pool[0])->slug;
//     }

//     $parts     = array_filter([$cat_slug, $post_slug]);
//     $url_parts = implode('/', $parts);

//     // Before overwriting, save the previous permalink so redirects can use it
//     $old_permalink = get_post_meta($post_id, 'custom_permalink', true);
//     if (! empty($old_permalink) && $old_permalink !== $url_parts) {
//         update_post_meta($post_id, 'old_custom_permalink', $old_permalink);
//     }

//     update_post_meta($post_id, 'custom_permalink', $url_parts);
// }
// add_action('wp_after_insert_post', 'tsp_update_custom_permalink', 35, 3);





