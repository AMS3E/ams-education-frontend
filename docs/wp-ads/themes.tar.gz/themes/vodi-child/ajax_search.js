// search 
document.addEventListener("DOMContentLoaded", function () {
    const searchInput = document.getElementById("searchInput");
    const dropdown = document.getElementById("dropdown");
    const clearBtn = document.getElementById("clearBtn");
    const form = document.querySelector(".wrap");

    if (!searchInput || !dropdown || !clearBtn || !form) return;

    let debounceTimer = null;

    function escapeHtml(text) {
        const div = document.createElement("div");
        div.textContent = text;
        return div.innerHTML;
    }

    function hideDropdown() {
        dropdown.innerHTML = "";
        dropdown.style.display = "none";
    }

    function showDropdown() {
        dropdown.style.display = "block";
    }

    function renderSuggestions(items) {
        if (!items || !items.length) {
            dropdown.innerHTML = '<div class="dropdown-empty">រកមិនឃើញ</div>';
            showDropdown();
            return;
        }

        let html = '<ul class="dropdown-list">';
        items.forEach(function (item) {
            html += `
                <li class="dropdown-item" data-value="${escapeHtml(item)}" style="gap: 3px; margin-top: 3px;">
                 <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-search w-4 h-4 text-muted-foreground" aria-hidden="true" style="margin-top:3px;"><path d="m21 21-4.34-4.34"></path><circle cx="11" cy="11" r="8"></circle></svg>
                    ${escapeHtml(item)}
                </li>
            `;
        });
        html += '</ul>';

        dropdown.innerHTML = html;
        showDropdown();

        dropdown.querySelectorAll(".dropdown-item").forEach(function (li) {
            li.addEventListener("click", function () {
                const value = this.getAttribute("data-value") || "";
                searchInput.value = value;
                hideDropdown();
                form.submit();
            });
        });
    }

    async function fetchSuggestions(keyword) {
        const url = `${amsSearch.ajaxurl}?action=ams_search_suggest&q=${encodeURIComponent(keyword)}&limit=8`;

        try {
            const response = await fetch(url, {
                method: "GET",
                credentials: "same-origin"
            });

            const result = await response.json();
            console.log("API Result:", result);

            if (!result.success || !Array.isArray(result.data)) {
                hideDropdown();
                return;
            }

            renderSuggestions(result.data);

        } catch (error) {
            console.error("Suggest error:", error);
            hideDropdown();
        }
    }

    searchInput.addEventListener("input", function () {
        const keyword = this.value.trim();

        if (!keyword) {
            hideDropdown();
            clearBtn.style.display = "none";
            return;
        }

        clearBtn.style.display = "flex";

        clearTimeout(debounceTimer);
        debounceTimer = setTimeout(function () {
            fetchSuggestions(keyword);
        }, 300);
    });

    clearBtn.addEventListener("click", function () {
        searchInput.value = "";
        searchInput.focus();
        clearBtn.style.display = "none";
        hideDropdown();
    });

    document.addEventListener("click", function (e) {
        if (!e.target.closest(".search-container")) {
            hideDropdown();
        }
    });

    if (searchInput.value.trim()) {
        clearBtn.style.display = "flex";
    } else {
        clearBtn.style.display = "none";
    }
});