<?php

/* Template Name: Audio */

get_header();


function generate_audio_file($text, $voice, $format) {
    // AWS Polly API endpoint
    $url = 'https://polly.us-west-2.amazonaws.com';

    // AWS access key and secret key
    $access_key = 'AKIAQSPHD4XYYA6AZNVW';
    $secret_key = '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';

    // AWS region
    $region = 'us-west-2';

    // AWS Polly API parameters
    $params = array(
        'Action' => 'synthesizeSpeech',
        'OutputFormat' => $format,
        'Text' => $text,
        'VoiceId' => $voice
    );

    // Generate the AWS Polly API request URL
    $request_url = $url . '/v1/' . 'synthesizeSpeech?' . http_build_query($params);

    // Generate the AWS signature for the request
    $datetime = gmdate('Ymd\THis\Z');
    $date = substr($datetime, 0, 8);
    $signature = hash_hmac('sha256', $date, 'AWS4' . $secret_key, true);
    $signature = hash_hmac('sha256', $region, $signature, true);
    $signature = hash_hmac('sha256', 'polly', $signature, true);
    $signature = hash_hmac('sha256', 'aws4_request' . "\n" . $datetime . "\n" . $date . '/' . $region . '/polly/aws4_request' . "\n" . hash('sha256', $request_url), $signature, true);
    $signature = bin2hex($signature);

    // Generate the AWS Polly API headers
    $headers = array(
        'Content-Type' => 'application/json',
        'X-Amz-Date' => $datetime,
        'Authorization' => 'AWS4-HMAC-SHA256 Credential=' . $access_key . '/' . $date . '/' . $region . '/polly/aws4_request,SignedHeaders=content-type;x-amz-date,Signature=' . $signature
    );

    // Send the AWS Polly API request using wp_remote_get
    $response = wp_remote_get($request_url, array('headers' => $headers));

    // Check for errors and handle the response
    if (is_wp_error($response)) {
        // There was an error in the request
        echo $response->get_error_message();
        return null;
    } else {
        // The request was successful
        $audio_content = wp_remote_retrieve_body($response);
        return $audio_content;
    }
}


$audio_content = generate_audio_file('Hello, world!', 'Joanna', 'mp3');
if ($audio_content !== null) {
    $data_url = 'data:audio/mp3;base64,' . base64_encode($audio_content);
    echo '<audio controls src="' . $data_url . '">Your browser does not support the audio element.</audio>';
}



get_footer();


?>