window.lockBodyScroll = window.lockBodyScroll || function () {
  if (document.body.classList.contains('panel-open')) {
    return;
  }

  document.body.classList.add('panel-open');

  if (window.innerWidth > 768) {
    return;
  }

  const scrollY = window.scrollY || window.pageYOffset || 0;
  document.body.dataset.panelScrollY = String(scrollY);
  document.body.style.position = 'fixed';
  document.body.style.top = `-${scrollY}px`;
  document.body.style.left = '0';
  document.body.style.right = '0';
  document.body.style.width = '100%';
};

window.unlockBodyScroll = window.unlockBodyScroll || function () {
  document.body.classList.remove('panel-open');

  if (window.innerWidth > 768) {
    return;
  }

  const savedScrollY = parseInt(document.body.dataset.panelScrollY || '0', 10) || 0;
  document.body.style.position = '';
  document.body.style.top = '';
  document.body.style.left = '';
  document.body.style.right = '';
  document.body.style.width = '';
  delete document.body.dataset.panelScrollY;

  window.scrollTo(0, savedScrollY);
};

window.formatDisplayUrl = window.formatDisplayUrl || function (url, title) {
  const rawUrl = (url || '').trim();
  const rawTitle = (title || '').trim();

  if (!rawUrl) {
    return '';
  }

  try {
    const parsedUrl = new URL(rawUrl, window.location.origin);
    const segments = parsedUrl.pathname.split('/').filter(Boolean);

    if (segments.length) {
      const lastIndex = segments.length - 1;

      if (/^\d+$/.test(segments[lastIndex]) && rawTitle) {
        segments[lastIndex] = rawTitle
          .toLowerCase()
          .replace(/[^a-z0-9\s-]/g, '')
          .trim()
          .replace(/\s+/g, '-')
          .replace(/-+/g, '-');
      }
    }

    return parsedUrl.origin + (segments.length ? '/' + segments.join('/') : '');
  } catch (error) {
    return rawUrl;
  }
};

document.addEventListener('DOMContentLoaded', function () {
  const idwach = document.getElementById('idwach');
  const previewImg = document.querySelector('.object-contain');
  const addTitle = document.getElementById('txt-title');
  const allimage = document.getElementById('image_all');
  const similaformId = document.getElementById('similaform_id');
  const btnClose = document.getElementById('btn_close');
  const imageResultsLayout = document.querySelector('.image-results-layout');
  const imageResultsMain = document.querySelector('.image-results-main');
  const resultUrls = document.querySelectorAll('.text-xs.text-muted-foreground.truncate');

  resultUrls.forEach(function (urlElement) {
    const titleElement = urlElement.closest('.overflow-hidden')?.querySelector('.line-clamp-2, h3');
    const formattedUrl = window.formatDisplayUrl(urlElement.textContent, titleElement ? titleElement.textContent : '');

    if (formattedUrl) {
      urlElement.textContent = formattedUrl;
      urlElement.title = formattedUrl;
    }
  });

  function getCards() {
    return document.querySelectorAll('.search-masonry-card');
  }

  function updatePreview(cardElement) {
    if (!cardElement) return;

    if (idwach) {
      idwach.href = cardElement.dataset.url || '#';
    }

    const titleEl = cardElement.querySelector('.line-clamp-2');
    if (addTitle) {
      addTitle.textContent = titleEl ? titleEl.textContent.trim() : '';
    }

    const cardImg = cardElement.querySelector('img');
    if (previewImg && cardImg) {
      previewImg.src = cardImg.src;

      if (cardImg.srcset) {
        previewImg.setAttribute('srcset', cardImg.srcset);
      } else {
        previewImg.removeAttribute('srcset');
      }

      if (cardImg.sizes) {
        previewImg.setAttribute('sizes', cardImg.sizes);
      } else {
        previewImg.removeAttribute('sizes');
      }
    }
  }

  function highlightSelection(activeId) {
    getCards().forEach(function (card) {
      card.classList.toggle('ring-blue-500', card.dataset.id === activeId);
    });

    document.querySelectorAll('.simila-image').forEach(function (image) {
      image.classList.toggle('border-blue-500', image.dataset.id === activeId);
    });
  }

  function renderSimilarImages(cards) {
    if (!allimage || !cards.length) return;

    const btnImages = document.querySelectorAll('.btn-image');
    if (btnImages.length === cards.length) return;

    let context = '';

    cards.forEach(function (card, index) {
      const img = card.querySelector('img');
      const title = card.querySelector('.line-clamp-2');

      context += `
        <button
          data-id="${card.dataset.id}"
          data-index="${index}"
          style="padding:4px; width:100%;"
          class="search-image-card-media w-full rounded-lg overflow-hidden border-2 transition btn-image simila-image"
        >
          <img
            alt="${title ? title.textContent.trim() : ''}"
            loading="lazy"
            width="150"
            height="150"
            decoding="async"
            class="search-image-card-photo w-full h-full object-cover"
            src="${img ? img.src : ''}"
            srcset="${img ? (img.srcset || img.src) : ''}"
          >
        </button>
      `;
    });

    allimage.innerHTML = context;
  }

  document.addEventListener('click', function (e) {
    const clickedCard = e.target.closest('.search-masonry-card');
    const clickedSimila = e.target.closest('.simila-image');
    const cards = getCards();

    if (clickedCard) {
      updatePreview(clickedCard);
      renderSimilarImages(cards);
      highlightSelection(clickedCard.dataset.id);

      if (similaformId) {
        similaformId.classList.remove('hide-form');
        if (imageResultsLayout) {
          imageResultsLayout.classList.add('panel-is-open');
        }
        window.lockBodyScroll();
      }
      return;
    }

    if (clickedSimila) {
      const matchCard = document.querySelector(`.search-masonry-card[data-id="${clickedSimila.dataset.id}"]`);
      if (!matchCard) return;

      updatePreview(matchCard);
      highlightSelection(clickedSimila.dataset.id);
    }
  });

  if (btnClose && similaformId) {
    btnClose.addEventListener('click', function () {
      similaformId.classList.add('hide-form');
      if (imageResultsLayout) {
        imageResultsLayout.classList.remove('panel-is-open');
      }
      window.unlockBodyScroll();
    });
  }
});

document.addEventListener('DOMContentLoaded', function () {
  const trigger = document.getElementById('site-filter');
  const menu = document.getElementById('site-filter-menu');
  const valueText = document.getElementById('site-filter-value');
  const hiddenInput = document.getElementById('site_slug_id');
  const hiddenAppliedInput = document.getElementById('site_filter_applied_id');

  if (!trigger || !menu || !valueText) {
    return;
  }

  const items = Array.from(menu.querySelectorAll('.filter-item'));

  function getItemLabel(item) {
    const label = item.querySelector('span');
    return label ? label.textContent.trim() : item.textContent.trim();
  }

  function getItemSlug(item) {
    if (item.dataset.value !== undefined) {
      return item.dataset.value;
    }

    try {
      const url = new URL(item.href, window.location.origin);
      return url.searchParams.get('site_slug') || '';
    } catch (error) {
      return '';
    }
  }

  function closeMenu() {
    menu.classList.add('hidden');
    trigger.setAttribute('aria-expanded', 'false');
  }

  function openMenu() {
    menu.classList.remove('hidden');
    trigger.setAttribute('aria-expanded', 'true');
  }

  function syncCheckmarks(selectedItem) {
    items.forEach(function (item) {
      const isSelected = item === selectedItem;
      item.classList.toggle('is-selected', isSelected);
      item.setAttribute('aria-selected', isSelected ? 'true' : 'false');

      let check = item.querySelector('.check');
      if (isSelected && !check) {
        check = document.createElement('span');
        check.className = 'text-blue-600 font-bold check';
        check.setAttribute('aria-hidden', 'true');
        check.innerHTML = '<svg width="14" height="14" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M3 8.5L6.5 12L13 4.5" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" /></svg>';
        item.appendChild(check);
      }

      if (!isSelected && check) {
        check.remove();
      }
    });
  }

  function setSelectedItem(selectedItem) {
    if (!selectedItem) {
      return;
    }

    valueText.textContent = getItemLabel(selectedItem);

    if (hiddenInput) {
      hiddenInput.value = getItemSlug(selectedItem);
    }

    if (hiddenAppliedInput) {
      hiddenAppliedInput.value = getItemSlug(selectedItem) ? '1' : '';
    }

    syncCheckmarks(selectedItem);
  }

  const initialSelectedItem = items.find(function (item) {
    return item.querySelector('.check');
  }) || items[0];

  setSelectedItem(initialSelectedItem);

  trigger.addEventListener('click', function (event) {
    event.preventDefault();
    event.stopPropagation();

    if (menu.classList.contains('hidden')) {
      openMenu();
      return;
    }

    closeMenu();
  });

  items.forEach(function (item) {
    item.addEventListener('click', function () {
      setSelectedItem(item);
      closeMenu();
    });
  });

  menu.addEventListener('click', function (event) {
    event.stopPropagation();
  });

  document.addEventListener('click', function (event) {
    if (!event.target.closest('.site-filter-wrap') && !event.target.closest('#site-filter-menu')) {
      closeMenu();
    }
  });

  document.addEventListener('keydown', function (event) {
    if (event.key === 'Escape') {
      closeMenu();
    }
  });

  closeMenu();
});


