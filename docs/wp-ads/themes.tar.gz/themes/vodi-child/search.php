<?php get_header(); ?>
<?php
// incloud funtion php
require_once __DIR__ . '/search_funtion.php';

if (!function_exists('search_detect_default_site_slug')) {
    function search_detect_default_site_slug()
    {
        $candidates = [];
        $server_host = strtolower((string) ($_SERVER['HTTP_HOST'] ?? $_SERVER['SERVER_NAME'] ?? ''));
        $server_uri = strtolower((string) ($_SERVER['REQUEST_URI'] ?? ''));
        $home_url_host = strtolower((string) wp_parse_url(home_url('/'), PHP_URL_HOST));
        $home_url_path = strtolower(trim((string) wp_parse_url(home_url('/'), PHP_URL_PATH), '/'));

        foreach ([$server_host, $server_uri, $home_url_host, $home_url_path] as $candidate) {
            if ($candidate !== '') {
                $candidates[] = $candidate;
            }
        }

        $site_map = [
            'economy' => ['economy.ams.com.kh', '/economy', 'economy'],
            'infotainment' => ['infotainment.ams.com.kh', '/infotainment', 'infotainment'],
            'education' => ['education.ams.com.kh', '/education', 'education', 'eductaion'],
        ];

        foreach ($site_map as $slug => $patterns) {
            foreach ($candidates as $candidate) {
                foreach ($patterns as $pattern) {
                    if ($candidate === $pattern || strpos($candidate, $pattern) !== false) {
                        return $slug;
                    }
                }
            }
        }

        return '';
    }
}
//get data Url
$q = sanitize_text_field($_GET['s'] ?? '');
$page = max(1, intval($_GET['page'] ?? 1));
$limit = min(100, intval($_GET['limit'] ?? 10));
$tab = sanitize_text_field($_GET['tab'] ?? '');
$site_filter_applied = sanitize_text_field($_GET['site_filter_applied'] ?? '') === '1';
$site_slug = $site_filter_applied ? sanitize_text_field($_GET['site_slug'] ?? '') : '';

if ($site_slug === 'eductaion') {
    $site_slug = 'education';
}

if (!$site_filter_applied && $site_slug === '') {
    $site_slug = search_detect_default_site_slug();

    if ($site_slug !== '') {
        $site_filter_applied = true;
    }
}
// get data 
$data = readapi($q, $page, $limit, $tab, $site_slug);

if (!function_exists('search_result_domain_label')) {
    function search_result_domain_label($hit)
    {
        $hosts = [];
        $paths = [];

        foreach (['url', 'favicon_url', 'site_logo', 'featured_image', 'thumbnail_url'] as $key) {
            $raw_url = (string) ($hit[$key] ?? '');
            $path = wp_parse_url($raw_url, PHP_URL_PATH);
            $host = wp_parse_url((string) ($hit[$key] ?? ''), PHP_URL_HOST);

            if (is_string($host) && $host !== '') {
                $hosts[] = strtolower($host);
            }

            if (is_string($path) && $path !== '') {
                $paths[] = trim(strtolower($path), '/');
            }
        }

        foreach ($hosts as $host) {
            if (!filter_var($host, FILTER_VALIDATE_IP)) {
                return 'http://' . preg_replace('/^www\./', '', $host);
            }
        }

        foreach ($paths as $path) {
            if (preg_match('/^(?:https?:\/\/)?([a-z0-9-]+(?:\.[a-z0-9-]+)+)$/i', $path, $matches)) {
                return 'http://' . preg_replace('/^www\./', '', strtolower($matches[1]));
            }
        }

        $slug = strtolower((string) ($hit['site_slug'] ?? ''));
        $site_name = strtolower(trim((string) ($hit['site_name'] ?? '')));
        $domain_map = [
            'economy' => 'economy.ams.com.kh',
            'education' => 'education.ams.com.kh',
            'eductaion' => 'education.ams.com.kh',
            'radio' => 'radio.ams.com.kh',
            'sport' => 'sports.ams.com.kh',
            'sports' => 'sports.ams.com.kh',
            'infotainment' => 'infotainment.ams.com.kh',
            'chivilize' => 'chivilize.ams.com.kh',
            'central' => 'central.ams.com.kh',
        ];

        if ($slug !== '' && isset($domain_map[$slug])) {
            return 'http://' . $domain_map[$slug];
        }

        if ($site_name !== '') {
            foreach ($domain_map as $key => $domain) {
                if (strpos($site_name, $key) !== false) {
                    return 'http://' . $domain;
                }
            }
        }

        return '';
    }
}

if (!function_exists('search_result_logo_url')) {
    function search_result_logo_url($hit)
    {
        $logo = $hit['site_logo'] ?? $hit['favicon_url'] ?? '';

        if (!empty($logo)) {
            return (string) $logo;
        }

        return get_stylesheet_directory_uri() . '/images/default-favicon.png';
    }
}

if (!function_exists('search_result_logo_is_youtube')) {
    function search_result_logo_is_youtube($hit)
    {
        foreach (['site_logo', 'favicon_url', 'url'] as $key) {
            $value = strtolower((string) ($hit[$key] ?? ''));

            if ($value !== '' && (strpos($value, 'youtube.com') !== false || strpos($value, 'youtu.be') !== false || strpos($value, 'ytimg.com') !== false)) {
                return true;
            }
        }

        return false;
    }
}

if (!function_exists('search_site_slug_label')) {
    function search_site_slug_label($slug)
    {
        $slug = strtolower(trim((string) $slug));

        $labels = [
            'central' => 'AMS Central',
            'chivilize' => 'AMS Chivilize',
            'economy' => 'AMS Economy',
            'education' => 'AMS Education',
            'eductaion' => 'AMS Education',
            'infotainment' => 'AMS Infotainment',
            'radio' => 'AMS Radio',
            'sport' => 'AMS Sport',
            'sports' => 'AMS Sport',
        ];

        if ($slug === '') {
            return '';
        }

        if (isset($labels[$slug])) {
            return $labels[$slug];
        }

        return 'AMS ' . ucwords(str_replace(['-', '_'], ' ', $slug));
    }
}

if (!function_exists('search_filter_site_label')) {
    function search_filter_site_label($slug)
    {
        $slug = strtolower(trim((string) $slug));

        $labels = [
            '' => 'គ្រប់គេហទំព័រ',
            'central' => 'សង់ត្រាល់',
            'chivilize' => 'អរិយធម៌',
            'economy' => 'សេដ្ឋកិច្ច',
            'education' => 'អប់រំ',
            'eductaion' => 'អប់រំ',
            'infotainment' => 'ព័ត៌មានកម្សាន្ត',
            'radio' => 'វិទ្យុអប្សរា',
            'sport' => 'កីឡា',
            'sports' => 'កីឡា',
        ];

        return $labels[$slug] ?? $slug;
    }
}

if (!function_exists('search_site_display_label')) {
    function search_site_display_label($hit_site_slug, $hit_site_name)
    {
        $hit_site_slug = strtolower(trim((string) $hit_site_slug));
        $hit_site_name = trim((string) $hit_site_name);

        if ($hit_site_slug !== '') {
            return trim(preg_replace('/\s+/', ' ', search_site_slug_label($hit_site_slug)));
        }

        if ($hit_site_name === '') {
            return 'AMS';
        }

        $normalized = trim(preg_replace('/\s+/', ' ', $hit_site_name));

        if (stripos($normalized, 'AMS ') === 0 || strcasecmp($normalized, 'AMS') === 0) {
            return $normalized;
        }

        return 'AMS ' . $normalized;
    }
}

if (!function_exists('render_search_result_heading')) {
    function render_search_result_heading($count, $query)
    {
        $count = (int) $count;
        $query = trim((string) $query);
        ?>
        <div class="search-results-summary-wrap">
            <h1 class="search-results-heading search-results-summary text-lg md:text-xl font-bold text-gray-800 dark:text-white">
                <span class="gradient-text search-results-heading__label">លទ្ធផលប្រហែល</span>
                <span class="gradient-text search-results-heading__count search-results-summary__count"><?php echo $count; ?></span>
                <span class="gradient-text search-results-heading__label">សម្រាប់ការស្វែងរក</span>
                <span class="gradient-text search-results-heading__query-wrap">"<span class="search-results-heading__query search-results-summary__query"><?php echo esc_html($query); ?></span>"</span>
            </h1>
        </div>
        <?php
    }
}

?>
<?php
$tab = sanitize_text_field($_GET['tab'] ?? 'all');
?>

<link rel="stylesheet" href="<?php echo esc_url(get_stylesheet_directory_uri() . '/search.css?ver=' . filemtime(get_stylesheet_directory() . '/search.css')); ?>" type="text/css" media="all">
<script src="<?php echo esc_url(get_stylesheet_directory_uri() . '/search.js?ver=' . filemtime(get_stylesheet_directory() . '/search.js')); ?>"></script>
<section class="video-read-news">
    <div class="row panel-read-news">
        <div class="col-md-12"></div>
        <div class="col-md-8"></div>

        <div dir="ltr" data-orientation="horizontal" data-slot="tabs" class="search-tabs-shell flex flex-col gap-2 w-[100%] mx-auto">
            <div dir="ltr" data-orientation="horizontal" data-slot="tabs" class="search-tabs-inner flex flex-col gap-2 w-[90%] mx-auto">
                <?php
                $search_value = isset($_GET['s']) ? sanitize_text_field($_GET['s']) : '';

                ?>


                <form class="wrap" method="get" action="">
                    <div class="search-container">
                        <div class="search-box" id="searchBox">
                            <svg class="search-icon" viewBox="0 0 24 24" fill="none" aria-hidden="true">
                                <path d="M21 21l-4.35-4.35M17 11A6 6 0 1 1 5 11a6 6 0 0 1 12 0z"
                                    stroke="#9aa0a6" stroke-width="2" stroke-linecap="round" />
                            </svg>

                            <input class="search-input" type="text" name="s" id="searchInput"
                                placeholder="ស្វែងរក" autocomplete="off" spellcheck="false"
                                value="<?php echo esc_attr($search_value); ?>" />

                            <button type="button" class="clear-btn" id="clearBtn" title="លុប" aria-label="លុប">
                                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" aria-hidden="true">
                                    <path d="M18 6L6 18M6 6l12 12" stroke="currentColor"
                                        stroke-width="2" stroke-linecap="round" />
                                </svg>
                            </button>

                        </div>

                        <div class="dropdown" id="dropdown"></div>
                    </div>
                    <input type="hidden" id="site_slug_id" name="site_slug" value="<?php echo esc_attr($site_slug); ?>">
                    <input type="hidden" id="site_filter_applied_id" name="site_filter_applied" value="<?php echo $site_slug !== '' ? '1' : ''; ?>">
                    <input type="hidden" name="page" value="<?php echo $page; ?>">



                </form>




               <div role="tablist" aria-orientation="horizontal" data-slot="tabs-list" class="search-tabs-bar text-muted-foreground items-center rounded-lg p-[3px] flex w-full md:w-fit justify-start gap-6 bg-background overflow-x-auto whitespace-nowrap no-scrollbar md:overflow-visible md:whitespace-normal md:justify-center px-2" tabindex="0" data-orientation="horizontal" style="outline: none;">
                    <!-- Tabs -->
                    <div data-slot="tabs-list" class="search-tabs-nav">
                        <a class="font-semibold munu-font tab-link"
                            role="tab"
                            aria-selected="<?php echo ($tab == 'all') ? 'true' : 'false'; ?>"
                            href="<?php echo esc_url(add_query_arg(['s' => $q, 'limit' => $limit, 'page' => $page, 'tab' => 'all', 'site_slug' => $site_slug, 'site_filter_applied' => $site_slug !== '' ? '1' : ''], home_url('/'))); ?>">
                            ទូទៅ
                        </a>

                        <a class="font-semibold munu-font tab-link"
                            role="tab"
                            aria-selected="<?php echo ($tab == 'post') ? 'true' : 'false'; ?>"
                            href="<?php echo esc_url(add_query_arg(['s' => $q, 'limit' => $limit, 'page' => $page, 'tab' => 'post', 'site_slug' => $site_slug, 'site_filter_applied' => $site_slug !== '' ? '1' : ''], home_url('/'))); ?>">
                            អត្ថបទ
                        </a>

                        <a class="font-semibold munu-font tab-link"
                            role="tab"
                            aria-selected="<?php echo ($tab == 'images') ? 'true' : 'false'; ?>"
                            href="<?php echo esc_url(add_query_arg(['s' => $q, 'limit' => $limit, 'page' => $page, 'tab' => 'images', 'site_slug' => $site_slug, 'site_filter_applied' => $site_slug !== '' ? '1' : ''], home_url('/'))); ?>">
                            រូបភាព
                        </a>

                        <a class="font-semibold munu-font tab-link"
                            role="tab"
                            aria-selected="<?php echo ($tab == 'video') ? 'true' : 'false'; ?>"
                            href="<?php echo esc_url(add_query_arg(['s' => $q, 'limit' => $limit, 'page' => $page, 'tab' => 'video', 'site_slug' => $site_slug, 'site_filter_applied' => $site_slug !== '' ? '1' : ''], home_url('/'))); ?>">
                            វីឌីអូ
                        </a>
                    </div>

                    <!-- ✅ Combobox (ONLY ONE id="site-filter") -->
                           <section class="search-site-filter w-full max-w-xs mx-auto text-primary">
                        <div class="site-filter-wrap ">
                            <button type="button" id="site-filter" aria-expanded="false"
                                class="site-filter-btn">
                                <span id="site-filter-value" class="site-filter-label">
                                    <?php
                                    echo esc_html(search_filter_site_label($site_slug));
                                    ?>
                                </span>

                                <svg
                                    id="filter-arrow"
                                    class="arrow-icon"
                                    width="6"
                                    height="8"
                                    viewBox="0 0 6 8"
                                    fill="none"
                                    xmlns="http://www.w3.org/2000/svg"
                                    aria-hidden="true">
                                    <path d="M0 8V0L6 4L0 8Z" fill="#28398D" />
                                </svg>
                            </button>
                        </div>


                        <div id="site-filter-content" class="site-content" tabindex="-1">
                            <div id="site-filter-menu" class="hidden bg-white shadow-lg rounded-lg p-2" role="listbox">

                                <!-- Option: All Sites -->
                                <a href="<?php echo esc_url(add_query_arg(['s' => $q, 'limit' => $limit, 'page' => $page, 'tab' => $tab, 'site_slug' => '', 'site_filter_applied' => ''], home_url('/'))); ?>"
                                    data-value=""
                                    class="filter-item<?php echo empty($site_slug) ? ' is-selected active' : ''; ?> flex justify-between items-center px-3 py-2 hover:bg-gray-100 rounded">
                                    <span>គ្រប់គេហទំព័រ</span>
                                    <?php if (empty($site_slug)) : ?>
                                        <span class="text-blue-600 font-bold check" aria-hidden="true">
                                            <svg width="14" height="14" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M3 8.5L6.5 12L13 4.5" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                            </svg>
                                        </span>
                                    <?php endif; ?>
                                </a>

                                    <?php
                                    $sites = ams_get_sites_api();

                                    foreach ($sites as $key => $iteam) {
                                        $slug = strtolower($iteam['slug']);
                                        $is_active = ($site_slug === $iteam['slug']);
                                    ?>
                                        <a href="<?php echo esc_url(add_query_arg(['s' => $q, 'limit' => $limit, 'page' => $page, 'tab' => $tab, 'site_slug' => $iteam['slug'], 'site_filter_applied' => '1'], home_url('/'))); ?>"
                                            data-value="<?php echo esc_attr($iteam['slug']); ?>"
                                            class="filter-item<?php echo $is_active ? ' is-selected active' : ''; ?> flex justify-between items-center px-3 py-2 hover:bg-gray-100 rounded">

                                            <!-- Label -->
                                            <span>
                                                <?php
                                                echo esc_html(search_filter_site_label($slug));
                                                ?>
                                            </span>

                                            <!-- Tick (ONLY if active) -->
                                            <?php if ($is_active) : ?>
                                                <span class="text-blue-600 font-bold check" aria-hidden="true">
                                                    <svg width="14" height="14" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <path d="M3 8.5L6.5 12L13 4.5" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                                    </svg>
                                                </span>
                                            <?php endif; ?>

                                        </a>
                                    <?php } ?>
                            </div>
                        </div>
                    </section>


                </div>
             <div class="flex justify-center items-center gap-3 mt-12 border-t pt-6 flex-wrap" style="padding-left: 0px;margin-top: 65px;margin-inline: initial;justify-content: flex-start;padding-top: 10px;">
                    <div class="mt-5"></div>
                    <!-- loop item -->
                    <div data-state="active"
                        data-orientation="horizontal"
                        role="tabpanel"
                        aria-labelledby="radix-_r_2_-trigger-all"
                        id="radix-_r_2_-content-all"
                        tabindex="0"
                        data-slot="tabs-content"
                        class="flex-1 outline-none">

                        <?php if ($tab == 'all') { ?>
                          <section class="space-y21" style="  padding-left: -45px;  margin-left: -2px;">

                                <?php if (!empty($data['hits']) && is_array($data['hits'])) { ?>

                                <?php render_search_result_heading(count($data['hits'] ?? []), $q); ?>

                                    <?php foreach ($data['hits'] as $hit) { ?>

                                        <div>
                                            <a target="_blank" rel="noopener noreferrer" href="<?php echo $hit['url']; ?>">

                                           <div class="flex p-3 space-x-3 items-center" style="margin-left: -13px;margin-top: -20px;">

                                                    <?php $is_youtube_logo = search_result_logo_is_youtube($hit); ?>
                                                    <span class="search-result-logo-badge<?php echo $is_youtube_logo ? ' search-result-logo-badge--plain' : ''; ?> relative flex shrink-0 overflow-hidden rounded-full">
                                                        <?php $favicon = esc_url(search_result_logo_url($hit)); ?>
                                                        <img class="search-result-logo-badge__image<?php echo $is_youtube_logo ? ' search-result-logo-badge__image--plain' : ''; ?> aspect-square"
                                                            src="<?php echo $favicon; ?>"
                                                            alt="favicon">
                                                    </span>
                                                    <div class="overflow-hidden">
                                                        <div class="flex space-x-1 items-center flex-wrap text-sm md:text-md mb-1">
                                                            <p class="font-medium gradient-text">
                                                                <?php
                                                                $hit_site_slug = strtolower((string) ($hit['site_slug'] ?? ''));
                                                                $hit_site_name = trim((string) ($hit['site_name'] ?? ''));
                                                                echo esc_html(search_site_display_label($hit_site_slug, $hit_site_name));
                                                                ?>
                                                            </p>

                                                        </div>

                                                        <?php $result_domain = search_result_domain_label($hit); ?>
                                                        <?php if ($result_domain !== '') : ?>
                                                            <p class="text-xs text-muted-foreground truncate">
                                                                <?php echo esc_html($result_domain); ?>
                                                            </p>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>

                                              <article class="space-y-1 group cursor-pointer p-3 transition -mt-5" style="  padding-bottom: 8px;  padding-top: 5px;">
                                               <h3 class="text-md md:text-xl font-bold hover:underline text-primary line-clamp-2 md:line-clamp-1" style="padding-top: -1px;margin-left: -7px;">
                                                        <?php echo $hit['title']; ?>
                                                    </h3>
                                                </article>

                                             <div class="flex-row space-x-1 items-center text-md text-primary p-3 -mt-5" style="padding-top: 5px;">
                                        <p class="text-[13px] md:text-[16px] text-[#555555] dark:text-gray-400 line-clamp-2 search-result-card__excerpt" style="line-height: 1.5;margin-top:0px;margin-left: -7px;">
                                                        <?php echo $hit['content']; ?>
                                                    </p>

                                               <p class="mt-1" style="font-size: 15px;margin-left: -6px;margin-top: -9px;margin-bottom: 10px;">
           
                                                        កាលបរិច្ឆេទ ៖
                                                        <span class="font-semibold gradient-text">
                                                            <?php echo khmer_date($hit['posted_at']); ?>
                                                        </span>
                                                    </p>
                                                </div>

                                            </a>
                                        </div>


                                    <?php } ?>
                                    <!-- Pagination -->
                                    <div class="search-pagination-wrap" style="padding-bottom: 25px;">
                                        <?php
                                        $total_pages = $data['total_pages'];
                                        $pagination = build_pagination(
                                            current_page: $page,
                                            total_pages: $total_pages,
                                            q: $q,
                                            tab: $tab,
                                            site_slug: $site_slug,
                                            limit: $limit,
                                            site_filter_applied: $site_slug !== ''
                                        );

                                        echo '<div class="search-pagination">';
                                        foreach ($pagination as $p) {
                                            if (isset($p['url'])) {
                                                $is_control = !is_numeric((string) $p['label']);
                                                $class = 'search-pagination__link';
                                                if ($p['page'] == $page) {
                                                    $class .= ' is-active';
                                                }
                                                if ($is_control) {
                                                    $class .= ' search-pagination__link--control';
                                                }
                                                echo '<a class="' . $class . '" href="' . htmlspecialchars($p['url']) . '">' . htmlspecialchars($p['label']) . '</a>';
                                            } else {
                                                echo '<span class="search-pagination__ellipsis">' . htmlspecialchars($p['label']) . '</span>';
                                            }
                                        }
                                        echo '</div>';
                                        ?>
                                    </div>

                                <?php } else { ?>
                                    <!-- No Result Section -->
                                    <?php render_search_result_heading(0, $q); ?>
                                    <div class="text-center py-16 search-empty-state">
                                        <span class="text-xl gradient-text font-bold search-empty-state__title">
                                            រកមិនឃើញលទ្ធផលសម្រាប់សំណួររបស់អ្នកទេ
                                        </span>

                                        <p class="text-md mt-2 text-primary search-empty-state__subtitle">
                                            សាកល្បងប្រើពាក្យផ្សេង
                                        </p>

                                        <div class="flex justify-center mt-3 search-empty-state__media">
                                            <iframe
                                                src="https://lottie.host/embed/75c73496-b14e-452a-ab1e-9ec55176eebd/wym6ydhzIf.lottie"
                                                class="lottie-empty-frame"
                                                frameborder="0"
                                                allowfullscreen>
                                            </iframe>
                                        </div>
                                    </div>

                                <?php } ?>

                            </section>



                        <?php }
                        if ($tab == 'post') { ?>
                            <!-- post -->
                            <section class="space-y-4">
                                <?php if (!empty($data['hits']) && is_array($data['hits'])) { ?>
                                    <?php render_search_result_heading((int) ($data['total'] ?? 0), $q); ?>

                                    <?php foreach ($data['hits'] as $hit) { ?>
                                        <div>
                                            <a target="_blank" rel="noopener noreferrer" href="<?php echo htmlspecialchars($hit['url']); ?>">
                                         <div class="flex p-3 space-x-3 items-center" style="margin-top: -18px;padding-left: 0px;">
                                                  <?php $is_youtube_logo = search_result_logo_is_youtube($hit); ?>
                                                  <span class="search-result-logo-badge<?php echo $is_youtube_logo ? ' search-result-logo-badge--plain' : ''; ?> relative flex shrink-0 overflow-hidden rounded-full" style="margin-top:-6px;">
                                                        <?php $favicon = esc_url(search_result_logo_url($hit)); ?>
                                                        <img class="search-result-logo-badge__image<?php echo $is_youtube_logo ? ' search-result-logo-badge__image--plain' : ''; ?> aspect-square"
                                                            src="<?php echo $favicon; ?>"
                                                            alt="favicon">
                                                    </span>
                                                    <div class="overflow-hidden">
                                                        <div class="flex space-x-1 items-center flex-wrap text-sm md:text-md mb-1">
                                                            <p class="font-medium gradient-text">
                                                                <?php
                                                                $hit_site_slug = strtolower((string) ($hit['site_slug'] ?? ''));
                                                                $hit_site_name = trim((string) ($hit['site_name'] ?? ''));
                                                                echo esc_html(search_site_display_label($hit_site_slug, $hit_site_name));
                                                                ?>
                                                            </p>

                                                            
                                                        </div>
                                                    </div>
                                                </div>
                                                <a href="<?php echo esc_url($hit['url'] ?? '#'); ?>"
                                                    class="block group cursor-pointer hover:bg-gray-50 transition">
                                                   <article class="flex items-start justify-between gap-2 p-3 sm:gap-3 sm:p-4" style="display: flex;/* padding-right: 4px; */margin-top: -26px;padding-left: 2px;">


                                                        <!-- Text block (left) -->
                                                        <div class="flex-1 min-w-0 flex flex-col gap-1">

                                                        <h3 class="font-bold text-primary line-clamp-1 leading-snug text-[12px] sm:text-[13px] md:text-[15px]   lg:text-[17px] xl:text-[19px]" style="/* line-height: 2.2; */">
                                                                <?php echo esc_html($hit['title'] ?? ''); ?>
                                                            </h3>

                                                          <p class="text-[13px] md:text-[16px] text-[#555555] dark:text-gray-400 line-clamp-2 search-result-card__excerpt" style="line-height: 1.5;margin-top: -10px;">
                                                                <?php echo esc_html($hit['content'] ?? ''); ?>
                                                            </p>

                                                     <p class="text-primary text-[11px] sm:text-[12px] md:text-[13px]" style=" font-size: 15px;margin-top:-13px;">
           
                                                                កាលបរិច្ឆេទ ៖
                                                                <span class="font-semibold gradient-text">
                                                                    <?php echo khmer_date($hit['posted_at']); ?>
                                                                </span>
                                                            </p>

                                                        </div>

                                                        <!-- Thumbnail (right) -->
                                                        <?php $image = esc_url($hit['thumbnail_url'] ?? $hit['featured_image'] ?? ''); ?>
                                                        <?php if ($image) : ?>
                                                            <div class="flex-shrink-0 w-[130px] sm:w-[160px]">
                                                                <img
                                                                    src="<?php echo $image; ?>"
                                                                    alt="<?php echo esc_attr($hit['title'] ?? ''); ?>"

                                                                     class="w-90 h-12 md:w-90 md:h-14 object-cover rounded-md" style="width: 123px;height: 97px;margin-top: -34px;">
                                                            </div>
                                                        <?php endif; ?>

                                                    </article>
                                                </a>
                                        </div>
                                    <?php } ?>

                                    <!-- Pagination -->
                                    <div class="search-pagination-wrap" style="padding-bottom: 25px;">
                                        <?php
                                        $total_pages = $data['total_pages'];
                                        $pagination = build_pagination(
                                            current_page: $page,
                                            total_pages: $total_pages,
                                            q: $q,
                                            tab: $tab,
                                            site_slug: $site_slug,
                                            limit: $limit,
                                            site_filter_applied: $site_slug !== ''
                                        );

                                        echo '<div class="search-pagination">';
                                        foreach ($pagination as $p) {
                                            if (isset($p['url'])) {
                                                $is_control = !is_numeric((string) $p['label']);
                                                $class = 'search-pagination__link';
                                                if ($p['page'] == $page) {
                                                    $class .= ' is-active';
                                                }
                                                if ($is_control) {
                                                    $class .= ' search-pagination__link--control';
                                                }
                                                echo '<a class="' . $class . '" href="' . htmlspecialchars($p['url']) . '">' . htmlspecialchars($p['label']) . '</a>';
                                            } else {
                                                echo '<span class="search-pagination__ellipsis">' . htmlspecialchars($p['label']) . '</span>';
                                            }
                                        }
                                        echo '</div>';
                                        ?>
                                    </div>

                                <?php } else { ?>
                                    <!-- No Result Section -->
                                    <?php render_search_result_heading(0, $q); ?>

                                    <div class="text-center py-16 search-empty-state">
                                        <span class="text-xl gradient-text font-bold search-empty-state__title">
                                            រកមិនឃើញលទ្ធផលសម្រាប់សំណួររបស់អ្នកទេ
                                        </span>

                                        <p class="text-md mt-2 text-primary search-empty-state__subtitle">
                                            សាកល្បងប្រើពាក្យផ្សេង
                                        </p>

                                        <div class="flex justify-center mt-3 search-empty-state__media">
                                            <iframe
                                                src="https://lottie.host/embed/75c73496-b14e-452a-ab1e-9ec55176eebd/wym6ydhzIf.lottie"
                                                class="lottie-empty-frame"
                                                frameborder="0"
                                                allowfullscreen>
                                            </iframe>
                                        </div>
                                    </div>
                                <?php } ?>

                            </section>

                  <?php }
if ($tab == 'images') { ?>
    <!-- Image -->
    <section class="relative flex w-full gap-4 image-results-layout">

        <?php if (!empty($data['hits']) && is_array($data['hits'])) : ?>

            <script>
                const allHits = <?php echo wp_json_encode(array_map(function ($hit) {
                                    return [
                                        'image'     => esc_url($hit['thumbnail_url'] ?? $hit['featured_image'] ?? ''),
                                        'site_name' => esc_html($hit['site_name'] ?? 'AMS'),
                                        'site_logo' => esc_url($hit['site_logo'] ?? $hit['favicon_url'] ?? ''),
                                        'title'     => wp_strip_all_tags($hit['title'] ?? ''),
                                        'url'       => esc_url($hit['url'] ?? '#'),
                                    ];
                                }, $data['hits'])); ?>;
            </script>

            <div class="flex-1 image-results-main">

                <!-- Results count -->
                <?php render_search_result_heading((int) ($data['total'] ?? 0), $q); ?>

                <!-- Masonry Grid -->
                <div class="grid grid-cols-3 similar-images-grid" style="gap:2px;">
                    <?php foreach ($data['hits'] as $index => $hit) :
                        $image     = esc_url($hit['thumbnail_url'] ?? $hit['featured_image'] ?? '');
                        $site_name = esc_html($hit['site_name'] ?? 'AMS');
                        $site_logo = esc_url($hit['site_logo'] ?? $hit['favicon_url'] ?? '');
                        $site_label = (stripos($site_name, 'AMS') === 0) ? $site_name : 'AMS ' . (!empty($site_name) ? $site_name : 'AMS');
                        $post_id   = (int) ($hit['wp_post_id'] ?? 0);
                        $url       = esc_url($hit['url'] ?? '#');
                        $title     = esc_html($hit['title'] ?? '');
                    ?>
                        <div class="break-inside-avoid rounded-lg group transition-all min-w-0 image-result-card">
                            <button type="button"
                                data-id="<?php echo $post_id; ?>"
                                data-index="<?php echo (int) $index; ?>"
                                onclick="openPanel(allHits, <?php echo (int) $index; ?>)"
                                style="padding:2px; width:100%;"
                                class="search-image-card-media w-full rounded-lg overflow-hidden border-2 transition btn-image simila-image hover:border-blue-300 border-transparent">
                                <?php if (!empty($image)) : ?>
                                    <img alt="Media image" loading="lazy" width="600" height="800" decoding="async" data-nimg="1" class="search-image-card-photo w-full h-full object-cover rounded-lg group-hover:opacity-75 transition-opacity" 
                                        src="<?php echo $image; ?>">
                                <?php else : ?>
                                    <div class="search-image-card-empty w-full h-full rounded-md bg-gray-200"></div>
                                <?php endif; ?>
                            </button>

                            <div style="display:flex; align-items:center; gap:5px; margin-top:8px;">
                                <?php if (!empty($site_logo)) : ?>
                                    <img src="<?php echo $site_logo; ?>"
                                        alt="<?php echo $site_name; ?> logo"
                                        style="width:12px; height:12px; border-radius:50%; object-fit:cover; flex-shrink:0;">
                                <?php else : ?>
                                    <svg width="12" height="12" viewBox="0 0 12 12" xmlns="http://www.w3.org/2000/svg" style="flex-shrink:0;">
                                        <defs>
                                            <linearGradient id="ams-grad-<?php echo $post_id; ?>" x1="0" y1="0" x2="0.6" y2="1">
                                                <stop offset="0%" stop-color="#BB2C2B" />
                                                <stop offset="24%" stop-color="#A42221" />
                                                <stop offset="61%" stop-color="#871C1B" />
                                                <stop offset="96%" stop-color="#600B0B" />
                                            </linearGradient>
                                        </defs>
                                        <circle cx="6" cy="6" r="6" fill="url(#ams-grad-<?php echo $post_id; ?>)" />
                                        <rect x="1" y="4.1" width="3.46" height="3.79" fill="white" />
                                        <rect x="4.79" y="4.1" width="3.40" height="3.79" fill="white" />
                                        <rect x="8.80" y="4.1" width="2.20" height="3.79" fill="white" />
                                    </svg>
                                <?php endif; ?>

                                <span class="similar-post-card__site" style="color:#555555; font-size:12px; font-family:'Roboto',sans-serif; font-weight:400; line-height:24px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">
                                    <?php echo $site_label; ?>
                                </span>
                            </div>

                            <p class="line-clamp-2 mt-0.5 similar-post-card__title" style="color:#28398D;font-size:16px;font-family:'Battambang',sans-serif;font-weight:700;line-height:1.5;word-wrap:break-word;margin-bottom:0;">
                                <?php echo $title; ?>
                            </p>
                        </div>
                    <?php endforeach; ?>
                </div>

                <!-- Pagination -->
            <div class="search-pagination-wrap" style="padding-bottom: 25px;">
                    <?php
                    $total_pages = $data['total_pages'] ?? 1;
                    $pagination  = build_pagination(
                        current_page: $page,
                        total_pages: $total_pages,
                        q: $q,
                        tab: $tab,
                        site_slug: $site_slug,
                        limit: $limit,
                        site_filter_applied: $site_slug !== ''
                    );

                    echo '<div class="search-pagination">';
                    foreach ($pagination as $p) {
                        if (isset($p['url'])) {
                            $is_control = !is_numeric((string) $p['label']);
                            $class = 'search-pagination__link';
                            if ($p['page'] == $page) {
                                $class .= ' is-active';
                            }
                            if ($is_control) {
                                $class .= ' search-pagination__link--control';
                            }

                            echo '<a class="' . $class . '" href="' . esc_url($p['url']) . '">' . esc_html($p['label']) . '</a>';
                        } else {
                            echo '<span class="search-pagination__ellipsis">' . esc_html($p['label']) . '</span>';
                        }
                    }
                    echo '</div>';
                    ?>
                </div>

            </div><!-- /.flex-1 -->

            <!-- Side Panel -->
            <div id="similaform_id"
                class="bg-white dark:bg-gray-900 z-50 overflow-y-auto flex flex-col hide-form similar-form-panel">
                                

                <!-- Top bar -->
                <div class="panel-top-bar">

                    <div style="display:flex; align-items:center; gap:6px;">
                        <div id="panel-site-dot"
                            style="width:16px; height:16px; flex-shrink:0; display:flex; align-items:center; justify-content:center;"></div>
                        <span id="panel-site-name"
                            style="font-size:12px; color:#282828; font-family:'Roboto',sans-serif; font-weight:400;"></span>
                    </div>

                    <div style="display:flex; align-items:center; gap:6px;">
                        <button id="btn-prev" onclick="navigatePanel(-1)"
                            style="width:24px; height:24px; display:flex; align-items:center; justify-content:center; border:none; background:none; cursor:pointer; border-radius:4px; padding:0;"
                            onmouseover="this.style.background='#f0f0ee'" onmouseout="this.style.background='none'">
                            <svg xmlns="http://www.w3.org/2000/svg" width="6" height="12" viewBox="0 0 6 12" fill="none">
                                <path d="M5.47852 11.4785L0.478516 5.97852L5.47852 0.478516" stroke="#282828" stroke-width="0.956835" stroke-linecap="round" stroke-linejoin="round" />
                            </svg>
                        </button>

                        <button id="btn-next" onclick="navigatePanel(1)"
                            style="width:24px; height:24px; display:flex; align-items:center; justify-content:center; border:none; background:none; cursor:pointer; border-radius:4px; padding:0;"
                            onmouseover="this.style.background='#f0f0ee'" onmouseout="this.style.background='none'">
                            <svg xmlns="http://www.w3.org/2000/svg" width="6" height="12" viewBox="0 0 6 12" fill="none">
                                <path d="M0.478516 0.478516L5.47852 5.97852L0.478516 11.4785" stroke="#282828" stroke-width="0.956835" stroke-linecap="round" stroke-linejoin="round" />
                            </svg>
                        </button>

                        <button id="btn_close" class="absolute top-4 right-4 z-10" style="right:0;border-top-width:0;top:37px;border-right-width:0;">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-x w-8 h-8 bg-red-500 p-2 rounded-full text-white hover:bg-red-600 transition" aria-hidden="true">
                                <path d="M18 6 6 18"></path>
                                <path d="m6 6 12 12"></path>
                            </svg>
                        </button>
                    </div>
                </div>

                <!-- Header: image + buttons + title — never scrolls -->
                <div class="similar-form-panel__header">

                <!-- Main image -->
                <div class="w-full similar-form-panel__media">
                    <img id="panel-main-img"
                        class="similar-form-panel__image"
                        alt="Selected media"
                        decoding="async"
                        src="">
                </div>

                <!-- Buttons + title (inside header) -->

                    <!-- Buttons -->
                   <div class="similar-form-panel__actions">
                        <div id="share-menu-wrap" style="position:relative; overflow:visible; width:100%;">
                            <button type="button" id="bnt_share"
                                class="similar-form-panel__action-btn similar-form-panel__action-btn--share"
                                style="display:flex; align-items:center; justify-content:center; gap:9px; width:100%; height:41px; border-radius:9px; background:#BFBFBF; border:none; cursor:pointer; font-size:13px; font-weight:600; font-family:'Battambang',sans-serif; color:#000000;">
                                ចែករំលែក
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none"
                                    stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                    <polyline points="12 3 12 15" />
                                    <polyline points="7 8 12 3 17 8" />
                                    <path d="M20 15v4a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2v-4" />
                                </svg>
                            </button>

                            <!-- Share dropdown -->
                      <div id="py-2" class="hide-form" style="background:#fff;border:0.5px solid #e0e0dc;border-radius:10px;box-shadow:0 4px 20px rgba(0,0,0,0.12);overflow:clip;position:absolute;top:-236px;left:0;margin:0;z-index:10020;">
                                <button type="button" data-network="telegram" class="w-full flex items-center gap-4 px-5 py-3 hover:bg-gray-100 dark:hover:bg-gray-700 transition">
                                    <svg fill="#139bd5" viewBox="0 0 496 512" class="w-6 h-6">
                                        <path d="M248,8C111.033,8,0,119.033,0,256S111.033,504,248,504,496,392.967,496,256,384.967,8,248,8ZM362.952,176.66c-3.732,39.215-19.881,134.378-28.1,178.3-3.476,18.584-10.322,24.816-16.948,25.425-14.4,1.326-25.338-9.517-39.287-18.661-21.827-14.308-34.158-23.215-55.346-37.177-24.485-16.135-8.612-25,5.342-39.5,3.652-3.793,67.107-61.51,68.335-66.746.153-.655.3-3.1-1.154-4.384s-3.59-.849-5.135-.5q-3.283.746-104.608,69.142-14.845,10.194-26.894,9.934c-8.855-.191-25.888-5.006-38.551-9.123-15.531-5.048-27.875-7.717-26.8-16.291q.84-6.7,18.45-13.7,108.446-47.248,144.628-62.3c68.872-28.647,83.183-33.623,92.511-33.789,2.052-.034,6.639.474,9.61,2.885a10.452,10.452,0,0,1,3.53,6.716A43.765,43.765,0,0,1,362.952,176.66Z" />
                                    </svg>
                                    <span>Telegram</span>
                                </button>
                                <div style="height:0.5px; background:#f0f0ec;"></div>

                                <button type="button" data-network="facebook" class="w-full flex items-center gap-4 px-5 py-3 hover:bg-gray-100 dark:hover:bg-gray-700 transition">
                                    <svg fill="#2f67e5" viewBox="0 0 512 512" class="w-6 h-6">
                                        <path d="M512 256C512 114.6 397.4 0 256 0S0 114.6 0 256C0 376 82.7 476.8 194.2 504.5V334.2H141.4V256h52.8V222.3c0-87.1 39.4-127.5 125-127.5c16.2 0 44.2 3.2 55.7 6.4V172c-6-.6-16.5-1-29.6-1c-42 0-58.2 15.9-58.2 57.2V256h83.6l-14.4 78.2H287V510.1C413.8 494.8 512 386.9 512 256h0z" />
                                    </svg>
                                    <span>Facebook</span>
                                </button>
                                <div style="height:0.5px; background:#f0f0ec;"></div>

                                <button type="button" data-network="twitter" class="w-full flex items-center gap-4 px-5 py-3 hover:bg-gray-100 dark:hover:bg-gray-700 transition">
                                    <svg fill="#000" viewBox="0 0 448 512" class="w-6 h-6">
                                        <path d="M64 32C28.7 32 0 60.7 0 96V416c0 35.3 28.7 64 64 64H384c35.3 0 64-28.7 64-64V96c0-35.3-28.7-64-64-64H64zm297.1 84L257.3 234.6 379.4 396H283.8L209 298.1 123.3 396H75.8l111-126.9L69.7 116h98l67.7 89.5L313.6 116h47.5zM323.3 367.6L153.4 142.9H125.1L296.9 367.6h26.3z" />
                                    </svg>
                                    <span>X (Twitter)</span>
                                </button>
                                <div style="height:0.5px; background:#f0f0ec;"></div>

                                <button type="button" data-network="whatsapp" class="w-full flex items-center gap-4 px-5 py-3 hover:bg-gray-100 dark:hover:bg-gray-700 transition">
                                    <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="text-[#00cf6e] w-8 h-8" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M260.062 32C138.605 32 40.134 129.701 40.134 250.232c0 41.23 11.532 79.79 31.559 112.687L32 480l121.764-38.682c31.508 17.285 67.745 27.146 106.298 27.146C381.535 468.464 480 370.749 480 250.232 480 129.701 381.535 32 260.062 32zm109.362 301.11c-5.174 12.827-28.574 24.533-38.899 25.072-10.314.547-10.608 7.994-66.84-16.434-56.225-24.434-90.052-83.844-92.719-87.67-2.669-3.812-21.78-31.047-20.749-58.455 1.038-27.413 16.047-40.346 21.404-45.725 5.351-5.387 11.486-6.352 15.232-6.413 4.428-.072 7.296-.132 10.573-.011 3.274.124 8.192-.685 12.45 10.639 4.256 11.323 14.443 39.153 15.746 41.989 1.302 2.839 2.108 6.126.102 9.771-2.012 3.653-3.042 5.935-5.961 9.083-2.935 3.148-6.174 7.042-8.792 9.449-2.92 2.665-5.97 5.572-2.9 11.269 3.068 5.693 13.653 24.356 29.779 39.736 20.725 19.771 38.598 26.329 44.098 29.317 5.515 3.004 8.806 2.67 12.226-.929 3.404-3.599 14.639-15.746 18.596-21.169 3.955-5.438 7.661-4.373 12.742-2.329 5.078 2.052 32.157 16.556 37.673 19.551 5.51 2.989 9.193 4.529 10.51 6.9 1.317 2.38.901 13.531-4.271 26.359z"></path>
                                    </svg>
                                    <span style="width:65px;height:72px;padding-left:13px;">WhatsApp</span>
                                </button>
                                <div style="height:0.5px; background:#f0f0ec;"></div>

                                <button type="button" data-network="copy" class="w-full flex items-center gap-4 px-5 py-3 hover:bg-gray-100 dark:hover:bg-gray-700 transition">
                                    <svg viewBox="0 0 512 512" class="w-6 h-6" fill="none" stroke="#333" stroke-width="48" stroke-linecap="round" stroke-linejoin="round">
                                        <path d="M200.66 352H144a96 96 0 0 1 0-192h55.41m113.18 0H368a96 96 0 0 1 0 192h-56.66m-142.27-96h175.86" />
                                    </svg>
                                    <span>ចម្លងតំណ</span>
                                </button>
                            </div>
                        </div>

                        <a id="idwach" target="_blank" href="#"
                            class="similar-form-panel__action-btn similar-form-panel__action-btn--watch"
                            style="display:flex; align-items:center; justify-content:center; gap:9px; width:100%; height:41px; border-radius:9px; background:linear-gradient(103deg,#28398D 1.27%,#7B2F6F 32.4%,#A32237 64.59%,#FF974D 111.76%); text-decoration:none; font-size:13px; font-weight:600; font-family:'Battambang',sans-serif; color:#fff !important;">
                            មើលទំព័រដើម
                            <svg xmlns="http://www.w3.org/2000/svg" width="7" height="11" viewBox="0 0 7 11" fill="none">
                                <path d="M0.91004 0.910645L5.46289 5.4635L0.91004 10.0163" stroke="white" stroke-width="1.82114" stroke-linecap="round" stroke-linejoin="round" />
                            </svg>
                        </a>
                    </div>

                    <!-- Title -->
                    <h2 id="txt-title"
                        style="font-size:20px; color:#28398D; line-height:1.6; font-family:'Battambang',sans-serif; font-weight:700; margin:8px 0 -3px;">
                    </h2>

                </div><!-- /.similar-form-panel__header -->

                <!-- Body: related images only — scrolls -->
                 <div style="padding:10px 14px 0px;" >
                     <!-- Related -->
                    <p style="font-size:15px; font-weight:600; color:#28398D; font-family:'Battambang',sans-serif; margin-bottom:10px;">
                        រូបភាពទាក់ទង៖
                    </p>
                </div>
                <div class="similar-form-panel__body" style="padding:10px 14px 20px;">

                   
                   
                    <div class="grid grid-cols-3 similar-images-grid" style="gap:2px;">
                      <?php foreach ($data['hits'] as $index => $hit) :
                        $image     = esc_url($hit['thumbnail_url'] ?? $hit['featured_image'] ?? '');
                        $site_name = esc_html($hit['site_name'] ?? 'AMS');
                        $site_logo = esc_url($hit['site_logo'] ?? $hit['favicon_url'] ?? '');
                        $site_label = (stripos($site_name, 'AMS') === 0) ? $site_name : 'AMS ' . (!empty($site_name) ? $site_name : 'AMS');
                        $post_id   = (int) ($hit['wp_post_id'] ?? 0);
                        $url       = esc_url($hit['url'] ?? '#');
                        $title     = esc_html($hit['title'] ?? '');
                    ?>
                        <div class="break-inside-avoid rounded-lg group transition-all min-w-0 image-result-card">
                            <button type="button"
                                data-id="<?php echo $post_id; ?>"
                                data-index="<?php echo (int) $index; ?>"
                                onclick="openPanel(allHits, <?php echo (int) $index; ?>)"
                                style="padding:2px; width:100%;"
                                class="search-image-card-media w-full rounded-lg overflow-hidden border-2 transition btn-image simila-image hover:border-blue-300 border-transparent">
                                <?php if (!empty($image)) : ?>
                                    <img alt="Media image" loading="lazy" width="600" height="800" decoding="async" data-nimg="1" class="search-image-card-photo w-full h-full object-cover rounded-lg group-hover:opacity-75 transition-opacity" 
                                        src="<?php echo $image; ?>">
                                <?php else : ?>
                                    <div class="search-image-card-empty w-full h-full rounded-md bg-gray-200"></div>
                                <?php endif; ?>
                            </button>

                            <div style="display:flex; align-items:center; gap:5px; margin-top:8px;">
                                <?php if (!empty($site_logo)) : ?>
                                    <img src="<?php echo $site_logo; ?>"
                                        alt="<?php echo $site_name; ?> logo"
                                        style="width:12px; height:12px; border-radius:50%; object-fit:cover; flex-shrink:0;">
                                <?php else : ?>
                                    <svg width="12" height="12" viewBox="0 0 12 12" xmlns="http://www.w3.org/2000/svg" style="flex-shrink:0;">
                                        <defs>
                                            <linearGradient id="ams-grad-<?php echo $post_id; ?>" x1="0" y1="0" x2="0.6" y2="1">
                                                <stop offset="0%" stop-color="#BB2C2B" />
                                                <stop offset="24%" stop-color="#A42221" />
                                                <stop offset="61%" stop-color="#871C1B" />
                                                <stop offset="96%" stop-color="#600B0B" />
                                            </linearGradient>
                                        </defs>
                                        <circle cx="6" cy="6" r="6" fill="url(#ams-grad-<?php echo $post_id; ?>)" />
                                        <rect x="1" y="4.1" width="3.46" height="3.79" fill="white" />
                                        <rect x="4.79" y="4.1" width="3.40" height="3.79" fill="white" />
                                        <rect x="8.80" y="4.1" width="2.20" height="3.79" fill="white" />
                                    </svg>
                                <?php endif; ?>

                                <span class="similar-post-card__site" style="color:#555555; font-size:12px; font-family:'Roboto',sans-serif; font-weight:400; line-height:24px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">
                                    <?php echo $site_label; ?>
                                </span>
                            </div>

                            <p class="line-clamp-2 mt-0.5 similar-post-card__title" style="color:#28398D;font-size:16px;font-family:'Battambang',sans-serif;font-weight:700;line-height:1.5;word-wrap:break-word;margin-bottom:0;">
                                <?php echo $title; ?>
                            </p>
                        </div>
                    <?php endforeach; ?>
                </div>


                    <script>
                        (function() {
                            let panelHits = [];
                            let panelIndex = 0;

                            const panel = document.getElementById('similaform_id');
                            const shareMenu = document.getElementById('py-2');
                            const shareButton = document.getElementById('bnt_share');
                            const shareMenuWrap = document.getElementById('share-menu-wrap');
                            const closeButton = document.getElementById('btn_close');

                            function hideShareDropdown() {
                                if (shareMenu) {
                                    shareMenu.classList.add('hide-form');
                                }
                            }

                            window.openPanel = function(hits, index) {
                                panelHits = hits;
                                panelIndex = index;
                                panel.scrollTop = 0;
                                renderPanel();
                                panel.classList.remove('hide-form');
                                document.body.classList.add('panel-open');
                            };

                            window.navigatePanel = function(dir) {
                                panelIndex = (panelIndex + dir + panelHits.length) % panelHits.length;
                                panel.scrollTop = 0;
                                renderPanel();
                            };

                            function renderPanel() {
                                const hit = panelHits[panelIndex];
                                if (!hit) return;

                                const img = document.getElementById('panel-main-img');
                                img.style.opacity = '0';

                                setTimeout(function() {
                                    img.src = hit.image || '';
                                    img.style.opacity = '1';
                                }, 150);

                                document.getElementById('panel-site-name').textContent = (hit.site_name && hit.site_name.toUpperCase().startsWith('AMS'))
                                    ? hit.site_name
                                    : 'AMS ' + (hit.site_name || 'AMS');

                                const dot = document.getElementById('panel-site-dot');
                                if (hit.site_logo) {
                                    dot.innerHTML = '<img src="' + hit.site_logo + '" alt="' + (hit.site_name || '') + '" style="width:16px;height:16px;border-radius:50%;object-fit:cover;display:block;">';
                                } else {
                                    dot.innerHTML = '<svg width="16" height="16" viewBox="0 0 12 12" xmlns="http://www.w3.org/2000/svg"><defs><linearGradient id="p-grad" x1="0" y1="0" x2="0.6" y2="1"><stop offset="0%" stop-color="#BB2C2B"/><stop offset="24%" stop-color="#A42221"/><stop offset="61%" stop-color="#871C1B"/><stop offset="96%" stop-color="#600B0B"/></linearGradient></defs><circle cx="6" cy="6" r="6" fill="url(#p-grad)"/><rect x="1" y="4.1" width="3.46" height="3.79" fill="white"/><rect x="4.79" y="4.1" width="3.40" height="3.79" fill="white"/><rect x="8.80" y="4.1" width="2.20" height="3.79" fill="white"/></svg>';
                                }

                                document.getElementById('txt-title').textContent = hit.title || '';
                                document.getElementById('idwach').href = hit.url || '#';
                                document.querySelectorAll('.simila-image').forEach(function(button) {
                                    const isActive = Number(button.dataset.index) === panelIndex;
                                    button.classList.toggle('border-blue-500', isActive);
                                    button.classList.toggle('border-transparent', !isActive);
                                });
                                hideShareDropdown();
                                panel.scrollTop = 0;
                            }

                            closeButton.addEventListener('click', function() {
                                hideShareDropdown();
                                panel.classList.add('hide-form');
                                document.body.classList.remove('panel-open');
                            });

                            shareButton.addEventListener('click', function(event) {
                                event.stopPropagation();
                                shareMenu.classList.toggle('hide-form');
                            });

                            shareMenu.addEventListener('click', function(event) {
                                event.stopPropagation();
                            });

                            document.addEventListener('click', function(event) {
                                if (shareMenu.classList.contains('hide-form')) return;

                                if (shareMenuWrap && !shareMenuWrap.contains(event.target)) {
                                    hideShareDropdown();
                                }
                            });

                            function copyToClipboard(text) {
                                if (navigator.clipboard && window.isSecureContext) {
                                    return navigator.clipboard.writeText(text).then(function() {
                                        showCopyFeedback('តំណត្រូវបានចម្លង!');
                                    });
                                } else {
                                    fallbackCopy(text);
                                }
                            }

                            function fallbackCopy(text) {
                                const textArea = document.createElement('textarea');
                                textArea.value = text;
                                textArea.style.position = 'fixed';
                                textArea.style.left = '-999999px';
                                textArea.style.top = '-999999px';
                                document.body.appendChild(textArea);
                                textArea.focus();
                                textArea.select();

                                try {
                                    document.execCommand('copy');
                                    showCopyFeedback('តំណត្រូវបានចម្លង!');
                                } catch (err) {
                                    showCopyFeedback('មានបញ្ហាក្នុងការចម្លងតំណ');
                                }

                                document.body.removeChild(textArea);
                            }

                            function showCopyFeedback(message) {
                                const toast = document.createElement('div');
                                toast.textContent = message;
                                toast.style.cssText = `
                                    position: fixed;
                                    top: 20px;
                                    left: 50%;
                                    transform: translateX(-50%);
                                    background: #4CAF50;
                                    color: white;
                                    padding: 12px 24px;
                                    border-radius: 8px;
                                    font-family: 'Battambang', sans-serif;
                                    font-size: 14px;
                                    z-index: 10000;
                                    opacity: 0;
                                    transition: opacity 0.3s ease;
                                    box-shadow: 0 4px 12px rgba(0,0,0,0.15);
                                `;
                                document.body.appendChild(toast);
                                setTimeout(() => toast.style.opacity = '1', 10);
                                setTimeout(() => {
                                    toast.style.opacity = '0';
                                    setTimeout(() => document.body.removeChild(toast), 300);
                                }, 2000);
                            }

                            document.querySelectorAll('#py-2 [data-network]').forEach(function(btn) {
                                btn.addEventListener('click', function() {
                                    const network = this.dataset.network;
                                    const hit = panelHits[panelIndex];
                                    if (!hit) return;

                                    const url = encodeURIComponent(hit.url || '');
                                    const title = encodeURIComponent(hit.title || '');
                                    let shareUrl = '';

                                    switch (network) {
                                        case 'telegram':
                                            shareUrl = 'https://t.me/share/url?url=' + url + '&text=' + title;
                                            break;
                                        case 'facebook':
                                            shareUrl = 'https://www.facebook.com/sharer/sharer.php?u=' + url;
                                            break;
                                        case 'twitter':
                                            shareUrl = 'https://twitter.com/intent/tweet?url=' + url + '&text=' + title;
                                            break;
                                        case 'whatsapp':
                                            shareUrl = 'https://wa.me/?text=' + title + '%20' + url;
                                            break;
                                        case 'copy':
                                            copyToClipboard(hit.url || '');
                                            hideShareDropdown();
                                            return;
                                    }

                                    if (shareUrl) {
                                        window.open(shareUrl, '_blank', 'noopener,noreferrer');
                                        hideShareDropdown();
                                    }
                                });
                            });
                        }());
                    </script>

                </div><!-- /#similaform_id -->

        <?php else : ?>

            <?php render_search_result_heading(0, $q); ?>

            <div class="search-empty-state search-empty-state--image">
                <div class="search-empty-state__media search-empty-state__media--large">
                    <iframe src="https://lottie.host/embed/75c73496-b14e-452a-ab1e-9ec55176eebd/wym6ydhzIf.lottie"
                        class="lottie-empty-frame lottie-empty-frame--large"
                        style="border:none; background:transparent;"
                        title="No results animation"></iframe>
                </div>
                <p class="search-empty-state__title search-empty-state__title--muted">
                    មិនទាន់មានមាតិកា
                </p>
                <p class="search-empty-state__subtitle search-empty-state__subtitle--muted">
                    មិនមានរូបភាពសម្រាប់
                    «<strong class="search-empty-state__query"><?php echo esc_html($q); ?></strong>»
                </p>
            </div>

        <?php endif; ?>

    </section>

<?php }

                        if ($tab == 'video') { ?>
                            <!-- video --->
                            <div class="px-4">
                                <div class="relative">
                                    <?php if (!empty($data['hits']) && is_array($data['hits'])) { ?>

                                        <?php render_search_result_heading((int)($data['total'] ?? 0), $q ?? ''); ?>

                          <div class="relative space-y-3" style="  margin-left: -14px;">

                                            <?php foreach ($data['hits'] as $hit) {

                                                // Thumbnail fallback
                                                $image = esc_url($hit['thumbnail_url'] ?? $hit['featured_image'] ?? '');

                                                // Categories safe
                                                $categories = (!empty($hit['categories']) && is_array($hit['categories'])) ? $hit['categories'] : [];

                                                // Video link (try common keys)
                                                $video_url = $hit['video_url'] ?? $hit['url'] ?? $hit['link'] ?? '';
                                                $video_url = $video_url ? esc_url($video_url) : '';

                                                // Duration (try common keys)
                                                $duration_text = $hit['duration'] ?? $hit['video_duration'] ?? ''; // e.g. "03:25"
                                                $duration_text = $duration_text ? esc_html($duration_text) : '—';

                                                // Posted date
                                                $posted_at = $hit['posted_at'] ?? null;
                                            ?>
                                                <article
                                                    class="group flex flex-col md:flex-row gap-4 p-4 rounded-xl cursor-pointer hover:bg-gray-100 transition video-card"
                                                    style="display:flex!important;"
                                                    data-video="<?php echo esc_attr($video_url); ?>"
                                                    data-site="<?php echo esc_attr($hit['site_name'] ?? ''); ?>"
                                                    data-favicon="<?php echo esc_attr(esc_url(search_result_logo_url($hit))); ?>"
                                                    data-title="<?php echo esc_attr($hit['title'] ?? ''); ?>"
                                                    data-excerpt="<?php echo esc_attr($hit['excerpt'] ?? ''); ?>"
                                                    data-duration="<?php echo esc_attr(khmer_duration($duration_text)); ?>"

                                                    data-date="<?php echo esc_attr($posted_at ? khmer_date($posted_at) : '—'); ?>"
                                                    data-tags="<?php
                                                                $tags = [];
                                                                foreach (($categories ?? []) as $c) {
                                                                    if (!empty($c['name'])) $tags[] = '#' . $c['name'];
                                                                }
                                                                echo esc_attr(implode(',', $tags));
                                                                ?>">
                                                    <div class="w-full md:w-60 h-36 relative rounded-md overflow-hidden bg-gray-200">
                                                        <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24"
                                                            fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
                                                            class="lucide lucide-play absolute top-[50%] left-[50%] translate-x-[-50%] translate-y-[-50%] text-white shadow-xl"
                                                            aria-hidden="true">
                                                            <path d="M5 5a2 2 0 0 1 3.008-1.728l11.997 6.998a2 2 0 0 1 .003 3.458l-12 7A2 2 0 0 1 5 19z"></path>
                                                        </svg>

                                                        <?php if ($image) { ?>
                                                            <img
                                                                alt="<?php echo esc_attr($hit['title'] ?? ''); ?>"
                                                                loading="lazy"
                                                                width="300"
                                                                height="160"
                                                                decoding="async"
                                                                class="object-cover w-full h-full group-hover:brightness-75"
                                                                src="<?php echo $image; ?>">
                                                        <?php } ?>
                                                    </div>

                                               <div class="flex flex-col w-full video-card__content" style="padding-left: 10px;">
                                                        <div class="mb-2 flex space-x-2 items-center flex-wrap text-sm video-card__meta-row">
                                                            <?php $is_youtube_logo = search_result_logo_is_youtube($hit); ?>
                                                            <span class="search-result-logo-badge<?php echo $is_youtube_logo ? ' search-result-logo-badge--plain' : ''; ?> relative flex shrink-0 overflow-hidden rounded-full">
                                                                <?php $favicon = esc_url(search_result_logo_url($hit)); ?>
                                                                <img class="search-result-logo-badge__image<?php echo $is_youtube_logo ? ' search-result-logo-badge__image--plain' : ''; ?> aspect-square"
                                                                    src="<?php echo $favicon; ?>"
                                                                    alt="favicon">
                                                            </span>
                                                            <span class="text-sm md:text-md gradient-text font-medium video-card__site">
                                                                <?php echo esc_html($hit['site_name'] ?? ''); ?>
                                                            </span>

                                                            <?php if (!empty($categories)) { ?>
                                                                <p class="gradient-text video-card__categories">
                                                                    <?php
                                                                    $names = [];
                                                                    foreach ($categories as $c) {
                                                                        $category_name = trim((string) ($c['name'] ?? ''));
                                                                        if ($category_name !== '' && strcasecmp($category_name, 'youtube') !== 0) {
                                                                            $names[] = $category_name;
                                                                        }
                                                                    }
                                                                    if (!empty($names)) echo ' • ' . esc_html(implode(' • ', $names));
                                                                    ?>
                                                                </p>
                                                            <?php } ?>
                                                        </div>

                                                        <h3 class="text-lg text-primary font-semibold group-hover:underline line-clamp-1 video-result-title">
                                                            <?php echo esc_html($hit['title'] ?? ''); ?>
                                                        </h3>

                                                      <p class="text-[13px] md:text-[16px] text-[#555555] dark:text-gray-400 line-clamp-2 search-result-card__excerpt" style="/* line-height: 1.5; *//* margin-top: -10px; */">
                                                            <?php echo esc_html($hit['excerpt'] ?? ''); ?>
                                                        </p>

                                                        <?php if ($video_url) { ?>
                                                            <a class="text-xs text-gray-500 break-all mt-1 hover:underline video-card__url" href="<?php echo $video_url; ?>" target="_blank" rel="noopener">
                                                                <?php echo $video_url; ?>
                                                            </a>
                                                        <?php } ?>

                                                        <div class="flex mt-3 text-primary video-card__stats">
                                                        <p class="text-md video-card__stat" style="font-size: 15px;">
                                                                <span class="video-card__stat-label">កាលបរិច្ឆេទ៖</span>
                                                                <span class="font-medium gradient-text video-card__stat-value">
                                                                    <?php echo esc_html($posted_at ? khmer_date($posted_at) : '—'); ?>
                                                                </span>
                                                            </p>

                                                        </div>
                                                </article>

                                            <?php } ?>
                                        </div>
                            <!-- Pagination -->
                                    <div class="search-pagination-wrap" style="padding-bottom: 25px;">
                                        <?php
                                        $total_pages = $data['total_pages'];
                                        $pagination = build_pagination(
                                            current_page: $page,
                                            total_pages: $total_pages,
                                            q: $q,
                                            tab: $tab,
                                            site_slug: $site_slug,
                                            limit: $limit,
                                            site_filter_applied: $site_slug !== ''
                                        );

                                        echo '<div class="search-pagination">';
                                        foreach ($pagination as $p) {
                                            if (isset($p['url'])) {
                                                $is_control = !is_numeric((string) $p['label']);
                                                $class = 'search-pagination__link';
                                                if ($p['page'] == $page) {
                                                    $class .= ' is-active';
                                                }
                                                if ($is_control) {
                                                    $class .= ' search-pagination__link--control';
                                                }
                                                echo '<a class="' . $class . '" href="' . htmlspecialchars($p['url']) . '">' . htmlspecialchars($p['label']) . '</a>';
                                            } else {
                                                echo '<span class="search-pagination__ellipsis">' . htmlspecialchars($p['label']) . '</span>';
                                            }
                                        }
                                        echo '</div>';
                                        ?>
                                    </div>

                                <!-- ✅ VIDEO MODAL -->
                                <div id="videoModal"
                                    class="fixed inset-0 hidden z-[9999]">


                                    <!-- CENTER CONTAINER -->
                                    <div class="absolute inset-0 flex items-center justify-center p-4">


                                        <!-- BACKDROP (click to close) -->
                                        <div id="videoBackdrop" class="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex justify-center items-start overflow-y-auto p-3">

                                            <!-- MODAL BOX -->
                                            <div class="relative w-[92%] max-w-3xl rounded-2xl bg-white shadow-2xl overflow-hidden" style=" width: 1500px;">

                                                <!-- HEADER
                                        <div class="flex justify-between items-center px-4 py-3 border-b">
                                            <p id="videoModalTitle"
                                                class="font-semibold text-primary"></p>

                                        </div> -->
                                                <!-- ✅ CLOSE BUTTON -->
                                                <div id="deleteVideoModal" class="absolute top-4 right-4 text-white w-10 h-10"> ✕</div>
                                                <!-- VIDEO CONTENT -->
                                                <div id="videoPlayerWrap" class="p-4 video-player-wrap">



                                                </div>


                                            </div>
                                        <?php } else { ?>
                                            <!-- No Result Section -->
                                            <?php render_search_result_heading(0, $q); ?>

                                            <div class="search-empty-state search-empty-state--video">
                                                <p class="search-empty-state__title search-empty-state__title--muted">
                                                    មិនមានលទ្ធផលវីឌីអូសម្រាប់
                                                    "<span class="font-bold gradient-text search-empty-state__query"><?php echo esc_html($q ?: ''); ?></span>"
                                                </p>
                                                <div class="search-empty-state__media search-empty-state__media--large">
                                                    <iframe
                                                        src="https://lottie.host/embed/75c73496-b14e-452a-ab1e-9ec55176eebd/wym6ydhzIf.lottie"
                                                        class="lottie-empty-frame lottie-empty-frame--large"
                                                        frameborder="0"
                                                        allowfullscreen>
                                                    </iframe>
                                                </div>
                                            </div>
                                        <?php } ?>
                                    <?php } ?>

                                        </div>

                                    </div>

                                </div>
                            </div>
</section>

<!--script video-->
<script>
    (function() {

        const modal = document.getElementById("videoModal");
        const backdrop = document.getElementById("videoBackdrop");
        const wrap = document.getElementById("videoPlayerWrap");
        const deleteBtn = document.getElementById("deleteVideoModal");

        if (!modal || !wrap) return;

        function normalize(url) {
            url = (url || "").trim();
            if (!url) return "";
            if (url.startsWith("www.")) url = "https://" + url;
            if (url.startsWith("//")) url = "https:" + url;
            return url;
        }

        function toKhmerDigits(str) {
            const map = {
                0: "០",
                1: "១",
                2: "២",
                3: "៣",
                4: "៤",
                5: "៥",
                6: "៦",
                7: "៧",
                8: "៨",
                9: "៩"
            };
            return String(str).replace(/[0-9]/g, d => map[d]);
        }

        function youtubeEmbed(url) {
            try {
                const u = new URL(url);
                const host = u.hostname.replace("www.", "");
                let id = "";

                if (host === "youtu.be") id = u.pathname.split("/").filter(Boolean)[0] || "";

                if (host.includes("youtube.com")) {
                    id = u.searchParams.get("v") || "";
                    if (!id) {
                        const parts = u.pathname.split("/").filter(Boolean);
                        if (parts[0] === "shorts" && parts[1]) id = parts[1];
                        if (parts[0] === "embed" && parts[1]) id = parts[1];
                    }
                }
                return id ? `https://www.youtube.com/embed/${id}?autoplay=1&rel=0` : "";
            } catch (e) {}
            return "";
        }

        function openModalFromCard(card) {
            const url = normalize(card.dataset.video || "");
            if (!url) return;

            const site = (card.dataset.site || "").trim();
            const favicon = (card.dataset.favicon || "").trim();
            const title = (card.dataset.title || "").trim();
            const date = (card.dataset.date || "—").trim();
            const tags = (card.dataset.tags || "").split(",").map(t => t.trim()).filter(Boolean);

            const durationRaw = (card.dataset.duration || "").trim();
            let durationLabel = "—";

            if (durationRaw && durationRaw.includes(":")) {
                const parts = durationRaw.split(":");
                const h = parts[0] ?? "00";
                const m = parts[1] ?? "00";
                const s = parts[2] ?? "00";
                durationLabel = `${toKhmerDigits(h)}ម៉ោង: ${toKhmerDigits(m)}នាទី: ${toKhmerDigits(s)}វិនាទី`;
            }

            wrap.innerHTML = "";

            const yt = youtubeEmbed(url);
            const playerHtml = yt ?
                `<div class="w-full aspect-video bg-black rounded-md overflow-hidden">
             <iframe src="${yt}" class="w-full h-full" frameborder="0"
               allow="autoplay; encrypted-media; picture-in-picture" allowfullscreen></iframe>
           </div>` :
                url.toLowerCase().includes(".mp4") ?
                `<div class="w-full aspect-video bg-black rounded-md overflow-hidden">
             <video class="w-full h-full" controls autoplay>
               <source src="${url}" type="video/mp4">
             </video>
           </div>` :
                "";

            if (!playerHtml) return;

            wrap.innerHTML = `
        <div class="bg-white w-full rounded-lg overflow-hidden p-4">
          ${playerHtml}
          <div class="mt-5 text-primary">
            <div class="mb-2 flex space-x-2 items-center flex-wrap text-sm">
            <span class="search-result-logo-badge relative flex shrink-0 overflow-hidden rounded-full" style="margin-top:-5px;">
                <img class="search-result-logo-badge__image aspect-square"
                  src="${favicon}"
                  alt="favicon">
              </span>
              <span class="text-sm md:text-md gradient-text font-medium">${site}</span>
            </div>

            <div class="mt-3">
             <p class="text-lg font-semibold mb-2" style=" font-size: 20px;">${title}</p>
            </div>

            <div class="flex mt-3 text-primary video-card__stats">
              <p class="video-card__stat" style="font-size: 15px;">
                <span class="video-card__stat-label">កាលបរិច្ឆេទ៖</span>
                <span class="gradient-text font-medium video-card__stat-value">${date}</span>
              </p>
            </div>

          </div>
        </div>
      `;

            modal.classList.remove("hidden");
            document.body.style.overflow = "hidden";
        }

        function closeModal() {
            const iframe = wrap.querySelector("iframe");
            if (iframe) iframe.src = "";

            const video = wrap.querySelector("video");
            if (video) {
                video.pause();
                video.currentTime = 0;
            }

            wrap.innerHTML = "";
            modal.classList.add("hidden");
            document.body.style.overflow = "";
        }

        document.addEventListener("click", function(e) {
            const card = e.target.closest(".video-card");
            if (!card) return;
            e.preventDefault();
            e.stopPropagation();
            openModalFromCard(card);
        }, true);

        backdrop && backdrop.addEventListener("click", closeModal);
        deleteBtn && deleteBtn.addEventListener("click", closeModal);

        document.addEventListener("keydown", function(e) {
            if (e.key === "Escape") closeModal();
        });
    })();
</script>

<?php get_footer(); ?>
