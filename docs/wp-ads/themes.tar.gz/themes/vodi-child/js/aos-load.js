AOS.init();


jQuery(document).ready(function($){
    
// Script Carousel Top Management
$('#tabs-nav-carousel-top-management li:last-child').addClass('active');
$('.tab-content-carousel-top-management').hide();
$('.tab-content-carousel-top-management:last').show();
    // Click function
$('#tabs-nav-carousel-top-management li').click(function(){
  $('#tabs-nav-carousel-top-management li').removeClass('active');
  $(this).addClass('active');
  $('.tab-content-carousel-top-management').hide();
  
  var activeTabEpi = $(this).find('a').attr('href');
  $(activeTabEpi).fadeIn();
  return false;
});
    
// Script Carousel Producer Single
$('#tabs-nav-carousel-producer-single li:last-child').addClass('active');
$('.tab-content-carousel-producer-single').hide();
$('.tab-content-carousel-producer-single:last').show();
    // Click function
$('#tabs-nav-carousel-producer-single li').click(function(){
  $('#tabs-nav-carousel-producer-single li').removeClass('active');
  $(this).addClass('active');
  $('.tab-content-carousel-producer-single').hide();
  
  var activeTabEpi = $(this).find('a').attr('href');
  $(activeTabEpi).fadeIn();
  return false;
});
    
// Script Carousel Production Single
$('#tabs-nav-carousel-production-single li:last-child').addClass('active');
$('.tab-content-carousel-production-single').hide();
$('.tab-content-carousel-production-single:last').show();
    // Click function
$('#tabs-nav-carousel-production-single li').click(function(){
  $('#tabs-nav-carousel-production-single li').removeClass('active');
  $(this).addClass('active');
  $('.tab-content-carousel-production-single').hide();
  
  var activeTabEpi = $(this).find('a').attr('href');
  $(activeTabEpi).fadeIn();
  return false;
});

// Script Carousel Digital Team
$('#tabs-nav-carousel-digital-team li:last-child').addClass('active');
$('.tab-content-carousel-digital-team').hide();
$('.tab-content-carousel-digital-team:last').show();
    // Click function
$('#tabs-nav-carousel-digital-team li').click(function(){
  $('#tabs-nav-carousel-digital-team li').removeClass('active');
  $(this).addClass('active');
  $('.tab-content-carousel-digital-team').hide();
  
  var activeTabEpi = $(this).find('a').attr('href');
  $(activeTabEpi).fadeIn();
  return false;
});



});