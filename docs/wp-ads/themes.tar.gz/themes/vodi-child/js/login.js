
  function getParameterByName(name) {
      name = name.replace(/[\[\]]/g, '\\$&');
      var regex = new RegExp('[?&]' + name + '(=([^&#]*)|&|#|$)'),
        results = regex.exec(window.location.href);
      if (!results) return null;
      if (!results[2]) return '';
      return decodeURIComponent(results[2].replace(/\+/g, ' '));
  }

jQuery(document).ready(function($) {
  // Handle form submission
  
    if (getParameterByName('login')) {
         $("#modal-login-account").modal().css({
            "display":"flex",
            "justify-content":"center",
            "align-items":"center"
        });
        
    }
    
   

  
//   $('#form-account-login').on('submit', function(e) {
//       e.preventDefault();

//       // Get the form data
//       var formData = {
//           'uname': $('#uname_login').val(),
//           'upass': $('#upass').val(),
//           'action': customLogin.loginAction
//       };
      

//       // Perform client-side validation
//       if (formData.uname === '' || formData.upass === '') {
//           alert('Please enter both username and password.');
//           return;
//       }

//       // Submit the form using AJAX
//       $.ajax({
//           type: 'POST',
//           url: customLogin.ajaxUrl,
//           data: formData,
//           success: function(response) {
//               // Handle the response from the server
//               if (response.data.status === 'OK') {
//                   var role = response.data.data.role;
//                   var token = response.data.data.token;

//                   localStorage.setItem('loginToken', token);
//                   if(role === 'subscriber'){
//                     window.location.replace('/dashboard');
//                   }else{
//                     window.location.replace('/wp-admin');
//                   }
//               } else {
//                   var errorMessage = response.data.message;
//                   alert(errorMessage);
//               }
//           },
//           error: function() {
//               alert('An error occurred. Please try again later.');
//           }
//       });
//   });
});
