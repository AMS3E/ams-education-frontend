var prevScrollpos = window.pageYOffset;
window.onscroll = function() {
var currentScrollPos = window.pageYOffset;
  if (prevScrollpos > currentScrollPos) {
    //   document.getElementById("content").style.marginTop = "10vw";
    document.getElementById("page").getElementsByClassName("handheld-stick-this")[0].classList.add('header-animate');
    document.getElementById("wpadminbar").style.opacity = "0";
    
  } else {
          document.getElementById("page").getElementsByClassName("handheld-stick-this")[0].classList.remove('header-animate');
  }
  prevScrollpos = currentScrollPos;
}