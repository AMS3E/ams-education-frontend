
jQuery(document).ready(function($) {
    

function fetchAuthorInfo(){
    let author_id = $("#author_id").val();
    
    $.ajax({
    url: 'https://economy.ams.com.kh/wp-json/api/v2/get-team-info?id='+author_id,
    type: 'GET',
    dataType: 'json',
    success: function(data) {
        console.log(data);
        let name_kh = data.data[0].name_kh;
        let name_en = data.data[0].name_en;
        let pro_info = data.data[0].profile_eco;
        let desc = data.data[0].description;
        
        let htmlContent = `
            <div class="link-back">
                <a href="/" class="back-home">ទំព័រដើម</a> / 
                <a href="/author" class="back-author">ទំព័រអ្នកនិពន្ធ</a>
            </div>
            <div class="section-author-one">
                <div class="image">
                    <img src="${pro_info}"></img>
                </div>
                <div class="panel-paragraph">
                    <div class="section-header-author">
                        <h2 class="titleAuthor">
                            អ្នកនិពន្ធ
                        </h2>
                    </div>
                    <h2 class="title-header2">
                        ${name_kh} | ${name_en}
                    </h2>
                    <p class="text-description">
                       ${desc}
                    </p>
                </div>
            </div>
        `;
        
        $('.section-author').append(htmlContent);
    },
    error: function(xhr, textStatus, errorThrown) {
      console.log('Error:', errorThrown);
    }
  });
    
}
  

function fetchAuthorCarousel() {
  $.ajax({
    url: 'https://economy.ams.com.kh/wp-json/api/v2/get-author-list?publish_on=Economy&showing_position=Author&position_type=Carousel&limit=20&orderby=id desc',
    type: 'GET',
    dataType: 'json',
    success: function(data) {

      data.data.forEach(function(item) {
        let id = item.id;
        let authorId = item.author_info_id;
        let imageUrl = item.profile_eco;
        let authorName = item.name_kh;

        let htmlContent = `
            <div class="swiper-slide">
            	<div class="card-episode">
            		<a class="link-episode" href="https://infotainment.ams.com.kh/author-info?authorId=${authorId}&id=${id}">
            			<img src="${item.profile_eco}" alt=""></img>
            			<div class="block-title">
            				<p class="epi-title" style="float:left;color:#fff;font-weight:bold;font-size:14px;margin-top:15px;">${authorName}</p>
            			</div>
            		</a>
            	</div>
            </div>
        `;
        $('#author-detail-episode-carousel').append(htmlContent);
      });
    },
    error: function(xhr, textStatus, errorThrown) {
      console.log('Error:', errorThrown);
    }
  });
}



fetchAuthorInfo();
fetchAuthorCarousel();



});
