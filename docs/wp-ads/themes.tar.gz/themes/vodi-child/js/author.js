function modal_ams_profile(id){
    
    let modal = document.getElementById('modal-ams-profile');
    let spanEn = document.getElementsByClassName("close_modal")[0];
    let author_desc = document.getElementById('author_desc');
    let author_img = document.getElementById('author_img');
    
    let loadingIndicator = '<div id="loading_indicator" class="loading"><p>LOADING</p></div>';
    
    modal.style.backgroundColor = "rgba(0, 0, 0, 0.5)";
    modal.style.display = "flex";
    
    spanEn.onclick = function() {
      modal.style.display = "none";
      document.body.style.overflow = 'auto';
    }
    
    window.onclick = function(event) {
      if (event.target == modal) {
        modal.style.display = "none";
        document.body.style.overflow = 'auto';
      }
    }
    
    fetch('https://economy.ams.com.kh/wp-json/api/v2/get-team-info?id='+id)
      .then(response => {
        if (!response.status == "OK") {
          throw new Error(response.message);
        }
        return response.json();
      })
      .then(data => {
            author_img.innerHTML = '<img src="' + data.data[0].profile_info + '"></img>';
            author_desc.innerHTML = '<p>' + data.data[0].name_kh + ' | ' + data.data[0].name_en + '</p>';
            author_desc.innerHTML += '<p>' + data.data[0].description + '</p>';
            
            
            
      })
      .catch(error => {
        console.error('Error:', error);
       
    });


}






jQuery(document).ready(function($) {
  
function fetchTopManagement() {
  $.ajax({
    url: 'https://economy.ams.com.kh/wp-json/api/v2/get-author-list?publish_on=Infotainment&showing_position=Top Management&position_type=Top Section&limit=2&orderby=re_order asc',
    type: 'GET',
    dataType: 'json',
    success: function(data) {

      data.data.forEach(function(item) {
        let imageUrl = item.profile_eco;
        let authorName = item.name_kh;
        let authorNameEN = item.name_en;
        let authorDescription = item.description;
        let position_title = item.position_title;

        let htmlContent = `
          <div class="section-author-one">
            <div class="image">
              <img src="${imageUrl}" alt="Author Image">
            </div>
            <div class="panel-paragraph">
              <div class="section-header-author">
                <h2 class="titleAuthor">${position_title}</h2>
              </div>
              <h2 class="title-header2">
                ${authorName} | ${authorNameEN}
              </h2>
              <p class="text-description">
                ${authorDescription}
              </p>
              <div class="button-author-detail">
                <a href="https://economy.ams.com.kh/author-information/" class="section-author-detail">មើលលម្អិត</a>
              </div>
            </div>
          </div>
        `;
        $('#top-management').append(htmlContent);
      });
    },
    error: function(xhr, textStatus, errorThrown) {
      console.log('Error:', errorThrown);
    }
  });
}


function fetchTopManagementCarousel() {
  $.ajax({
    url: 'https://economy.ams.com.kh/wp-json/api/v2/get-author-list?publish_on=Economy&showing_position=Top&position_type=Carousel&limit=20&orderby=id desc',
    type: 'GET',
    dataType: 'json',
    success: function(data) {

      data.data.forEach(function(item) {
        let imageUrl = item.profile_info;
        let authorName = item.name_kh;

        let htmlContent = `
            <div class="swiper-slide">
            	<div class="card-episode">
            		<a class="link-episode" href="/">
            			<img src="${item.profile_eco}" alt=""></img>
            			<div class="block-title">
            				<p class="epi-title" style="float:left;color:#fff;font-weight:bold;font-size:14px;margin-top:15px;">${authorName}</p>
            			</div>
            		</a>
            	</div>
            </div>
        `;
        $('#top-management-carousel').append(htmlContent);
      });
    },
    error: function(xhr, textStatus, errorThrown) {
      console.log('Error:', errorThrown);
    }
  });
}

function fetchTopAuthor() {
  $.ajax({
    url: 'https://economy.ams.com.kh/wp-json/api/v2/get-author-list?publish_on=Economy&showing_position=Author&position_type=Top&limit=1&orderby=id desc',
    type: 'GET',
    dataType: 'json',
    success: function(data) {

      data.data.forEach(function(item) {
        let id = item.id;
        let authorId = item.author_eco_id;
        let imageUrl = item.profile_eco;
        let authorName = item.name_kh;
        let authorNameEN = item.name_en;
        let authorDescription = item.description;
        let position_title = item.position_title;

        let htmlContent = `
          <div class="section-author-one">
            <div class="image">
              <img src="${imageUrl}" alt="Author Image">
            </div>
            <div class="panel-paragraph">
              <div class="section-header-author">
                <h2 class="titleAuthor">${position_title}</h2>
              </div>
              <h2 class="title-header2">
                ${authorName} | ${authorNameEN}
              </h2>
              <p class="text-description">
                ${authorDescription}
              </p>
              <div class="button-author-detail">
                <a href="https://economy.ams.com.kh/author-info?authorId=${authorId}&id=${id}" class="section-author-detail">មើលលម្អិត</a>
              </div>
            </div>
          </div>
        `;
        $('#top-author').append(htmlContent);
      });
    },
    error: function(xhr, textStatus, errorThrown) {
      console.log('Error:', errorThrown);
    }
  });
}


function fetchAuthorCarousel() {
  $.ajax({
    url: 'https://economy.ams.com.kh/wp-json/api/v2/get-author-list?publish_on=Economy&showing_position=Author&position_type=Carousel&limit=20&orderby=id desc',
    type: 'GET',
    dataType: 'json',
    success: function(data) {

      data.data.forEach(function(item) {
        let id = item.id;
        let authorId = item.author_eco_id;
        let imageUrl = item.profile_eco;
        let authorName = item.name_kh;

        let htmlContent = `
            <div class="swiper-slide">
            	<div class="card-episode">
            		<a class="link-episode" href="https://economy.ams.com.kh/author-info?authorId=${authorId}&id=${id}">
            			<img src="${item.profile_eco}" alt=""></img>
            			<div class="block-title">
            				<p class="epi-title" style="float:left;color:#fff;font-weight:bold;font-size:14px;margin-top:15px;">${authorName}</p>
            			</div>
            		</a>
            	</div>
            </div>
        `;
        $('#author-episode-carousel').append(htmlContent);
      });
    },
    error: function(xhr, textStatus, errorThrown) {
      console.log('Error:', errorThrown);
    }
  });
}


function fetchTopProducer() {
  $.ajax({
    url: 'https://economy.ams.com.kh/wp-json/api/v2/get-author-list?publish_on=Economy&showing_position=Pro&position_type=Top&limit=1&orderby=id desc',
    type: 'GET',
    dataType: 'json',
    success: function(data) {

      data.data.forEach(function(item) {
        let id = item.id;
        let imageUrl = item.profile_eco;
        let authorName = item.name_kh;
        let authorNameEN = item.name_en;
        let authorDescription = item.description;

        let htmlContent = `
          <div class="section-author-one">
            <div class="image">
              <img src="${imageUrl}" alt="Author Image">
            </div>
            <div class="panel-paragraph">
              <div class="section-header-author">
                <h2 class="titleAuthor">អំពីផលិតករ</h2>
              </div>
              <h2 class="title-header2">
                ${authorName} | ${authorNameEN}
              </h2>
              <p class="text-description">
                ${authorDescription}
              </p>
              <div class="button-author-detail">
                <a href="javascript:void(0);" onClick="modal_ams_profile('${id}')" class="section-author-detail">មើលលម្អិត</a>
              </div>
            </div>
          </div>
        `;
        $('#top-producer').append(htmlContent);
      });
    },
    error: function(xhr, textStatus, errorThrown) {
      console.log('Error:', errorThrown);
    }
  });
}


function fetchProducerCarousel() {
  $.ajax({
    url: 'https://economy.ams.com.kh/wp-json/api/v2/get-author-list?publish_on=Economy&showing_position=Pro&position_type=Carousel&limit=20&orderby=id desc',
    type: 'GET',
    dataType: 'json',
    success: function(data) {

      data.data.forEach(function(item) {
        let id = item.id;
        let imageUrl = item.profile_eco;
        let authorName = item.name_kh;

        let htmlContent = `
            <div class="swiper-slide">
            	<div class="card-episode">
            		<a class="link-episode" href="javascript:void(0);" onClick="modal_ams_profile('${id}')">
            			<img src="${item.profile_eco}" alt=""></img>
            			<div class="block-title">
            				<p class="epi-title" style="float:left;color:#fff;font-weight:bold;font-size:14px;margin-top:15px;">${authorName}</p>
            			</div>
            		</a>
            	</div>
            </div>
        `;
        $('#producer-episode-carousel').append(htmlContent);
      });
    },
    error: function(xhr, textStatus, errorThrown) {
      console.log('Error:', errorThrown);
    }
  });
}


function fetchTopDigital() {
  $.ajax({
    url: 'https://economy.ams.com.kh/wp-json/api/v2/get-author-list?publish_on=Economy&showing_position=Digital&position_type=Top&limit=1&orderby=id desc',
    type: 'GET',
    dataType: 'json',
    success: function(data) {

      data.data.forEach(function(item) {
        let id = item.id;
        let imageUrl = item.profile_eco;
        let authorName = item.name_kh;
        let authorNameEN = item.name_en;
        let authorDescription = item.description;

        let htmlContent = `
          <div class="section-author-one">
            <div class="image">
              <img src="${imageUrl}" alt="Author Image">
            </div>
            <div class="panel-paragraph">
              <div class="section-header-author">
                <h2 class="titleAuthor">អំពីក្រុមឌីជីថល</h2>
              </div>
              <h2 class="title-header2">
                ${authorName} | ${authorNameEN}
              </h2>
              <p class="text-description">
                ${authorDescription}
              </p>
              <div class="button-author-detail">
                <a href="javascript:void(0);" onClick="modal_ams_profile('${id}')">មើលលម្អិត</a>
              </div>
            </div>
          </div>
        `;
        $('#top-digital').append(htmlContent);
      });
    },
    error: function(xhr, textStatus, errorThrown) {
      console.log('Error:', errorThrown);
    }
  });
}



function fetchDigitalCarousel() {
  $.ajax({
    url: 'https://economy.ams.com.kh/wp-json/api/v2/get-author-list?publish_on=Infotainment&showing_position=Digital&position_type=Carousel&limit=20&orderby=id asc',
    type: 'GET',
    dataType: 'json',
    success: function(data) {

      data.data.forEach(function(item) {
        let id = item.id;
        let imageUrl = item.profile_info;
        let authorName = item.name_kh;

        let htmlContent = `
            <div class="swiper-slide">
            	<div class="card-episode">
            		<a class="link-episode" href="javascript:void(0);" onClick="modal_ams_profile('${id}')">
            			<img src="${item.profile_info}" alt=""></img>
            			<div class="block-title">
            				<p class="epi-title" style="float:left;color:#fff;font-weight:bold;font-size:14px;margin-top:15px;">${authorName}</p>
            			</div>
            		</a>
            	</div>
            </div>
        `;
        $('#digital-episode-carousel').append(htmlContent);
      });
    },
    error: function(xhr, textStatus, errorThrown) {
      console.log('Error:', errorThrown);
    }
  });
}



function fetchTopDesigner() {
  $.ajax({
    url: 'https://economy.ams.com.kh/wp-json/api/v2/get-author-list?publish_on=Infotainment&showing_position=UI/UX&position_type=Top&limit=20&orderby=id asc',
    type: 'GET',
    dataType: 'json',
    success: function(data) {

      data.data.forEach(function(item) {
        let id = item.id;
        let imageUrl = item.profile_info;
        let authorName = item.name_kh;
        let authorNameEN = item.name_en;
        let authorDescription = item.description;
        let position_title = item.position_title;

        let htmlContent = `
          <div class="section-author-one">
            <div class="image">
              <img src="${imageUrl}" alt="Author Image">
            </div>
            <div class="panel-paragraph">
              <div class="section-header-author">
                <h2 class="titleAuthor">${position_title}</h2>
              </div>
              <h2 class="title-header2">
                ${authorName} | ${authorNameEN}
              </h2>
              <p class="text-description">
                ${authorDescription}
              </p>
              <div class="button-author-detail">
                <a href="javascript:void(0);" onClick="modal_ams_profile('${id}')" class="section-author-detail">មើលលម្អិត</a>
              </div>
            </div>
          </div>
        `;
        $('#top-designer').append(htmlContent);
      });
    },
    error: function(xhr, textStatus, errorThrown) {
      console.log('Error:', errorThrown);
    }
  });
}


function fetchDesignerCarousel() {
  $.ajax({
    url: 'https://economy.ams.com.kh/wp-json/api/v2/get-author-list?publish_on=Infotainment&showing_position=UI/UX&position_type=Carousel&limit=20&orderby=id asc',
    type: 'GET',
    dataType: 'json',
    success: function(data) {

      data.data.forEach(function(item) {
        let id = item.id;
        let imageUrl = item.profile_info;
        let authorName = item.name_kh;

        let htmlContent = `
            <div class="swiper-slide">
            	<div class="card-episode">
            		<a class="link-episode" href="javascript:void(0);" onClick="modal_ams_profile('${id}')">
            			<img src="${item.profile_info}" alt=""></img>
            			<div class="block-title">
            				<p class="epi-title" style="float:left;color:#fff;font-weight:bold;font-size:14px;margin-top:15px;">${authorName}</p>
            			</div>
            		</a>
            	</div>
            </div>
        `;
        $('#designer-episode-carousel').append(htmlContent);
      });
    },
    error: function(xhr, textStatus, errorThrown) {
      console.log('Error:', errorThrown);
    }
  });
}


function fetchDeveloperTeam() {
  $.ajax({
    url: 'https://economy.ams.com.kh/wp-json/api/v2/get-author-list?publish_on=Infotainment&showing_position=Web&position_type=&limit=20&orderby=id asc',
    type: 'GET',
    dataType: 'json',
    success: function(data) {

      data.data.forEach(function(item) {
        let id = item.id;
        let imageUrl = item.profile_info;
        let authorName = item.name_kh;
        let authorNameEN = item.name_en;
        let authorDescription = item.description;
        let position_title = item.position_title;

        let htmlContent = `
          <div class="section-developer">
            <div class="image">
              <img src="${imageUrl}" alt="Author Image">
            </div>
            <div class="panel-paragraph">
              <div class="section-header-author">
                <h2 class="titleAuthor">${position_title}</h2>
              </div>
              <h2 class="title-header2">
                ${authorName} | ${authorNameEN}
              </h2>
              <p class="text-description">
                ${authorDescription}
              </p>
              <div class="button-author-detail">
                <a href="javascript:void(0);" onClick="modal_ams_profile('${id}')" class="section-author-detail">មើលលម្អិត</a>
              </div>
            </div>
          </div>
        `;
        $('#developer-team').append(htmlContent);
      });
        
    },
    error: function(xhr, textStatus, errorThrown) {
      console.log('Error:', errorThrown);
    }
  });
}


fetchTopManagement();
fetchTopManagementCarousel();
fetchTopAuthor();
fetchAuthorCarousel();
fetchTopProducer();
fetchProducerCarousel();
fetchTopDigital();
fetchDigitalCarousel();
fetchTopDesigner();
fetchDesignerCarousel();
fetchDeveloperTeam();


});
