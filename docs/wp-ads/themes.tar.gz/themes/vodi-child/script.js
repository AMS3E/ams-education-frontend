


document.addEventListener('DOMContentLoaded', () => {
    
    // function waitForElement(selector, callback) {
    // const el = document.querySelector(selector);
    // if (el && el.querySelectorAll('p').length > 0) {
    //     return callback();
    // }

    // const observer = new MutationObserver(() => {
    //     const el = document.querySelector(selector);
    //     if (el && el.querySelectorAll('p').length > 0) {
    //         observer.disconnect();
    //         callback();
    //     }
    // });

    // observer.observe(document.body, { childList: true, subtree: true });
    // }
    function createAdLabel(text = 'Advertisement') {
      const label = document.createElement('div');
      label.textContent = text;
      label.style.fontSize = '12px';
      label.style.color = '#6e6e6e';
      label.style.margin = '0';
      label.style.lineHeight = '1.2';
    //   label.style.textAlign = 'center';
      return label;
    }
    
    function observerAdsLoaded(container, onAdLoaded){
        let adsLoaded = true;
        const observer = new MutationObserver((mutations, obs) => {
                const iframe = container.querySelector('iframe');
                if (iframe) {
                // Add label, etc.
                container.prepend(createAdLabel());
                if (onAdLoaded) onAdLoaded();
                obs.disconnect(); // stop watching
                }else{
                    console.log('Ad iframe is not loaded!')
                }
            });

        observer.observe(container, { childList: true, subtree: true });
        
       setTimeout(() => {
    const iframe = container.querySelector('iframe');
    if (!iframe) {
      console.log('❌ No ad — hiding container');
      container.style.display = 'none';
    }
  }, 3000);
    }
    function appendDivsAfterParagraphs() {
        
        const isMobile = window.matchMedia("(max-width: 768px)").matches;
        const contentElements = document.querySelectorAll('.article__content.entry-content'); //article__content entry-content
   

        contentElements.forEach(contentElement => {
            const paragraphs = contentElement.querySelectorAll('p');
            
            if (paragraphs.length >= 2) {
              // MR1 Desktop
                const mrOne_Desk = document.createElement('div');
                
                mrOne_Desk.id = 'gax-inpage-async-1728357404'; // new 1728357404 old 1729764905
                mrOne_Desk.style.height = '250px';
                mrOne_Desk.style.width = '300px';
                mrOne_Desk.style.margin = 'auto';
                
                // Add CSS to hide the div on mobile screens
                observerAdsLoaded(mrOne_Desk, ()=>{
                    mrOne_Desk.style.overflow = 'hidden';
                });
                const style = document.createElement('style');
                style.innerHTML = `
                  #main div iframe {
                    padding-top: 0 !important;
                    
                    display: block;
                 }
                  #gax-inpage-async-1728357404 {
                    display: block;
                  }
                  @media (max-width: 768px) {
                    #gax-inpage-async-1728357404 {
                      display: none;
                    }
                  }
                `;
                document.head.appendChild(style);
                
                document.body.appendChild(mrOne_Desk);
            
                const parOne = paragraphs[1];
                parOne.parentNode.insertBefore(mrOne_Desk, parOne.nextSibling);
            }

            // Create and append divs after specific paragraphs
            if (paragraphs.length >= 1) {
                // Create the mr_one div and append it after the second paragraph
               
                const mr_one = document.createElement('div');
                mr_one.id = 'gax-inpage-async-1729764905'; //1729764905 old 1729764934
                mr_one.style.textAlign = 'center';
                mr_one.style.display = isMobile ? 'block' : 'none'; // Show mr_one only on mobile screens
                observerAdsLoaded(mr_one);
                const secondParagraph = paragraphs[0];
                secondParagraph.parentNode.insertBefore(mr_one, secondParagraph.nextSibling);
                
                
                // Create another div (div1) after the second paragraph (always visible)
                const div1 = document.createElement('div');
                div1.id = 'gax-inpage-async-1729764934'; //1729764934  old 1721642630
                div1.style.textAlign = 'center';
                secondParagraph.parentNode.insertBefore(div1, mr_one.nextSibling);
            }
            
            if (paragraphs.length >= 4) {
                const fourthParagraph = paragraphs[3];
                const div2 = document.createElement('div');
                div2.id = 'gax-inpage-async-1731396715';
                div2.style.textAlign = 'center';
                // observerAdsLoaded(div2);
                fourthParagraph.parentNode.insertBefore(div2, fourthParagraph.nextSibling);
            }
            
            if (paragraphs.length >= 3) {
                // Get the third paragraph (index 2)
                const thirdParagraph = paragraphs[2];
            
                // Create a custom div to hold the ad elements
                const customDiv = document.createElement('div');
            
                // Create the <ins> element for the ad
                const insElement = document.createElement('ins');
                insElement.setAttribute('data-revive-zoneid', '233');
                insElement.setAttribute('data-revive-id', '2d10743d9880200bf17a894cfa35dba0');
                customDiv.appendChild(insElement);
            
                // Create the script element for the ad
                const adScript = document.createElement('script');
                adScript.async = true;
                // adScript.src = '//adservermsa.gpas.co/www/delivery/asyncjs.php';
                customDiv.appendChild(adScript);
            
                // Insert the custom div after the third paragraph
                thirdParagraph.parentNode.insertBefore(customDiv, thirdParagraph.nextSibling);
            }

            // Damrei MR1
            const div3 = document.createElement('div');
            div3.id = 'gax-inpage-async-1726823765';
            div3.style.textAlign = 'center';
            div3.style.display = isMobile ? 'block' : 'none'; // Show div3 only on mobile screens
            observerAdsLoaded(div3);
            contentElement.parentNode.insertBefore(div3, contentElement.nextSibling);
        });
    }

    appendDivsAfterParagraphs();
    // waitForElement('.article__content.entry-content', appendDivsAfterParagraphs);
});

jQuery(document).ready(function($){
    
    // START::Offcanvas Menu
    $('.navbar-toggler').on('click', function(){
       $('.offcanvas-drawer').css('display', 'block !important');
    });
    
    $('.toggle-icon').click(function(e) {
        e.preventDefault();
        $(this).toggleClass('active'); // Add a class to toggle the icon
        $(this).siblings('.sub-menu-b').slideToggle();
    });
    // END::Offcanvas Menu
    

    // function loadToggle(){
    //     var toggleSpan = '<a class="expandCanvasMenu" href="javascript:void(0);">+</a>';
    //     $('.dropdown-toggle').after(toggleSpan);
    // }

    // loadToggle();
    
    // $('.expandCanvasMenu').on('click', function(){
    // //   $('.expandCanvasMenu').html('+');
    //   $('ul.menu-item').css('display','block');
    // //   $(this).html('-');
    //   $(this).parent().toggleClass('show').siblings().removeClass('show');
       
    // })
    
    $('#tabs-nav li:first-child').addClass('active');
    $('.tab-content').hide();
    $('.tab-content:first').show();
    
    
    // Click function
    $('#tabs-nav li').click(function(){
      $('#tabs-nav li').removeClass('active');
      $(this).addClass('active');
      $('.tab-content').hide();
      
      var activeTab = $(this).find('a').attr('href');
      $(activeTab).fadeIn();
      return false;
    });
    
    
    // $('#tabs-nav li:first-child').addClass('active');
    //     $('.tab-content').hide();
    //     $('.tab-content:first').show();
        
    //     // Click function
    //     $('#tabs-nav li').click(function(){
    //       $('#tabs-nav li').removeClass('active');
    //       $(this).addClass('active');
    //       $('.tab-content').hide();
          
    //       var activeTab = $(this).find('a').attr('href');
    //       $(activeTab).fadeIn();
    //       return false;
    // });



    // Script Carousel Episode Multiple
    $('#tabs-nav-carousel li:last-child').addClass('active');
    $('.tab-content-carousel').hide();
    $('.tab-content-carousel:last').show();
        // Click function
    $('#tabs-nav-carousel li').click(function(){
      $('#tabs-nav-carousel li').removeClass('active');
      $(this).addClass('active');
      $('.tab-content-carousel').hide();
      
      var activeTabEpi = $(this).find('a').attr('href');
      $(activeTabEpi).fadeIn();
      return false;
    });
    
    
    // Script Carousel Episode Single
    $('#tabs-nav-carousel-single li:last-child').addClass('active');
    $('.tab-content-carousel-single').hide();
    $('.tab-content-carousel-single:last').show();
        // Click function
    $('#tabs-nav-carousel-single li').click(function(){
      $('#tabs-nav-carousel-single li').removeClass('active');
      $(this).addClass('active');
      $('.tab-content-carousel-single').hide();
      
      var activeTabEpi = $(this).find('a').attr('href');
      $(activeTabEpi).fadeIn();
      return false;
    });
    
    
    // Script Carousel Cambodia360 Insider Single
    $('#tabs-nav-carousel-cambodia360-single li:last-child').addClass('active');
    $('.tab-content-carousel-cambodia360-single').hide();
    $('.tab-content-carousel-cambodia360-single:last').show();
        // Click function
    $('#tabs-nav-carousel-cambodia360-single li').click(function(){
      $('#tabs-nav-carousel-cambodia360-single li').removeClass('active');
      $(this).addClass('active');
      $('.tab-content-carousel-cambodia360-single').hide();
      
      var activeTabEpi = $(this).find('a').attr('href');
      $(activeTabEpi).fadeIn();
      return false;
    });
    
    
        // Script Carousel Episode Khmer Insider Single
    $('#tabs-nav-carousel-khmer-insider-single li:last-child').addClass('active');
    $('.tab-content-carousel-khmer-insider-single').hide();
    $('.tab-content-carousel-khmer-insider-single:last').show();
        // Click function
    $('#tabs-nav-carousel-khmer-insider-single li').click(function(){
      $('#tabs-nav-carousel-khmer-insider-single li').removeClass('active');
      $(this).addClass('active');
      $('.tab-content-carousel-khmer-insider-single').hide();
      
      var activeTabEpi = $(this).find('a').attr('href');
      $(activeTabEpi).fadeIn();
      return false;
    });
    
    
   
       var swiper2 = new Swiper(".mySwiperAdsTest", {
            slidesPerView: 1,
            spaceBetween: 0,
            loop: true,
            autoplay: {
                delay: 5000,
                disableOnInteraction: false,
                pauseOnMouseEnter: true,
            },
            centeredSlides: true,
            pagination: {
                el: ".swiper-pagination",
                clickable: true,
                // dynamicBullets: true,
            },
        });
              
    
    
    var swiper1 = new Swiper(".mySwiperAds", {
        slidesPerView: 1,
        spaceBetween: 0,
        loop: true,
        autoplay: {
            delay: 5000,
            disableOnInteraction: false,
            pauseOnMouseEnter: true,
        },
        pagination: {
            el: ".swiper-pagination",
            clickable: true,
            // dynamicBullets: true,
        },
    });
    
    

    
    
    // START::Swiper
    var swiper = new Swiper('.swiper-container', {
          slidesPerView: 1,
          spaceBetween: 20,
        //   initialSlide: 3,
        //   watchOverflow: true,
          // centeredSlides: true,
          breakpoints: {
            140: {
              slidesPerView: 2,
              spaceBetween: 15,
            },
            340: {
              slidesPerView: 2,
              spaceBetween: 15,
            },
            360: {
              slidesPerView: 2,
              spaceBetween: 15,
            },
            380: {
              slidesPerView: 2,
              spaceBetween: 15,
            },
            480: {
              slidesPerView: 2,
              spaceBetween: 15,
            },
            599: {
              slidesPerView: 2,
              spaceBetween: 15,
            },
            640: {
              slidesPerView: 4,
              spaceBetween: 15,
            },
            768: {
              slidesPerView: 5,
              spaceBetween: 20,
            },
            1024: {
              slidesPerView: 5,
              spaceBetween: 20,
            },
            1437: {
              slidesPerView: 6,
              spaceBetween: 20,
            },
          },
          navigation: {
            nextEl: '.swiper-button-next',
            prevEl: '.swiper-button-prev',
        },
        autoplay: {
            delay: 3000,
            disableOnInteraction: false,
        },
    });



    // END::Swiper
    
    
    
    
    // START::Article You Should Know
    // $('[data-toggle="tab"]').on('click', function(){
    //     $(this).find('#fininace-menu').addClass('show').css('display', 'block').siblings().removeClass('show');
    // })
    // END::Article You Should Know
    
    $('.txtSectionNews').on('click', function(event) {
        event.preventDefault();
        $('.txtSectionNews').css('font-weight', 'normal', 'color', '#2c3e50');
        $(this).css({'font-weight': '600 !important', 'color': '#00208c !important'});
    });
    
    // START::Today News
    $('.btnTodayNews').on('click', function(){
        $('.today-news').css('display', 'block'); 
        $('.before-yesterday-news').css('display', 'none'); 
        $('.yesterday-news').css('display', 'none');
    });
    
    $('.btnYesterdayNews').on('click', function(){
        $('.yesterday-news').css('display', 'block');
        $('.today-news').css('display', 'none'); 
        $('.before-yesterday-news').css('display', 'none'); 
      
    });

    $('.btnBeforeYesterday').on('click', function(){
        $('.before-yesterday-news').css('display', 'block');
        $('.yesterday-news').css('display', 'none');
        $('.today-news').css('display', 'none'); 
        
    });
    // END::Today News
    
    // $('.expandCanvasMenu').on('click', function(){
    //     $('.nav-item').addClass('show');
    //     $('.dropdown-menu').addClass('show');
        
    // })

  //create account
//   $('#btnCreateAccount').on('click', function(){
//     $('#frmTitle').html('បង្កើតគណនី');
//     $('#frmLogin').hide();
//     $('#frmRegister').css("display", "block");

//   });

//   $('#btnBackToLogin').on('click', function(){
//     $('#frmTitle').html('ភ្ជាប់ជាមួយបណ្តាញសង្គម');
//     $('#frmRegister').hide();
//     $('#frmLogin').show();
//   });
  
  
  
//   $('#menu-ams-economy-mobile .menu-item .dropdown-toggle').click(function () {
//     $('#menu-item-24925').removeClass('show');
// });






$('#btnCollapOffcanvas').click(function () {
    $(this).closest(".dropdown-toggle > a").remove()
});
  
  



  $('.home-blog-tab-section .container .home-blog-tab-section__inner .home-section__flex-header .home-section__title-tabs .section-title__inner .nav-tabs .nav-item:nth-child(2) .nav-link').on('click', function(){
      $('.home-section__title-tabs .nav-item .nav-link').css('cssText', 'color: #949494 !important; font-weight: normal !important;');
      $('.home-section__title-tabs .nav-item:nth-child(1) .nav-link').css('cssText', 'color: black !important;');
      $('.home-section__title-tabs .nav-item:nth-child(2) .nav-link').css('cssText', 'color: #00208c !important; font-weight: bold !important;');
  });

  $('.home-blog-tab-section .container .home-blog-tab-section__inner .home-section__flex-header .home-section__title-tabs .section-title__inner .nav-tabs .nav-item:nth-child(3) .nav-link').on('click', function(){
      $('.home-section__title-tabs .nav-item .nav-link').css('cssText', 'color: #949494 !important; font-weight: normal !important;');
      $('.home-section__title-tabs .nav-item:nth-child(1) .nav-link').css('cssText', 'color: black !important;');
      $('.home-section__title-tabs .nav-item:nth-child(3) .nav-link').css('cssText', 'color: #00208c !important; font-weight: bold;');
  });

  $('.home-blog-tab-section .container .home-blog-tab-section__inner .home-section__flex-header .home-section__title-tabs .section-title__inner .nav-tabs .nav-item:nth-child(4) .nav-link').on('click', function(){
      $('.home-section__title-tabs .nav-item .nav-link').css('cssText', 'color: #949494 !important; font-weight: normal !important;');
      $('.home-section__title-tabs .nav-item:nth-child(1) .nav-link').css('cssText', 'color: black !important;');
      $('.home-section__title-tabs .nav-item:nth-child(4) .nav-link').css('cssText', 'color: #00208c !important; font-weight: bold;');
  });

  $('.home-blog-tab-section .container .home-blog-tab-section__inner .home-section__flex-header .home-section__title-tabs .section-title__inner .nav-tabs .nav-item:nth-child(5) .nav-link').on('click', function(){
      $('.home-section__title-tabs .nav-item .nav-link').css('cssText', 'color: #949494 !important; font-weight: normal !important;');
      $('.home-section__title-tabs .nav-item:nth-child(1) .nav-link').css('cssText', 'color: black !important;');
      $('.home-section__title-tabs .nav-item:nth-child(5) .nav-link').css('cssText', 'color: #00208c !important; font-weight: bold;');
  });

  $('.home-blog-tab-section .container .home-blog-tab-section__inner .home-section__flex-header .home-section__title-tabs .section-title__inner .nav-tabs .nav-item:nth-child(6) .nav-link').on('click', function(){
      $('.home-section__title-tabs .nav-item .nav-link').css('cssText', 'color: #949494 !important; font-weight: normal !important;');
      $('.home-section__title-tabs .nav-item:nth-child(1) .nav-link').css('cssText', 'color: black !important;');
      $('.home-section__title-tabs .nav-item:nth-child(6) .nav-link').css('cssText', 'color: #00208c !important; font-weight: bold;');
  });

  $('.home-blog-tab-section .container .home-blog-tab-section__inner .home-section__flex-header .home-section__title-tabs .section-title__inner .nav-tabs .nav-item:nth-child(7) .nav-link').on('click', function(){
      $('.home-section__title-tabs .nav-item .nav-link').css('cssText', 'color: #949494 !important; font-weight: normal !important;');
      $('.home-section__title-tabs .nav-item:nth-child(1) .nav-link').css('cssText', 'color: black !important;');
      $('.home-section__title-tabs .nav-item:nth-child(7) .nav-link').css('cssText', 'color: #00208c !important; font-weight: bold;');
  });
    


//   START::Offcanvas Menu
  $('.my-class .menu-item-with-icon').click(function(e) {
        e.preventDefault();
        $(this).toggleClass('opened');
        $(this).siblings('.submenu').slideToggle();
    });
//   END::Offcanvas Menu


    function parseUserAgent(userAgent) {
        const patterns = [
            /\((.*?)\)/,    // Match everything inside parentheses
            /Android\s([^\s;]+)/, // Match Android version
            /iPhone\sOS\s(\d+[\_|\.\d+]+)/, // Match iOS version for iPhone
            /iPad\sOS\s(\d+[\_|\.\d+]+)/,   // Match iOS version for iPad
            /(Windows\sNT\s\d+\.\d+)/,      // Match Windows version
            /Mac\sOS\sX\s(10[._]\d+(\.\d+)?)/,  // Match Mac OS X version
            /Linux/,  // Match Linux
            /\bCrOS\b/, // Match Chrome OS
            /\bWindows\b/, // Match Windows
            /\b(?:SymbianOS|Series\d+|UIQ|S60|S40|SymbOS)\b/i, // Match Symbian OS
        ];
    
        const labels = [
            'Device',
            'Android',
            'iOS',
            'iOS (iPad)',
            'Windows',
            'macOS',
            'Linux',
            'Chrome OS',
            'Windows',
            'Symbian',
        ];
    
        let os = '';
        let device = '';
        let brand = '';
    
        for (let i = 0; i < patterns.length; i++) {
            const pattern = patterns[i];
            const match = userAgent.match(pattern);
            if (match) {
                if (i === 0) {
                    device = match[1];
                    const parts = device.split(';');
                    if (parts.length > 1) {
                        brand = parts[0].trim();
                        device = parts.slice(1).join(';').trim();
                    }
                } else {
                    os = labels[i] + ' ' + (match[1] || '');
                    break;
                }
            }
        }
    
        const isMobileApp = detectMobileApp(userAgent);
        const structure = isMobileApp ? 'Mobile App' : 'Website';
    
        return {
            os: os.trim(),
            device: device.trim(),
            brand: brand.trim(),
            structure: structure,
        };
    }
    
    function detectMobileApp(userAgent) {
        // List of known patterns in user agents of mobile apps
        const mobileAppPatterns = [
            /FBAV/, // Facebook App
            /Instagram/, // Instagram App
            /Twitter/, // Twitter App
            /Snapchat/, // Snapchat App
            /WhatsApp/, // WhatsApp App
            /TikTok/, // TikTok App
            /com\.google\.android\.youtube/, // YouTube App
            /com\.facebook\.katana/, // Facebook App on Android
            /Line\/\d/, // LINE App
            /WeChat/, // WeChat App
        ];
    
        for (const pattern of mobileAppPatterns) {
            if (pattern.test(userAgent)) {
                return true;
            }
        }
        return false;
    }
    

    var userAgent = navigator.userAgent;
    var uaInfo = parseUserAgent(userAgent);

   
   $(document).on({
        mouseenter: handleMouseEnterTouchStart,
        touchstart: handleMouseEnterTouchStart,
        click: handleClick
    }, ".panel-ads");
    
    function getFormData(element, ipUser = null) {
        return {
            'user_id': element.data('uid'),
            'post_id': element.data('pid'),
            'cus_id': element.data('cusid'),
            'layout_id': element.data('layout'),
            'position_id': element.data('position'),
            'ip': ipUser,
            'os': uaInfo.os,
            'device': uaInfo.device,
            'device_brand': uaInfo.brand,
            'plateform': uaInfo.structure
        };
    }
    
    function handleMouseEnterTouchStart() {
        let ipUser = $("#text_ip_user").val();
        let formData = getFormData($(this), ipUser);
    
        $.ajax({
            url: "/wp-json/api/v2/ads-tracking-hover",
            type: "POST",
            data: formData,
            success: function(response) {},
            error: function(xhr, status, error) {
                // console.error(error);
            }
        });
    }
    
    function handleClick() {
        let formData = {
            'user_id': $(this).data('uid'),
            'post_id': $(this).data('pid'),
            'cus_id': $(this).data('cusid'),
            'layout_id': $(this).data('layout'),
            'position_id': $(this).data('position')
        };
    
        $.ajax({
            url: "/wp-json/api/v2/ads-tracking-click",
            type: "POST",
            data: formData,
            success: function(response) {},
            // error: function(xhr, status, error) {
            //     console.error(error);
            // }
        });
    }

    


});
document.querySelectorAll(
  '#main .wp-block-column .wp-block-column:nth-child(1) .wp-block-spacer:nth-child(3)'
).forEach(el => {
  el.style.setProperty('height', '0px', 'important');
});


var el = document.querySelector('#page #content .container .site-content__inner .widget-area-inner');
if (el) {
  el.style.cssText += `
    width: 100% !important;
  `;
}
