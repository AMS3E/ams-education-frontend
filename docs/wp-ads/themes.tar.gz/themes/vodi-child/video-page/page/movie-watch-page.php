<?php

$khi_show_id = khi_show_id_for_queried_object();
$khi_show    = $khi_show_id ? get_post( $khi_show_id ) : null;

$default_asset_uri = get_stylesheet_directory_uri() . '/video-page/assets';

$requested_season = isset( $_GET['season'] ) ? absint( $_GET['season'] ) : null;

if ( $khi_show_id ) {
	$seasons            = array();
	$current_episode    = null;
	$current_season     = $requested_season ?: 0;
	$episodes_in_season = array();
} else {
	// Standalone 'movie' post (no linked tv_show) - it supplies its own
	// video/description directly, so there's no season/episode sidebar.
	$seasons            = array();
	$current_episode    = get_queried_object();
	$current_season     = 0;
	$episodes_in_season = array();
}
get_header();
?>

<div class="khmer-insider-watch-page">

	<main class="container">

		<div class="content-row">

			<div class="main-column">

				<section class="video-block">

					<div id="khiVideoBlock"<?php echo $khi_show_id ? ' class="is-loading"' : ''; ?>><?php echo $khi_show_id ? khi_render_video_block_loading() : khi_render_video_block( $current_episode ); ?></div>

				</section>

				<section class="lower-content">

					<div class="description-box" id="khiDescriptionBox"><?php echo khi_render_description( $current_episode ); ?></div>

					<?php if ( $khi_show ) : ?>
						<div class="about-box">
							<div class="about-inner">
								<?php
								$about_thumb = get_the_post_thumbnail_url( get_queried_object_id(), 'large' );
								if ( ! $about_thumb ) {
									$about_thumb = get_the_post_thumbnail_url( $khi_show, 'large' );
								}
								?>
								<img class="about-thumb" src="<?php echo esc_url( $about_thumb ? $about_thumb : $default_asset_uri . '/about-thumbnail.png' ); ?>" alt="<?php echo esc_attr( $khi_show->post_title ); ?>" />
								<div class="about-head">
									<h2 class="box-title">អំពី <?php echo esc_html( $khi_show->post_title ); ?></h2>
									<?php $khi_schedule = khi_show_schedule_text( get_queried_object_id() ); ?>
									<?php if ( $khi_schedule ) : ?>
										<p class="about-schedule"><?php echo esc_html( $khi_schedule ); ?></p>
									<?php endif; ?>
								</div>
								<p class="about-text"><?php echo esc_html( khi_synopsis_text( $khi_show->ID ) ); ?></p>
							</div>
						</div>
					<?php endif; ?>

				</section>

			</div>

			<?php if ( $khi_show_id ) : ?>
			<aside class="sidebar">
				<div class="season-select">
					<button class="season-select-btn" id="seasonSelectBtn">
						<span id="seasonSelectLabel"><?php echo $khi_show_id ? esc_html__( 'កំពុងផ្ទុក...', 'vodi-child' ) : esc_html( khi_season_label( $current_season ) ); ?></span>
						<img class="chevron" src="<?php echo esc_url( $default_asset_uri . '/icon-chevron.svg' ); ?>" alt="" />
					</button>
					<ul class="season-dropdown" id="seasonDropdown"><?php echo khi_render_season_dropdown( $seasons, $current_season, $khi_show_id ); ?></ul>
				</div>

				<div class="episode-panel">
					<div class="episode-panel-head">
						<div class="episode-panel-head-titles">
							<h2 class="show-title"><?php echo $khi_show ? esc_html( $khi_show->post_title ) : ''; ?></h2>
							<?php if ( $khi_show ) : ?>
								<?php $khi_panel_schedule = khi_show_schedule_text( get_queried_object_id() ); ?>
								<?php if ( $khi_panel_schedule ) : ?>
									<p class="show-schedule"><?php echo esc_html( $khi_panel_schedule ); ?></p>
								<?php endif; ?>
							<?php endif; ?>
						</div>
						<button class="episode-panel-toggle" id="episodePanelToggle" type="button" aria-expanded="true" aria-label="បង្ហាញតិច">
							<img class="chevron" src="<?php echo esc_url( $default_asset_uri . '/icon-chevron.svg' ); ?>" alt="" />
						</button>
					</div>

					<ul class="episode-list" id="episodeList"><?php
						if ( $khi_show_id ) {
							echo '<li class="episode-loading">' . esc_html__( 'កំពុងផ្ទុក...', 'vodi-child' ) . '</li>';
						} else {
							echo khi_render_episode_list( $episodes_in_season, $current_episode, $current_season, $default_asset_uri );
						}
					?></ul>
				</div>
			</aside>
			<?php endif; ?>

		</div>
	</main>

	<!-- Ad banner -->
	<p style="margin-top: 30px;"></p>
	<ins data-revive-zoneid="9" data-revive-id="55aa4b5dd75ab774bd198a60f6c237bc"></ins>
	<!--<div class="ads-banner">-->
	  
	<!--</div>-->

</div>

<?php get_footer(); ?>
