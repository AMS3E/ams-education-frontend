<?php
function khi_show_id_for_movie( $movie_id ) {
	$tv_show_id = absint( get_post_meta( $movie_id, '_khi_tv_show_id', true ) );

	// Only trust the cached link if that show actually has episodes -
	// otherwise keep looking, since a movie can end up linked to an empty
	// placeholder tv_show (see khi_find_tv_show_id_for_movie_post()).
	if ( $tv_show_id && khi_tv_show_has_episodes( $tv_show_id ) ) {
		return $tv_show_id;
	}

	// Self-heal: the one-time khi_migrate_legacy_watch_show_map() only ran
	// once and only matches by exact title, so movies added afterwards, or
	// whose title differs from their tv_show's (e.g. Khmer vs. transliterated
	// Latin title), never got linked. Re-resolve and cache the result so this
	// only re-runs while the linked show still has no episodes to show.
	$movie = get_post( $movie_id );
	if ( ! $movie ) {
		return $tv_show_id;
	}

	$resolved_id = khi_find_tv_show_id_for_movie_post( $movie );
	if ( $resolved_id && $resolved_id !== $tv_show_id ) {
		update_post_meta( $movie_id, '_khi_tv_show_id', $resolved_id );
		return $resolved_id;
	}

	return $tv_show_id ? $tv_show_id : $resolved_id;
}

function khi_tv_show_has_episodes( $tv_show_id ) {
	$episodes = get_posts( array(
		'post_type'      => 'episode',
		'post_status'    => 'publish',
		'posts_per_page' => 1,
		'fields'         => 'ids',
		'meta_query'     => array(
			array(
				'key'   => '_tv_show_id',
				'value' => $tv_show_id,
			),
		),
	) );

	return ! empty( $episodes );
}

function khi_find_tv_show_id_for_movie_post( $movie ) {
	// Highest priority: the movie's own content often already embeds an
	// episode-carousel shortcode (e.g. [epsode-carousel-dynamic ...
	// tv_show_num=181312]) that an editor configured by hand for the old
	// default template - that's a more reliable source of truth than
	// guessing a link from title/slug matching.
	$from_shortcode = khi_tv_show_id_from_shortcode_content( $movie->post_content );
	if ( $from_shortcode && khi_tv_show_has_episodes( $from_shortcode ) ) {
		return $from_shortcode;
	}

	$by_slug = get_posts( array(
		'post_type'      => 'tv_show',
		'post_status'    => 'publish',
		'name'           => $movie->post_name,
		'posts_per_page' => 1,
		'fields'         => 'ids',
	) );
	if ( $by_slug && khi_tv_show_has_episodes( $by_slug[0] ) ) {
		return absint( $by_slug[0] );
	}

	$by_title = get_posts( array(
		'post_type'      => 'tv_show',
		'post_status'    => 'publish',
		'title'          => $movie->post_title,
		'posts_per_page' => 1,
		'fields'         => 'ids',
	) );
	if ( $by_title && khi_tv_show_has_episodes( $by_title[0] ) ) {
		return absint( $by_title[0] );
	}

	// Nothing with actual episodes found - fall back to whichever match
	// exists anyway (in this priority order), so the movie is still linked
	// once that show gets episodes later, instead of staying unlinked.
	if ( $from_shortcode ) {
		return absint( $from_shortcode );
	}
	if ( $by_slug ) {
		return absint( $by_slug[0] );
	}
	if ( $by_title ) {
		return absint( $by_title[0] );
	}

	return 0;
}

function khi_tv_show_id_from_shortcode_content( $post_content ) {
	if ( ! $post_content || false === stripos( $post_content, 'tv_show_num' ) ) {
		return 0;
	}

	if ( preg_match( '/\[epsode-carousel[a-z0-9_-]*\b[^\]]*\btv_show_num\s*=\s*"?(\d+)"?/i', $post_content, $matches ) ) {
		$candidate = absint( $matches[1] );
		if ( $candidate && 'tv_show' === get_post_type( $candidate ) ) {
			return $candidate;
		}
	}

	return 0;
}

function khi_normalize_title_for_matching( $title ) {
	return strtolower( trim( preg_replace( '/\s+/', ' ', wp_strip_all_tags( $title ) ) ) );
}

function khi_migrate_legacy_watch_show_map() {
	if ( get_option( 'khi_tv_show_map_migrated' ) ) {
		return;
	}

	$movie_ids = get_posts( array(
		'post_type'      => 'movie',
		'post_status'    => 'any',
		'posts_per_page' => -1,
		'fields'         => 'ids',
	) );

	$tv_shows_by_title = array();
	foreach ( get_posts( array(
		'post_type'      => 'tv_show',
		'post_status'    => 'any',
		'posts_per_page' => -1,
	) ) as $tv_show ) {
		$tv_shows_by_title[ khi_normalize_title_for_matching( $tv_show->post_title ) ] = $tv_show->ID;
	}

	foreach ( $movie_ids as $movie_id ) {
		if ( get_post_meta( $movie_id, '_khi_tv_show_id', true ) ) {
			continue;
		}
		$title = khi_normalize_title_for_matching( get_the_title( $movie_id ) );
		if ( isset( $tv_shows_by_title[ $title ] ) ) {
			update_post_meta( $movie_id, '_khi_tv_show_id', $tv_shows_by_title[ $title ] );
		}
	}

	update_option( 'khi_tv_show_map_migrated', 1 );
}
add_action( 'init', 'khi_migrate_legacy_watch_show_map' );

/**
 * "Watch Page: Linked TV Show" meta box on the movie edit screen - lets an
 * admin pick which tv_show post supplies this movie's watch-page episodes,
 * instead of that link being hardcoded in code (see khi_show_id_for_movie()).
 */
add_action( 'add_meta_boxes', function () {
	add_meta_box(
		'khi_tv_show_link',
		__( 'Watch Page: Linked TV Show', 'vodi-child' ),
		'khi_render_tv_show_link_meta_box',
		'movie',
		'side'
	);
} );

function khi_render_tv_show_link_meta_box( $post ) {
	wp_nonce_field( 'khi_save_tv_show_link', 'khi_tv_show_link_nonce' );
	$current = get_post_meta( $post->ID, '_khi_tv_show_id', true );
	$shows = get_posts( array(
		'post_type'      => array( 'tv_show', 'movie' ),
		'post_status'    => 'any',
		'posts_per_page' => -1,
		'post__not_in'   => array( $post->ID ),
		'orderby'        => 'title',
		'order'          => 'ASC',
	) );
	?>
	<p><?php esc_html_e( "This movie's watch page pulls its episodes from:", 'vodi-child' ); ?></p>
	<select name="khi_tv_show_id" id="khi_tv_show_id" style="width:100%;">
		<option value=""><?php esc_html_e( '— None —', 'vodi-child' ); ?></option>
		<?php foreach ( $shows as $show ) : ?>
			<option value="<?php echo esc_attr( $show->ID ); ?>" <?php selected( $current, $show->ID ); ?>>
				<?php echo esc_html( $show->post_title . ' (' . $show->post_type . ' #' . $show->ID . ')' ); ?>
			</option>
		<?php endforeach; ?>
	</select>
	<?php
}

add_action( 'save_post_movie', function ( $post_id ) {
	if ( ! isset( $_POST['khi_tv_show_link_nonce'] ) || ! wp_verify_nonce( $_POST['khi_tv_show_link_nonce'], 'khi_save_tv_show_link' ) ) {
		return;
	}
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return;
	}
	if ( ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}

	$tv_show_id = isset( $_POST['khi_tv_show_id'] ) ? absint( $_POST['khi_tv_show_id'] ) : 0;
	if ( $tv_show_id ) {
		update_post_meta( $post_id, '_khi_tv_show_id', $tv_show_id );
	} else {
		delete_post_meta( $post_id, '_khi_tv_show_id' );
	}
} );

function khi_show_id_for_queried_object() {
	$queried = get_queried_object();
	if ( ! $queried ) {
		return 0;
	}
	if ( 'tv_show' === $queried->post_type ) {
		return $queried->ID;
	}
	if ( 'movie' === $queried->post_type ) {
		return khi_show_id_for_movie( $queried->ID );
	}
	if ( 'episode' === $queried->post_type ) {
		return absint( get_post_meta( $queried->ID, '_tv_show_id', true ) );
	}
	return 0;
}


add_filter( 'template_include', function ( $template ) {
	if ( is_singular( 'movie' ) || is_singular( 'tv_show' ) || is_singular( 'episode' ) ) {
		$override = get_stylesheet_directory() . '/video-page/page/movie-watch-page.php';
		if ( file_exists( $override ) ) {
			return $override;
		}
	}
	return $template;
}, 99 );

function khi_embed_url_from_episode( $episode_id ) {
	$choice = get_post_meta( $episode_id, '_episode_choice', true );
	$url    = get_post_meta( $episode_id, '_episode_url_link', true );

	if ( ( 'episode_url' === $choice || '' === $choice ) && $url ) {
		if ( preg_match( '#vimeo\.com/(?:video/)?(\d+)#', $url, $m ) ) {
			return 'https://player.vimeo.com/video/' . $m[1] . '?title=0&byline=0&portrait=0';
		}
		if ( preg_match( '#youtu\.?be(?:\.com)?/(?:watch\?v=)?([A-Za-z0-9_-]{6,})#', $url, $m ) ) {
			// enablejsapi=1 lets video-watch-template.js detect playback end
			// and show the "next episode" popup (see bindPlayerEnded()).
			return 'https://www.youtube.com/embed/' . $m[1] . '?enablejsapi=1&rel=0&origin=' . rawurlencode( home_url() );
		}
	}

	return '';
}

function khi_embed_url_from_link( $url ) {
	if ( ! $url ) {
		return '';
	}
	if ( preg_match( '#vimeo\.com/(?:video/)?(\d+)#', $url, $m ) ) {
		return 'https://player.vimeo.com/video/' . $m[1] . '?title=0&byline=0&portrait=0';
	}
	if ( preg_match( '#youtu\.?be(?:\.com)?/(?:watch\?v=)?([A-Za-z0-9_-]{6,})#', $url, $m ) ) {
		return 'https://www.youtube.com/embed/' . $m[1] . '?enablejsapi=1&rel=0&origin=' . rawurlencode( home_url() );
	}
	return '';
}

function khi_embed_url_from_post( $post ) {
	if ( ! $post ) {
		return '';
	}
	if ( 'movie' === $post->post_type ) {
		$choice = get_post_meta( $post->ID, '_movie_choice', true );
		$url    = get_post_meta( $post->ID, '_movie_url_link', true );
		return ( 'movie_url' === $choice || '' === $choice ) ? khi_embed_url_from_link( $url ) : '';
	}
	return khi_embed_url_from_episode( $post->ID );
}


function khi_embed_provider_from_url( $embed_url ) {
	if ( false !== strpos( $embed_url, 'player.vimeo.com' ) ) {
		return 'vimeo';
	}
	if ( false !== strpos( $embed_url, 'youtube.com/embed' ) ) {
		return 'youtube';
	}
	return '';
}


function khi_synopsis_text( $post_id ) {
	$text = trim( wp_strip_all_tags( get_post_field( 'post_excerpt', $post_id ) ) );
	if ( '' === $text ) {
		$text = trim( wp_strip_all_tags( get_post_field( 'post_content', $post_id ) ) );
	}
	return $text;
}


function khi_show_schedule_text( $post_id ) {
	$parts = array();

	$release_date = get_post_meta( $post_id, '_movie_release_date', true );
	if ( $release_date ) {
		// MasVideos stores this as a raw Unix timestamp string - strtotime()
		// on a bare numeric string doesn't parse it as one (it misreads it as
		// something else entirely, e.g. turning 1630515600 into the year
		// 5600), so use it directly when numeric instead.
		$timestamp = is_numeric( $release_date ) ? (int) $release_date : strtotime( $release_date );
		if ( $timestamp ) {
			$parts[] = date_i18n( 'Y', $timestamp );
		}
	}

	$run_time = get_post_meta( $post_id, '_movie_run_time', true );
	if ( $run_time ) {
		$parts[] = $run_time;
	}

	$censor_rating = get_post_meta( $post_id, '_movie_censor_rating', true );
	if ( $censor_rating ) {
		$parts[] = $censor_rating;
	}

	return implode( ' | ', $parts );
}

function khi_season_numerals() {
	return array( '១', '២', '៣', '៤', '៥', '៦', '៧', '៨', '៩', '១០' );
}


function khi_resolve_watch_state( $show_id, $requested_ep = 0, $requested_season = null ) {
	$state = array(
		'seasons'            => array(),
		'current_episode'    => null,
		'current_season'     => 0,
		'episodes_in_season' => array(),
	);

	if ( ! $show_id ) {
		return $state;
	}

	global $wpdb;
	// `show` is a reserved MySQL word, so the join alias must be backtick-quoted.
	$season_rows = $wpdb->get_results( $wpdb->prepare(
		"SELECT season.meta_value AS season_id, MAX(p.post_date) AS last_post_date
		 FROM {$wpdb->postmeta} season
		 INNER JOIN {$wpdb->postmeta} `show` ON `show`.post_id = season.post_id
		 INNER JOIN {$wpdb->posts} p ON p.ID = season.post_id
		 WHERE season.meta_key = '_tv_show_season_id'
		 AND `show`.meta_key = '_tv_show_id' AND `show`.meta_value = %d
		 AND p.post_status = 'publish'
		 GROUP BY season.meta_value
		 ORDER BY last_post_date DESC",
		$show_id
	) );
	$state['seasons'] = array_map( function ( $row ) {
		return (int) $row->season_id;
	}, $season_rows );

	// Show seasons highest-to-lowest (10, 9, 8 ... 1) instead of the SQL
	// query's last-post-date order, which looks arbitrary to viewers.
	rsort( $state['seasons'] );

	$current_episode = null;
	if ( $requested_ep ) {
		$maybe_episode = get_post( $requested_ep );
		if ( $maybe_episode && 'episode' === $maybe_episode->post_type && 'publish' === $maybe_episode->post_status
			&& (int) get_post_meta( $maybe_episode->ID, '_tv_show_id', true ) === $show_id ) {
			$current_episode = $maybe_episode;
		}
	}

	if ( ! $current_episode ) {
		// No specific episode requested (or it didn't resolve) - scope the
		// "latest episode" lookup to the requested season, or the biggest
		// (most recent) season when no season was requested either.
		$fallback_season = null !== $requested_season ? $requested_season
			: ( ! empty( $state['seasons'] ) ? $state['seasons'][0] : 0 );

		$latest = get_posts( array(
			'post_type'      => 'episode',
			'post_status'    => 'publish',
			'posts_per_page' => 1,
			// Tie-break same-timestamp posts (e.g. bulk-imported episodes) by
			// ID DESC, so the most recently added episode still wins "latest".
			'orderby'        => array( 'date' => 'DESC', 'ID' => 'DESC' ),
			'meta_query'     => array(
				'relation' => 'AND',
				array(
					'key'   => '_tv_show_id',
					'value' => $show_id,
				),
				array(
					'key'   => '_tv_show_season_id',
					'value' => $fallback_season,
				),
			),
		) );
		$current_episode = ! empty( $latest ) ? $latest[0] : null;
	}

	$current_season = null !== $requested_season ? $requested_season
		: ( $current_episode ? (int) get_post_meta( $current_episode->ID, '_tv_show_season_id', true ) : ( ! empty( $state['seasons'] ) ? $state['seasons'][0] : 0 ) );

	$episodes_in_season = get_posts( array(
		'post_type'      => 'episode',
		'post_status'    => 'publish',
		'posts_per_page' => 100,
		// Tie-break same-timestamp posts (e.g. bulk-imported episodes) by
		// ID DESC - re-sorted by duration below, this only matters for
		// same-duration ties.
		'orderby'        => array( 'date' => 'DESC', 'ID' => 'DESC' ),
		'meta_query'     => array(
			'relation' => 'AND',
			array(
				'key'   => '_tv_show_id',
				'value' => $show_id,
			),
			array(
				'key'   => '_tv_show_season_id',
				'value' => $current_season,
			),
		),
	) );

	// Keep the visible list deterministic even when a plugin modifies the SQL
	// ordering. The date string uses MySQL's sortable Y-m-d H:i:s format; ID is
	// the tie-breaker for episodes imported with the same publish timestamp.
	usort( $episodes_in_season, function ( $a, $b ) {
		$date_order = strcmp( $b->post_date, $a->post_date );
		return 0 !== $date_order ? $date_order : ( (int) $b->ID <=> (int) $a->ID );
	} );

	$state['current_episode']    = $current_episode;
	$state['current_season']     = $current_season;
	$state['episodes_in_season'] = $episodes_in_season;

	return $state;
}


function khi_current_watch_context() {
	static $context = null;
	if ( null !== $context ) {
		return $context;
	}

	$context = array(
		'show_id'         => 0,
		'show'            => null,
		'current_episode' => null,
		'current_season'  => 0,
		'ep_requested'    => false,
	);

	if ( ! ( is_singular( 'movie' ) || is_singular( 'tv_show' ) || is_singular( 'episode' ) ) ) {
		return $context;
	}

	$show_id = khi_show_id_for_queried_object();
	if ( ! $show_id ) {
		return $context;
	}

	$queried = get_queried_object();
	// On an episode's own permalink there's no ?ep= in the URL to read - the
	// queried episode itself is the requested one. A ?ep= query arg (the old
	// show/movie-permalink watch links) still takes priority when present.
	$requested_ep     = isset( $_GET['ep'] ) ? absint( $_GET['ep'] ) : ( ( $queried && 'episode' === $queried->post_type ) ? $queried->ID : 0 );
	$requested_season = isset( $_GET['season'] ) ? absint( $_GET['season'] ) : null;
	$state            = khi_resolve_watch_state( $show_id, $requested_ep, $requested_season );

	$context['show_id']         = $show_id;
	$context['show']            = get_post( $show_id );
	$context['current_episode'] = $state['current_episode'];
	$context['current_season']  = $state['current_season'];
	// Only true when the URL explicitly asked for this episode - the bare
	// show URL (default/latest episode) stays self-canonical instead of
	// pointing away to a query-string URL nobody requested.
	$context['ep_requested']    = $requested_ep && $state['current_episode'] && $requested_ep === $state['current_episode']->ID;

	return $context;
}

function khi_episode_seo_title( $ctx ) {
	$ep_title   = get_the_title( $ctx['current_episode'] );
	$show_title = $ctx['show'] ? $ctx['show']->post_title : '';
	return $show_title ? ( $ep_title . ' - ' . $show_title ) : $ep_title;
}

function khi_episode_seo_description( $ctx ) {
	$text = khi_synopsis_text( $ctx['current_episode']->ID );
	if ( '' === $text && $ctx['show'] ) {
		$text = khi_synopsis_text( $ctx['show']->ID );
	}
	return wp_trim_words( $text, 30, '…' );
}

/**
 * The episode's own indexable URL - its real permalink. Old
 * ?season=&ep= links (on the show/movie permalink) still resolve to the
 * same content, but canonicalize here so search engines converge on one URL.
 */
function khi_episode_canonical_url( $ctx ) {
	return get_permalink( $ctx['current_episode']->ID );
}

/**
 * Best-effort "8:36 នាទី" / "1:08:36" style duration text -> total seconds,
 * for sorting episodes by length. Returns 0 if unparseable.
 */
function khi_duration_text_to_seconds( $text ) {
	if ( ! preg_match( '/(\d+):(\d{2})(?::(\d{2}))?/', (string) $text, $m ) ) {
		return 0;
	}
	if ( isset( $m[3] ) && '' !== $m[3] ) {
		return ( (int) $m[1] ) * 3600 + ( (int) $m[2] ) * 60 + (int) $m[3];
	}
	return ( (int) $m[1] ) * 60 + (int) $m[2];
}

/**
 * Best-effort "8:36 នាទី" / "1:08:36" style duration text -> ISO 8601
 * (schema.org VideoObject wants e.g. PT8M36S). Returns '' if unparseable.
 */
function khi_iso8601_duration_from_text( $text ) {
	if ( ! preg_match( '/(\d+):(\d{2})(?::(\d{2}))?/', (string) $text, $m ) ) {
		return '';
	}
	if ( isset( $m[3] ) && '' !== $m[3] ) {
		$hours   = (int) $m[1];
		$minutes = (int) $m[2];
		$seconds = (int) $m[3];
	} else {
		$hours   = 0;
		$minutes = (int) $m[1];
		$seconds = (int) $m[2];
	}
	$duration = 'PT';
	if ( $hours ) {
		$duration .= $hours . 'H';
	}
	if ( $minutes ) {
		$duration .= $minutes . 'M';
	}
	return $duration . $seconds . 'S';
}


add_filter( 'wpseo_title', function ( $title ) {
	$ctx = khi_current_watch_context();
	return $ctx['current_episode'] ? khi_episode_seo_title( $ctx ) : $title;
} );

add_filter( 'wpseo_metadesc', function ( $desc ) {
	$ctx = khi_current_watch_context();
	return $ctx['current_episode'] ? khi_episode_seo_description( $ctx ) : $desc;
} );

add_filter( 'wpseo_opengraph_title', function ( $title ) {
	$ctx = khi_current_watch_context();
	return $ctx['current_episode'] ? khi_episode_seo_title( $ctx ) : $title;
} );

add_filter( 'wpseo_opengraph_desc', function ( $desc ) {
	$ctx = khi_current_watch_context();
	return $ctx['current_episode'] ? khi_episode_seo_description( $ctx ) : $desc;
} );

add_filter( 'wpseo_opengraph_image', function ( $image ) {
	$ctx = khi_current_watch_context();
	if ( ! $ctx['current_episode'] ) {
		return $image;
	}
	$thumb = get_the_post_thumbnail_url( $ctx['current_episode'], 'large' );
	return $thumb ? $thumb : $image;
} );

// Canonical/OG-url only move off the show's base URL once ?ep= is
// explicitly in the request - see the 'ep_requested' comment above.
add_filter( 'wpseo_canonical', function ( $canonical ) {
	$ctx = khi_current_watch_context();
	if ( ! $ctx['current_episode'] || ! $ctx['ep_requested'] ) {
		return $canonical;
	}
	return khi_episode_canonical_url( $ctx );
} );

add_filter( 'wpseo_opengraph_url', function ( $url ) {
	$ctx = khi_current_watch_context();
	if ( ! $ctx['current_episode'] || ! $ctx['ep_requested'] ) {
		return $url;
	}
	return khi_episode_canonical_url( $ctx );
} );

add_action( 'wp_head', function () {
	$ctx = khi_current_watch_context();
	if ( ! $ctx['current_episode'] ) {
		return;
	}
	$episode = $ctx['current_episode'];

	$thumbnail = get_the_post_thumbnail_url( $episode, 'large' );
	if ( ! $thumbnail && $ctx['show'] ) {
		$thumbnail = get_the_post_thumbnail_url( $ctx['show'], 'large' );
	}

	$schema = array(
		'@context'     => 'https://schema.org',
		'@type'        => 'VideoObject',
		'name'         => get_the_title( $episode ),
		'description'  => khi_episode_seo_description( $ctx ),
		'uploadDate'   => mysql2date( 'c', $episode->post_date ),
		'thumbnailUrl' => $thumbnail ? array( $thumbnail ) : null,
		'embedUrl'     => khi_embed_url_from_episode( $episode->ID ),
	);

	$duration = khi_iso8601_duration_from_text( get_post_meta( $episode->ID, '_episode_run_time', true ) );
	if ( $duration ) {
		$schema['duration'] = $duration;
	}

	if ( $ctx['show'] ) {
		$schema['partOfSeries'] = array(
			'@type' => 'TVSeries',
			'name'  => $ctx['show']->post_title,
		);
	}

	$schema = array_filter( $schema, function ( $value ) {
		return null !== $value && '' !== $value;
	} );

	echo '<script type="application/ld+json">' . wp_json_encode( $schema ) . '</script>' . "\n";
}, 20 );


function khi_render_video_block( $current_episode ) {
	$is_movie = $current_episode && 'movie' === $current_episode->post_type;
	ob_start();
	?>
	<div class="video-wrapper">
		<div class="video-player">
			<?php if ( $current_episode ) :
				$embed_url = khi_embed_url_from_post( $current_episode );
				?>
				<?php if ( $embed_url ) : ?>
					<iframe
						id="khiPlayerFrame"
						data-provider="<?php echo esc_attr( khi_embed_provider_from_url( $embed_url ) ); ?>"
						src="<?php echo esc_url( $embed_url ); ?>"
						title="<?php echo esc_attr( get_the_title( $current_episode ) ); ?>"
						frameborder="0"
						allow="autoplay; fullscreen; picture-in-picture; clipboard-write; encrypted-media; web-share"
						allowfullscreen
					></iframe>
				<?php elseif ( $is_movie && function_exists( 'masvideos_get_the_movie' ) ) : ?>
					<?php echo masvideos_get_the_movie( $current_episode->ID ); ?>
				<?php elseif ( ! $is_movie && function_exists( 'masvideos_get_the_episode' ) ) : ?>
					<?php echo masvideos_get_the_episode( $current_episode->ID ); ?>
				<?php endif; ?>
			<?php endif; ?>
		</div>
	</div>

	<div class="video-meta">
		<h1 class="video-title"><?php echo $current_episode ? esc_html( get_the_title( $current_episode ) ) : esc_html__( 'No episode available yet', 'vodi-child' ); ?></h1>
		<?php if ( $current_episode ) :
			$duration = get_post_meta( $current_episode->ID, $is_movie ? '_movie_run_time' : '_episode_run_time', true );
			?>
			<p class="video-sub">
				<?php if ( $duration ) : ?><?php echo esc_html( $duration ); ?>&nbsp;|&nbsp;<?php endif; ?>
				Added: <?php echo esc_html( mysql2date( 'd.m.Y', $current_episode->post_date ) ); ?>
			</p>
		<?php endif; ?>
	</div>
	<?php
	return ob_get_clean();
}


function khi_render_video_block_loading() {
	ob_start();
	?>
	<div class="video-wrapper">
		<div class="video-player"></div>
	</div>
	<div class="video-meta">
		<h1 class="video-title">&nbsp;</h1>
	</div>
	<?php
	return ob_get_clean();
}

function khi_render_description( $current_episode ) {
	ob_start();
	?>
	<h2 class="box-title">Description</h2>
	<p class="description-text">
		<?php echo $current_episode ? esc_html( khi_synopsis_text( $current_episode->ID ) ) : ''; ?>
	</p>
	<?php
	return ob_get_clean();
}

/**
 * The episode a season's dropdown entry should link to - its most recently
 * posted episode, same "latest in season" precedence khi_resolve_watch_state()
 * uses when no specific episode is requested.
 */
function khi_season_latest_episode_id( $show_id, $season ) {
	$latest = get_posts( array(
		'post_type'      => 'episode',
		'post_status'    => 'publish',
		'posts_per_page' => 1,
		'fields'         => 'ids',
		'orderby'        => 'date',
		'order'          => 'DESC',
		'meta_query'     => array(
			'relation' => 'AND',
			array(
				'key'   => '_tv_show_id',
				'value' => $show_id,
			),
			array(
				'key'   => '_tv_show_season_id',
				'value' => $season,
			),
		),
	) );
	return ! empty( $latest ) ? (int) $latest[0] : 0;
}

function khi_render_season_dropdown( $seasons, $current_season, $show_id = 0 ) {
	$season_numerals = khi_season_numerals();
	ob_start();
	foreach ( $seasons as $season_value ) :
		$is_active  = $season_value === $current_season;
		$season_ep  = $show_id ? khi_season_latest_episode_id( $show_id, $season_value ) : 0;
		$season_url = $season_ep ? get_permalink( $season_ep ) : '#';
		?>
		<li class="<?php echo $is_active ? 'active' : ''; ?>">
			<a href="<?php echo esc_url( $season_url ); ?>" data-season="<?php echo esc_attr( $season_value ); ?>">
				រដូវកាលទី​ <?php echo esc_html( isset( $season_numerals[ $season_value ] ) ? $season_numerals[ $season_value ] : ( $season_value + 1 ) ); ?>
			</a>
		</li>
		<?php
	endforeach;
	return ob_get_clean();
}

function khi_render_episode_list( $episodes_in_season, $current_episode, $current_season, $default_asset_uri ) {
	ob_start();
	foreach ( $episodes_in_season as $ep ) :
		$is_active   = $current_episode && $ep->ID === $current_episode->ID;
		$ep_url      = get_permalink( $ep->ID );
		$ep_duration = get_post_meta( $ep->ID, '_episode_run_time', true );
		?>
		<li class="episode-item<?php echo $is_active ? ' active' : ''; ?>">
			<a href="<?php echo esc_url( $ep_url ); ?>" data-ep="<?php echo esc_attr( $ep->ID ); ?>" data-season="<?php echo esc_attr( $current_season ); ?>" style="display:flex;gap:10px;align-items:center;width:100%;">
				<?php $ep_thumb = get_the_post_thumbnail_url( $ep, 'medium' ); ?>
				<img class="episode-thumb" src="<?php echo esc_url( $ep_thumb ? $ep_thumb : $default_asset_uri . '/episode-thumb.svg' ); ?>" alt="<?php echo esc_attr( get_the_title( $ep ) ); ?>" />
				<div class="episode-info">
					<p class="episode-title"><?php echo esc_html( get_the_title( $ep ) ); ?></p>
					<p class="episode-meta">
						<?php if ( $ep_duration ) : ?><?php echo esc_html( $ep_duration ); ?> | <?php endif; ?>
						Added: <?php echo esc_html( mysql2date( 'd.m.Y', $ep->post_date ) ); ?>
					</p>
				</div>
			</a>
		</li>
		<?php
	endforeach;
	return ob_get_clean();
}

function khi_season_label( $current_season ) {
	$season_numerals = khi_season_numerals();
	return 'រដូវកាលទី​ ' . ( isset( $season_numerals[ $current_season ] ) ? $season_numerals[ $current_season ] : ( $current_season + 1 ) );
}

function khi_enqueue_watch_assets() {
	$ctx     = khi_current_watch_context();
	$show_id = $ctx['show_id'];
	if ( ! $show_id ) {
		return;
	}

	$js_path = get_stylesheet_directory() . '/video-page/js/video-watch-template.js';

	// Loaded as dependencies so they've at least been requested/executed
	// before video-watch-template.js runs its "next episode" popup logic
	// (see bindPlayerEnded() there).
	wp_enqueue_script( 'vimeo-player-sdk', 'https://player.vimeo.com/api/player.js', array(), null, true );
	wp_enqueue_script( 'youtube-iframe-api', 'https://www.youtube.com/iframe_api', array(), null, true );

	wp_enqueue_script(
		'khmer-insider-watch',
		get_stylesheet_directory_uri() . '/video-page/js/video-watch-template.js',
		array( 'vimeo-player-sdk', 'youtube-iframe-api' ),
		file_exists( $js_path ) ? filemtime( $js_path ) : '1.0',
		true
	);
	wp_localize_script( 'khmer-insider-watch', 'khiWatch', array(
		'restUrl'       => rest_url( 'wp/v2/khmer-insider-episode' ),
		'showId'        => $show_id,
		'initialSeason' => $ctx['current_season'],
		'initialEp'     => $ctx['current_episode'] ? $ctx['current_episode']->ID : 0,
	) );
}
add_action( 'wp_enqueue_scripts', 'khi_enqueue_watch_assets' );

/**
 * Public, read-only endpoint - same pattern as the other wp/v2 routes in this
 * theme, deliberately not nonce-gated (see unlock-video-watch.php).
 */
add_action( 'rest_api_init', function () {
	register_rest_route( 'wp/v2', 'khmer-insider-episode', array(
		'methods'             => 'GET',
		'callback'            => 'khi_rest_get_episode',
		'permission_callback' => '__return_true',
	) );
} );

function khi_rest_get_episode( $request ) {
	$show_id = absint( $request->get_param( 'show_id' ) );
	if ( ! $show_id ) {
		return new WP_Error( 'khi_no_show', 'Show not found.', array( 'status' => 404 ) );
	}

	$requested_ep     = absint( $request->get_param( 'ep' ) );
	$requested_season = null !== $request->get_param( 'season' ) ? absint( $request->get_param( 'season' ) ) : null;

	$state = khi_resolve_watch_state( $show_id, $requested_ep, $requested_season );

	$default_asset_uri = get_stylesheet_directory_uri() . '/video-page/assets';

	return array(
		'video_html'           => khi_render_video_block( $state['current_episode'] ),
		'description_html'     => khi_render_description( $state['current_episode'] ),
		'episode_list_html'    => khi_render_episode_list( $state['episodes_in_season'], $state['current_episode'], $state['current_season'], $default_asset_uri ),
		'season_dropdown_html' => khi_render_season_dropdown( $state['seasons'], $state['current_season'], $show_id ),
		'season_label'         => khi_season_label( $state['current_season'] ),
		'title'                => ( $state['current_episode'] ? get_the_title( $state['current_episode'] ) : esc_html__( 'No episode available yet', 'vodi-child' ) ) . ' - ' . get_bloginfo( 'name' ),
		'permalink'            => $state['current_episode'] ? get_permalink( $state['current_episode']->ID ) : home_url(),
		'query'                => array(
			'season' => $state['current_season'],
			'ep'     => $state['current_episode'] ? $state['current_episode']->ID : 0,
		),
	);
}
