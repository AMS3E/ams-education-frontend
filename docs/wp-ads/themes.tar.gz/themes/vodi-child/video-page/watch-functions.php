<?php

include('functions/unlock-video-watch.php');
include('functions/video-watch.php');



// Shared Figma watch-page template (video-page/page/movie-watch-page.php) - the
// template_include filter in video-page/functions/video-watch.php forces this
// for every 'movie', 'tv_show', and 'episode' post, so its styles load for all of them.
function khi_enqueue_watch_template_styles() {
    if (is_singular('movie') || is_singular('tv_show') || is_singular('episode')) {
        $khi_css_path = get_stylesheet_directory() . '/video-page/css/video-watch-template.css';
        wp_enqueue_style('google-fonts-battambang', 'https://fonts.googleapis.com/css2?family=Battambang:wght@400;700&display=swap', array(), null);
        wp_enqueue_style('khmer-insider-watch-template', get_stylesheet_directory_uri() . '/video-page/css/video-watch-template.css', array(), file_exists($khi_css_path) ? filemtime($khi_css_path) : 100);
    }
}
add_action('wp_enqueue_scripts', 'khi_enqueue_watch_template_styles');

// Fallback Revive ad tag shown in the watch page's ads-banner when the
// ads-layout-five-fullwidth shortcode returns nothing. Change the zone/id
// here to swap the ad without touching video-page/page/movie-watch-page.php.
function khi_watch_ads_banner_fallback() {
    $zone_id   = '9';
    $revive_id = '55aa4b5dd75ab774bd198a60f6c237bc';
    return '<ins data-revive-zoneid="' . esc_attr($zone_id) . '" data-revive-id="' . esc_attr($revive_id) . '"></ins>';
}
