document.addEventListener('DOMContentLoaded', function () {
	var btn = document.getElementById('seasonSelectBtn');
	var dropdown = document.getElementById('seasonDropdown');

	if (btn && dropdown) {
		btn.addEventListener('click', function () {
			btn.classList.toggle('open');
		});

		document.addEventListener('click', function (e) {
			if (!btn.contains(e.target) && !dropdown.contains(e.target)) {
				btn.classList.remove('open');
			}
		});
	}

	var panelToggle = document.getElementById('episodePanelToggle');
	var panel = document.querySelector('.episode-panel');

	if (panelToggle && panel) {
		if (window.matchMedia('(max-width: 768px)').matches) {
			panel.classList.add('collapsed');
			panelToggle.classList.add('collapsed');
			panelToggle.setAttribute('aria-expanded', 'false');
			panelToggle.setAttribute('aria-label', 'បង្ហាញច្រើន');
		}

		panelToggle.addEventListener('click', function () {
			var collapsed = panel.classList.toggle('collapsed');
			panelToggle.classList.toggle('collapsed', collapsed);
			panelToggle.setAttribute('aria-expanded', collapsed ? 'false' : 'true');
			panelToggle.setAttribute('aria-label', collapsed ? 'បង្ហាញច្រើន' : 'បង្ហាញតិច');
		});
	}

	var adsBanner = document.querySelector('.khmer-insider-watch-page .ads-banner');

	if (adsBanner) {
		if (adsBanner.querySelector('iframe')) {
			adsBanner.classList.remove('no-ads');
		} else {
			var adsTimeout = setTimeout(function () {
				adsObserver.disconnect();
				adsBanner.classList.add('no-ads');
			}, 4000);

			var adsObserver = new MutationObserver(function () {
				if (adsBanner.querySelector('iframe')) {
					clearTimeout(adsTimeout);
					adsObserver.disconnect();
					adsBanner.classList.remove('no-ads');
				}
			});
			adsObserver.observe(adsBanner, { childList: true, subtree: true });
		}
	}

	if (typeof khiWatch === 'undefined' || !khiWatch.restUrl || !khiWatch.showId) {
		return;
	}

	var videoBlock = document.getElementById('khiVideoBlock');
	var descriptionBox = document.getElementById('khiDescriptionBox');
	var episodeList = document.getElementById('episodeList');
	var seasonLabel = document.getElementById('seasonSelectLabel');

	if (!videoBlock || !episodeList || !dropdown) {
		return;
	}

	function isPlainClick(e) {
		return e.button === 0 && !e.metaKey && !e.ctrlKey && !e.shiftKey && !e.altKey;
	}

	function bindEpisodeLinks() {
		episodeList.querySelectorAll('a[data-ep]').forEach(function (link) {
			link.addEventListener('click', function (e) {
				if (!isPlainClick(e)) {
					return;
				}
				e.preventDefault();
				loadState(link.getAttribute('data-season'), link.getAttribute('data-ep'), false, link.getAttribute('href'));
			});
		});
	}

	function bindSeasonLinks() {
		dropdown.querySelectorAll('a[data-season]').forEach(function (link) {
			link.addEventListener('click', function (e) {
				if (!isPlainClick(e)) {
					return;
				}
				e.preventDefault();
				btn.classList.remove('open');
				loadState(link.getAttribute('data-season'), '', false, link.getAttribute('href'));
			});
		});
	}

	// Next-episode popup shown when the player fires its "ended" event -
	// reads the already-rendered #episodeList instead of a fresh request.
	function buildNextOverlay() {
		var items = Array.prototype.slice.call(episodeList.querySelectorAll('.episode-item'));
		if (!items.length) {
			return null;
		}

		var activeIndex = items.findIndex(function (li) {
			return li.classList.contains('active');
		});
		if (activeIndex === -1) {
			activeIndex = 0;
		}

		var nextItems = [];
		for (var i = 1; i <= items.length - 1 && nextItems.length < 3; i++) {
			nextItems.push(items[(activeIndex + i) % items.length]);
		}
		if (!nextItems.length) {
			return null;
		}

		var overlay = document.createElement('div');
		overlay.className = 'khi-next-overlay';

		var head = document.createElement('div');
		head.className = 'khi-next-head';
		head.textContent = 'វគ្គបន្ទាប់';
		overlay.appendChild(head);

		var grid = document.createElement('div');
		grid.className = 'khi-next-grid';

		nextItems.forEach(function (li) {
			var link = li.querySelector('a[data-ep]');
			var thumb = li.querySelector('.episode-thumb');
			var title = li.querySelector('.episode-title');
			if (!link) {
				return;
			}

			var item = document.createElement('a');
			item.className = 'khi-next-item';
			item.href = link.getAttribute('href');

			var thumbWrap = document.createElement('div');
			thumbWrap.className = 'khi-next-thumb';

			var img = document.createElement('img');
			img.src = thumb ? thumb.src : '';
			img.alt = '';
			thumbWrap.appendChild(img);

			var play = document.createElement('div');
			play.className = 'khi-next-play';
			play.innerHTML = '<svg viewBox="0 0 24 24" fill="#ffffff"><path d="M8 5v14l11-7z"/></svg>';
			thumbWrap.appendChild(play);

			item.appendChild(thumbWrap);

			var p = document.createElement('p');
			p.textContent = title ? title.textContent : '';
			item.appendChild(p);

			item.addEventListener('click', function (e) {
				if (!isPlainClick(e)) {
					return;
				}
				e.preventDefault();
				overlay.remove();
				loadState(link.getAttribute('data-season'), link.getAttribute('data-ep'), false, link.getAttribute('href'));
			});

			grid.appendChild(item);
		});

		overlay.appendChild(grid);

		var closeBtn = document.createElement('button');
		closeBtn.type = 'button';
		closeBtn.className = 'khi-next-close';
		closeBtn.setAttribute('aria-label', 'បិទ');
		closeBtn.textContent = '✕';
		closeBtn.addEventListener('click', function () {
			overlay.remove();
		});
		overlay.appendChild(closeBtn);

		return overlay;
	}

	function showNextOverlay() {
		var playerWrap = videoBlock.querySelector('.video-player');
		if (!playerWrap || playerWrap.querySelector('.khi-next-overlay')) {
			return;
		}
		var overlay = buildNextOverlay();
		if (overlay) {
			playerWrap.appendChild(overlay);
		}
	}

	// Wires the "ended" event of whichever player embed is currently in the
	// DOM (Vimeo Player SDK or YouTube IFrame API) to showNextOverlay().
	// Re-run after every applyState() since the iframe is replaced.
	function bindPlayerEnded() {
		var iframe = document.getElementById('khiPlayerFrame');
		if (!iframe) {
			return;
		}
		var provider = iframe.getAttribute('data-provider');

		if (provider === 'vimeo') {
			if (typeof Vimeo === 'undefined' || !Vimeo.Player) {
				return;
			}
			new Vimeo.Player(iframe).on('ended', showNextOverlay);
		} else if (provider === 'youtube') {
			var createYouTubePlayer = function () {
				if (!document.body.contains(iframe)) {
					return;
				}
				new YT.Player(iframe, {
					events: {
						onStateChange: function (e) {
							if (e.data === YT.PlayerState.ENDED) {
								showNextOverlay();
							}
						}
					}
				});
			};

			if (typeof YT !== 'undefined' && YT.Player) {
				createYouTubePlayer();
			} else {
				var existingReady = window.onYouTubeIframeAPIReady;
				window.onYouTubeIframeAPIReady = function () {
					if (existingReady) {
						existingReady();
					}
					createYouTubePlayer();
				};
			}
		}
	}

	function applyState(data) {
		videoBlock.innerHTML = data.video_html;
		if (descriptionBox) {
			descriptionBox.innerHTML = data.description_html;
		}
		episodeList.innerHTML = data.episode_list_html;
		dropdown.innerHTML = data.season_dropdown_html;
		if (seasonLabel) {
			seasonLabel.textContent = data.season_label;
		}
		if (data.title) {
			document.title = data.title;
		}
		bindEpisodeLinks();
		bindSeasonLinks();
		bindPlayerEnded();
	}

	// isInitial: true for the page-load fetch that fills in the server-
	// rendered empty shell (see video-page/page/movie-watch-page.php) - it must
	// not bounce the browser to fallbackHref on failure (that would just
	// reload the same URL, and on a persistent failure, loop) and it
	// replaces history instead of pushing a duplicate entry onto it.
	// fallbackHref: the episode/season link's own href (its real permalink),
	// used only if the REST fetch fails - normally the address bar is set from
	// data.permalink, the server's authoritative resolution of the request.
	function loadState(season, ep, isInitial, fallbackHref) {
		var params = new URLSearchParams();
		params.set('show_id', khiWatch.showId);
		if (season !== null && season !== '') {
			params.set('season', season);
		}
		if (ep) {
			params.set('ep', ep);
		}

		videoBlock.classList.add('is-loading');

		fetch(khiWatch.restUrl + '?' + params.toString(), { credentials: 'same-origin' })
			.then(function (res) { return res.json(); })
			.then(function (data) {
				if (!data || !data.video_html) {
					if (!isInitial && fallbackHref) {
						window.location.href = fallbackHref;
					}
					return;
				}
				applyState(data);
				var url = data.permalink || fallbackHref || window.location.href;
				if (isInitial) {
					window.history.replaceState({ khi: data.query }, '', url);
				} else {
					window.history.pushState({ khi: data.query }, '', url);
				}
			})
			.catch(function () {
				if (!isInitial && fallbackHref) {
					window.location.href = fallbackHref;
				}
			})
			.finally(function () {
				videoBlock.classList.remove('is-loading');
			});
	}

	window.addEventListener('popstate', function (e) {
		var state = e.state && e.state.khi;
		if (state) {
			loadState(state.season, state.ep);
		} else {
			// No state we pushed (e.g. navigated back past our history entries) -
			// a full reload of whatever URL the browser landed on is always correct.
			window.location.reload();
		}
	});

	// The server already resolved the starting season/episode - honoring
	// ?season=/?ep= on the show/movie permalink (old watch links) or the
	// episode itself when landing directly on its own permalink - so the
	// client doesn't need to re-parse the URL.
	loadState(khiWatch.initialSeason, khiWatch.initialEp, true);
});
