<?php



function general_news_ams($atts){
    
    ob_start();
    
    ?>
    
    <section class="section-general-news">
        <div class="col-lg-12 panel-general-news">
            <div class="d-flex justify-content-between" style="padding-top:50px;">
                <h2 class="section-title">ព័ត៌មានទូទៅ</h2>
                <a class="btnPopularNewsText" href="https://economy.ams.com.kh/category/all-news/"style="font-weight:bold;">មើលទាំងអស់ ➧</a>
            </div>
            
            <!-- START::Popular News Text-->
            <div class="general-news-ams">
    
            <?php
        
                extract(shortcode_atts( array(
                    'post_type' => 'post_type',
                    'post_status' => 'post_status',
                    'category__in' => 'category__in',
                    'orderby' => 'orderby',
                    'posts_per_page' => 'posts_per_page',
                ), $atts));
                
                
                $options = array(
                    'post_type' => $post_type,
                    'post_status' => $post_status,
                    'category__in' => $category__in,
                    'orderby' => $orderby,
                    'posts_per_page' => $posts_per_page,
                );
                
                $loop = new WP_Query( $options );
                    
                if($loop->have_posts()) :
                    while($loop->have_posts()) : $loop->the_post();
                        ?>
                            <div class="container-general-news-ams">
                                <a class="general-news-ams" href="<?= the_permalink();?>">
                                    <?php the_post_thumbnail(); ?>
                                    <div class="article">
                                    <p><?php the_title(); ?></p>
                                        <div class="row">
                                            <p class="category"><?php echo             get_the_category_list(', '); ?> 
                                            </p>
                                            <p class="date"> • <?php echo get_the_date(); ?></p> 
                                            <p class="article-except"><?php echo get_the_excerpt(); ?></p>
                                        </div>
                                    </div>
                                </a>
                            </div>
                        <?php
                    endwhile;
                    
                    
            		
                endif;
                
                wp_reset_query();
            ?>
        
        
        </div>
        <!-- END::Popular News Text-->

        
        
        
    </section>
    
    <?php
        $myvariable = ob_get_clean();

        return $myvariable;
    ?>
            	
    <?php



}

add_shortcode('general-news', 'general_news_ams');


?>