<?php



function author_articles($atts){
    
    ob_start();
    
    ?>

    
    <section class="section-start-up-innovation">
        <div class="col-lg-12 panel-start-up-innovation">
            <div class="d-flex justify-content-between" style="padding-top:50px;">
                <!--<h2 class="section-title">-->
                <!--    អត្ថបទថ្មីៗ-->
                <!--</h2>-->
        	    <ul id="tabs-nav-carousel" class="header-epi-title">

                    <li><a href="#latest-article" class="title-header">អត្ថបទថ្មីៗ</a></li>
                    <span style="margin-left:15px;margin-right:15px;">/</span>
                    <li><a href="#most-view-article" class="title-header">អត្ថបទពេញនិយម</a></li>
                
                </ul>
                <a class="btnInnovation txtSectionNews" href="">មើលទាំងអស់ ➧</a>
            </div>
            
            <div class="tabs">
                <div id="tabs-content">
                    <div id="latest-article" class="tab-content-carousel">
                        <!-- START::start-up-innovation Articles-->
                        <div class="start-up-innovation">
                
                        <?php
                    
                            extract(shortcode_atts( array(
                                'post_type' => 'post_type',
                                'post_status' => 'post_status',
                                'orderby' => 'ID',
                                'order' => 'order',
                                'posts_per_page' => 'posts_per_page',
                            ), $atts));
                            
                            
                            $options = array(
                                'post_type' => $post_type,
                                'post_status' => $post_status,
                                'orderby' => 'ID',
                                'order' => $order,
                                'posts_per_page' => $posts_per_page,
                            );
                            
                            $loop = new WP_Query( $options );
                                
                            if($loop->have_posts()) :
                                while($loop->have_posts()) : $loop->the_post();
                                    ?>
                                        <div class="container-start-up-innovation">
                                            <a class="start-up-innovation" href="<?= the_permalink();?>">
                                                <?php the_post_thumbnail(); ?>
                                                <div class="article">
                                                <p><?php the_title(); ?></p>
                                                    <div class="row">
                                                        <p class="category"><?php echo             get_the_category_list(', '); ?> 
                                                        </p>
                                                        <p class="date"> • <?php echo get_the_date(); ?></p> 
                                                    </div>
                                                </div>
                                            </a>
                                        </div>
                                    <?php
                                endwhile;
                                
                                
                        		
                            endif;
                            
                            wp_reset_query();
                        ?>
                    
                    
                    </div>
                        <!-- END::start-up-innovation Articles-->
                    </div>
                    
                    
                    
                    
                    
                    <div id="most-view-article" class="tab-content-carousel">
                        <div class="start-up-innovation">
                
                        <?php
                            
                            extract(shortcode_atts( array(
                                'post_type' => 'post_type',
                                'post_status' => 'post_status',
                                'author' => 'author',
                                'orderby' => 'ID',
                                'order' => 'order',
                                'posts_per_page' => 'posts_per_page',
                            ), $atts));
                            
                            
                            $options = array(
                                'post_type' => $post_type,
                                'post_status' => $post_status,
                                'author' => $author,
                                'orderby' => 'ID',
                                'order' => $order,
                                'posts_per_page' => $posts_per_page,
                            );
                            
                            $loop = new WP_Query( $options );
                                
                            if($loop->have_posts()) :
                                while($loop->have_posts()) : $loop->the_post();
                                    ?>
                                        <div class="container-start-up-innovation">
                                            <a class="start-up-innovation" href="<?= the_permalink();?>">
                                                <?php the_post_thumbnail(); ?>
                                                <div class="article">
                                                <p><?php the_title(); ?></p>
                                                    <div class="row">
                                                        <p class="category"><?php echo             get_the_category_list(', '); ?> 
                                                        </p>
                                                        <p class="date"> • <?php echo get_the_date(); ?></p> 
                                                        <?php echo get_post_meta($post_id, 'views', true); ?>
                                                    </div>
                                                </div>
                                            </a>
                                        </div>
                                    <?php
                                endwhile;
                                
                                
                        		
                            endif;
                            
                            wp_reset_query();
                        ?>
                    
                    
                    </div>
                    </div>
                    
                </div>  
            </div>

        
        
    </section>
    
    <?php
        $myvariable = ob_get_clean();

        return $myvariable;
    ?>
            	
    <?php



}

add_shortcode('author-article', 'author_articles');


?>