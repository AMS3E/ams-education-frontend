<?php



function latest_article_you_should_know($atts){
    
    ob_start();
    
    ?>
    
    <section class="should-know-article">
        <div class="col-lg-12 panel-should-know-article">
            <div class="title-header">
                <h2 class="section-title">អត្ថបទថ្មីៗដែលលោកអ្នកគួរយល់ដឹង</h2>
                <div class="title-category-section">
                    
                      <ul id="tabs-nav">
                        <li style="width:80px;"><a href="#economy-mnu-section">សេដ្ឋកិច្ច</a></li>
                        <li style="width:80px;"><a href="#finance-mnu-section">ហិរញ្ញវត្ថុ</a></li>
                        <li style="width:95px;"><a href="#realestate-mnu-section">អចលនទ្រព្យ</a></li>
                        <li style="width:70px;"><a href="#bussiness-mnu-section">ជំនួញ</a></li>
                        <li style="width:135px;"><a href="#innovation-mnu-section">អាជីវកម្ម និងនវានុវត្ត</a></li>
                        <li style="width:115px;"><a href="#pr-mnu-section">អត្ថបទពាណិជ្ជកម្ម</a></li>
                      </ul>
  
                </div>
            </div>
            

        
            <div class="tabs">
  
              <div id="tabs-content">
                  
                <div id="economy-mnu-section" class="tab-content">
                              <!-- START::Economy Article-->
                        <div class="you-should-know-articles">
                
                        <?php
                    
                            extract(shortcode_atts( array(
                                'post_type' => 'post_type',
                                'post_status' => 'post_status',
                                'category__in' => 'category__in',
                                'orderby' => 'orderby',
                                'posts_per_page' => 'posts_per_page',
                            ), $atts));
                            
                            
                            $options = array(
                                'post_type' => $post_type,
                                'post_status' => $post_status,
                                'category__in' => $category__in,
                                'order' => $order,
                                'posts_per_page' => $posts_per_page,
                            );
                            
                            $loop = new WP_Query( $options );
                                
                            if($loop->have_posts()) :
                                while($loop->have_posts()) : $loop->the_post();
                                    ?>
                                        <div class="container-popular-news">
                                            <a class="popular-news" href="<?= the_permalink();?>">
                                                <?php the_post_thumbnail(); ?>
                                                <div class="article">
                                                <p><?php the_title(); ?></p>
                                                    <div class="row">
                                                        <p class="category"><?php echo             get_the_category_list(', '); ?> 
                                                        </p>
                                                        <p class="date"> • <?php echo get_the_date(); ?></p> 
                                                    </div>
                                                </div>
                                            </a>
                                        </div>
                                    <?php
                                endwhile;
                                
                                
                        		
                            endif;
                            
                            wp_reset_query();
                        ?>
                        
                        
                    </div>
                
                    <!-- END::Economy Article-->
                </div>
                
                <div id="finance-mnu-section" class="tab-content">
                                  <!-- START::Finance Article-->
                    <div class="you-should-know-articles">
                
                        <?php
                    
                            extract(shortcode_atts( array(
                                'post_type' => 'post_type',
                                'post_status' => 'post_status',
                                'category__in' => 'category__in',
                                'orderby' => 'orderby',
                                'posts_per_page' => 'posts_per_page',
                            ), $atts));
                            
                            
                            $options = array(
                                'post_type' => $post_type,
                                'post_status' => $post_status,
                                'category__in' => 247,
                                'order' => $order,
                                'posts_per_page' => $posts_per_page,
                            );
                            
                            $loop = new WP_Query( $options );
                                
                            if($loop->have_posts()) :
                                while($loop->have_posts()) : $loop->the_post();
                                    ?>
                                        <div class="container-popular-news">
                                            <a class="popular-news" href="<?= the_permalink();?>">
                                                <?php the_post_thumbnail(); ?>
                                                <div class="article">
                                                <p><?php the_title(); ?></p>
                                                    <div class="row">
                                                        <p class="category"><?php echo             get_the_category_list(', '); ?> 
                                                        </p>
                                                        <p class="date"> • <?php echo get_the_date(); ?></p> 
                                                    </div>
                                                </div>
                                            </a>
                                        </div>
                                    <?php
                                endwhile;
                                
                                
                        		
                            endif;
                            
                            wp_reset_query();
                        ?>
                    
                    
                    </div>
                    <!-- END::Finance Article-->
                </div>
                
                <div id="realestate-mnu-section" class="tab-content">
                                  <!-- START::Real Estate Article-->
                    <div class="you-should-know-articles">
                
                        <?php
                    
                            extract(shortcode_atts( array(
                                'post_type' => 'post_type',
                                'post_status' => 'post_status',
                                'category__in' => 'category__in',
                                'orderby' => 'orderby',
                                'posts_per_page' => 'posts_per_page',
                            ), $atts));
                            
                            
                            $options = array(
                                'post_type' => $post_type,
                                'post_status' => $post_status,
                                'category__in' => 249,
                                'order' => $order,
                                'posts_per_page' => $posts_per_page,
                            );
                            
                            $loop = new WP_Query( $options );
                                
                            if($loop->have_posts()) :
                                while($loop->have_posts()) : $loop->the_post();
                                    ?>
                                        <div class="container-popular-news">
                                            <a class="popular-news" href="<?= the_permalink();?>">
                                                <?php the_post_thumbnail(); ?>
                                                <div class="article">
                                                <p><?php the_title(); ?></p>
                                                    <div class="row">
                                                        <p class="category"><?php echo             get_the_category_list(', '); ?> 
                                                        </p>
                                                        <p class="date"> • <?php echo get_the_date(); ?></p> 
                                                    </div>
                                                </div>
                                            </a>
                                        </div>
                                    <?php
                                endwhile;
                                
                                
                        		
                            endif;
                            
                            wp_reset_query();
                        ?>
                    
                    
                    </div>
                    <!-- END::Real Estate Article-->
                </div>
                
                <div id="bussiness-mnu-section" class="tab-content">
                                  <!-- START::Bussiness Article-->
                    <div class="you-should-know-articles">
                
                        <?php
                    
                            extract(shortcode_atts( array(
                                'post_type' => 'post_type',
                                'post_status' => 'post_status',
                                'category__in' => 'category__in',
                                'orderby' => 'orderby',
                                'posts_per_page' => 'posts_per_page',
                            ), $atts));
                            
                            
                            $options = array(
                                'post_type' => $post_type,
                                'post_status' => $post_status,
                                'category__in' => 251,
                                'order' => $order,
                                'posts_per_page' => $posts_per_page,
                            );
                            
                            $loop = new WP_Query( $options );
                                
                            if($loop->have_posts()) :
                                while($loop->have_posts()) : $loop->the_post();
                                    ?>
                                        <div class="container-popular-news">
                                            <a class="popular-news" href="<?= the_permalink();?>">
                                                <?php the_post_thumbnail(); ?>
                                                <div class="article">
                                                <p><?php the_title(); ?></p>
                                                    <div class="row">
                                                        <p class="category"><?php echo             get_the_category_list(', '); ?> 
                                                        </p>
                                                        <p class="date"> • <?php echo get_the_date(); ?></p> 
                                                    </div>
                                                </div>
                                            </a>
                                        </div>
                                    <?php
                                endwhile;
                                
                                
                        		
                            endif;
                            
                            wp_reset_query();
                        ?>
                    
                    
                    </div>
                    <!-- END::Bussiness Article-->
                </div>
                
                <div id="innovation-mnu-section" class="tab-content">
                                  <!-- START::Innovation Article-->
                    <div class="you-should-know-articles">
                
                        <?php
                    
                            extract(shortcode_atts( array(
                                'post_type' => 'post_type',
                                'post_status' => 'post_status',
                                'category__in' => 'category__in',
                                'orderby' => 'orderby',
                                'posts_per_page' => 'posts_per_page',
                            ), $atts));
                            
                            
                            $options = array(
                                'post_type' => $post_type,
                                'post_status' => $post_status,
                                'category__in' => 253,
                                'order' => $order,
                                'posts_per_page' => $posts_per_page,
                            );
                            
                            $loop = new WP_Query( $options );
                                
                            if($loop->have_posts()) :
                                while($loop->have_posts()) : $loop->the_post();
                                    ?>
                                        <div class="container-popular-news">
                                            <a class="popular-news" href="<?= the_permalink();?>">
                                                <?php the_post_thumbnail(); ?>
                                                <div class="article">
                                                <p><?php the_title(); ?></p>
                                                    <div class="row">
                                                        <p class="category"><?php echo             get_the_category_list(', '); ?> 
                                                        </p>
                                                        <p class="date"> • <?php echo get_the_date(); ?></p> 
                                                    </div>
                                                </div>
                                            </a>
                                        </div>
                                    <?php
                                endwhile;
                                
                                
                        		
                            endif;
                            
                            wp_reset_query();
                        ?>
                    
                    
                    </div>
                    <!-- END::Innovation Article-->
                </div>
                
                <div id="pr-mnu-section" class="tab-content">
                                  <!-- START::PR Article-->
                    <div class="you-should-know-articles">
                
                        <?php
                    
                            extract(shortcode_atts( array(
                                'post_type' => 'post_type',
                                'post_status' => 'post_status',
                                'category__in' => 'category__in',
                                'orderby' => 'orderby',
                                'posts_per_page' => 'posts_per_page',
                            ), $atts));
                            
                            
                            $options = array(
                                'post_type' => $post_type,
                                'post_status' => $post_status,
                                'category__in' => 257,
                                'order' => $order,
                                'posts_per_page' => $posts_per_page,
                            );
                            
                            $loop = new WP_Query( $options );
                                
                            if($loop->have_posts()) :
                                while($loop->have_posts()) : $loop->the_post();
                                    ?>
                                        <div class="container-popular-news">
                                            <a class="popular-news" href="<?= the_permalink();?>">
                                                <?php the_post_thumbnail(); ?>
                                                <div class="article">
                                                <p><?php the_title(); ?></p>
                                                    <div class="row">
                                                        <p class="category"><?php echo             get_the_category_list(', '); ?> 
                                                        </p>
                                                        <p class="date"> • <?php echo get_the_date(); ?></p> 
                                                    </div>
                                                </div>
                                            </a>
                                        </div>
                                    <?php
                                endwhile;
                                
                                
                        		
                            endif;
                            
                            wp_reset_query();
                        ?>
                    
                    
                    </div>
                    <!-- END::PR Article-->
                </div>
                
                
              </div> <!-- END tabs-content -->
            </div> <!-- END tabs -->

        
        
        
    </section>
    
    <?php
        $myvariable = ob_get_clean();

        return $myvariable;
    ?>
            	
    <?php



}

add_shortcode('ams-latest-article-you-should-know', 'latest_article_you_should_know');


?>