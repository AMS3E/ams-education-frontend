<?php

function episode_carousel_multiple($atts){

    ob_start();
    
    ?>
    <section id="episode-carousel">
    	
    	<div class="epi-header">
    	    <!--<h5 class="epi-title-header"><?php echo $atts['title']; ?></h5>-->
    	    <ul id="tabs-nav-carousel" class="header-epi-title">

                
                <li style="width:80px;color:#fff;"><a href="#tab1" class="title-header">រដូវកាលទី ១</a></li>
                <span style="margin-left:15px;margin-right:15px;">/</span>
                <li style="width:80px;color:#fff;"><a href="#tab2" class="title-header">រដូវកាលទី ២</a></li>
            
            </ul>
            
            <p class="epi-link-header"><a href="<?php echo $atts['href']; ?>">មើលទាំងអស់ ➧</a></p>
          
         </div>
          
          <div class="tabs">
  
              <div id="tabs-content">
                  
                <div id="tab1" class="tab-content-carousel">
                      <div class="swiper-container">
                
        		<div class="swiper-wrapper">
        		    
        		    <?php
        		     $tv_show_num = $atts['tv_show_num'];
        		     
        		     $season_num = $atts['season'] - 1;
        		    
        		        extract(shortcode_atts( array(
                            'post_type' => 'post_type',
                            'post_status' => 'post_status',
                            'nopaging' => true,
                            'meta_key' => '_episode_number',
                            'meta_query' => array(
                                'relation' => 'AND',
                                array(
                                    'key' => '_tv_show_id',
                                    'value' => $tv_show_num,
                                ),
                                array(
                                    'key' => '_tv_show_season_id',
                                    'value' => $season_num,
                                    'compare' => 'LIKE',
                                )
                            ),
                            'orderby' => array(
                                '_episode_number' => 'DESC',
                                'date' => 'DESC',
                            ),
                        ), $atts));
                        
                        
                        $options = array(
                            'post_type' => $post_type,
                            'post_status' => $post_status,
                            'nopaging' => true,
                            'meta_key' => '_episode_number',
                            'meta_query' => array(
                                'relation' => 'AND',
                                array(
                                    'key' => '_tv_show_id',
                                    'value' => $tv_show_num,
                                ),
                                array(
                                    'key' => '_tv_show_season_id',
                                    'value' => $season_num,
                                    'compare' => 'LIKE',
                                )
                            ),
                            'orderby' => array(
                                '_episode_number' => 'DESC',
                                'date' => 'DESC',
                            ),
                            
                        );
         
                        $loop = new WP_Query($options);
                        
                        $posts = $loop->get_posts();
                        
                        usort($posts, function($a, $b) {
                                $a_num = intval(substr($a->ID, 0));
                                $b_num = intval(substr($b->ID, 0));
                                
                                return $b_num - $a_num;
    
                        });
                        
                        foreach ($posts as $post) {
                            setup_postdata($post);
                        ?>
                            <div class="swiper-slide">
                                <div class="card-episode">
                                    <a class="link-episode" href="<?= get_permalink($post->ID);?>">
                                        <?php echo get_the_post_thumbnail( $post->ID, 'large' ); ?>
                                        <div class="block-epi-num">
                                            <p class="epi-num" style="font-size:10px !important; color:#7f8c8d;margin-bottom:0px;margin-top:10px;"><?php echo get_post_meta($post->ID, '_episode_number', true) ?></p>
                                        </div>
                                        <div class="block-title">
                                            <p class="epi-title" style="color:#fff;font-weight:bold;font-size:14px;"><?php echo get_the_title($post->ID); ?></p>
                                        </div>
                                    </a>
                                </div>
                            </div>
                        <?php
                        }
                        
                        wp_reset_postdata();


                        
        		    ?>
   
        		</div>  
        		
        	
    	         	<div class="swiper-button-prev"><img src="https://s3.ams.com.kh/infotainment/2023/04/left-arrow-1.png"></div>
                    <div class="swiper-button-next"><img src="https://s3.ams.com.kh/infotainment/2023/04/arrow-right.png"></div>
    		   
     
        	</div>
                </div>
                <!--END::Tab 1-->

                <div id="tab2" class="tab-content-carousel">
                      <div class="swiper-container">
                
        		<div class="swiper-wrapper">
        		    
        		    <?php
                        
                        $options = array(
                            'post_type' => 'episode',
                            'post_status' => 'publish',
                            'posts_per_page' => 100,
                            'orderby' => 'meta_value',
                            'meta_key' => '_episode_number',
                            'order' => 'DESC',
                            'meta_query' => array(
                                'relation' => 'AND',
                                array(
                                    'key' => '_tv_show_id',
                                    'value' => $tv_show_num,
                                ),
                                array(
                                    'key' => '_tv_show_season_id',
                                    'value' => 1,
                                    'compare' => 'LIKE',
                                )
                            )
                        );
                        
                        $loop = new WP_Query( $options );
                        
                        if($loop->have_posts()) :
                            while($loop->have_posts()) : $loop->the_post();
                            $id = get_the_ID();
                                ?>
                                
                                    <div class="swiper-slide">
                                        <div class="card-episode">
                                            <a class="link-episode" href="<?= the_permalink();?>">
                                                <?php the_post_thumbnail(); ?>
                                                <div class="block-epi-num">
                                                    <p class="epi-num" style="font-size:10px !important; color:#7f8c8d;margin-bottom:0px;margin-top:10px;"><?php echo get_post_meta($id, '_episode_number', true) ?></p>
                                                </div>
                                                <div class="block-title">
                                                    <p class="epi-title" style="color:#fff;font-weight:bold;font-size:14px;"><?php echo get_the_title(); ?></p>
                                                </div>
                                            </a>
                                        </div>
                                    </div>
                                
                                <?php
                            endwhile;
                            
                            
                    		
                        endif;
                        
                        wp_reset_query();
                        
        		    ?>
        		    
        		    
        			
        		</div>  
        		    
        	         	<div class="swiper-button-prev"><img src="https://s3.ams.com.kh/infotainment/2023/04/left-arrow-1.png"></div>
                        <div class="swiper-button-next"><img src="https://s3.ams.com.kh/infotainment/2023/04/arrow-right.png"></div>
        		   
        		    
     
        	</div>  
                </div>
                <!--END::Tab 2-->
            
                
                
              </div> <!-- END tabs-content -->
            </div> <!-- END tabs -->
            
          
          
        	

        		
	</section>
    
    <?php
        $myvariable = ob_get_clean();

        return $myvariable;
    ?>
            	
    <?php





}


add_shortcode('epsode-carousel-multiple', 'episode_carousel_multiple');




?>