<?php



function popular_news_text($atts){
    
    ob_start();
    
    ?>
    
    <section class="section-popular-news-text">
        <div class="col-lg-12 panel-popular-news-text">
            <div class="d-flex justify-content-between" style="padding-top:50px;">
                <h2 class="section-title">ប្រធានបទពេញនិយម</h2>
                <a class="btnPopularNewsText" href="<?php echo $atts['href']; ?>"> មើលទាំងអស់ ➧</a>
            </div>
            
            <!-- START::Popular News Text-->
            <div class="popular-news-text">
    
            <?php
        
                extract(shortcode_atts( array(
                    'post_type' => 'post_type',
                    'post_status' => 'post_status',
                    'category__in' => 'category__in',
                    'orderby' => 'orderby',
                    'posts_per_page' => 'posts_per_page',
                ), $atts));
                
                
                $options = array(
                    'post_type' => $post_type,
                    'post_status' => $post_status,
                    'category__in' => $category__in,
                    'orderby' => $orderby,
                    'posts_per_page' => $posts_per_page,
                );
                
                $loop = new WP_Query( $options );
                    
                if($loop->have_posts()) :
                    while($loop->have_posts()) : $loop->the_post();
                        ?>
                            <div class="container-popular-news-text">
                                <a class="read-news" href="<?= the_permalink();?>">
                                    <div class="article">
                                        <p class="number"><?php echo $loop->current_post + 1; ?></p>
                                    <p><?php the_title(); ?></p>
                                       
                                    </div>
                                </a>
                            </div>
                        <?php
                    endwhile;
                    
                    
            		
                endif;
                
                wp_reset_query();
            ?>
        
        
        </div>
        <!-- END::Popular News Text-->

        
        
        
    </section>
    
    <?php
        $myvariable = ob_get_clean();

        return $myvariable;
    ?>
            	
    <?php



}

add_shortcode('popular-news-text', 'popular_news_text');


?>