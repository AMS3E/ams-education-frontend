<?php



function section_latest_news($atts){
    
    ob_start();
    
    ?>
    
    <section class="latest-news">
        <div class="col-lg-12 panel-latest-news">
            <div class="d-flex justify-content-between" style="padding-top:50px;">
                <h2 class="section-title">ព័ត៌មានថ្មីបំផុត</h2>
                <a class="btnTodayNews txtSectionNews01" href="<?php echo $atts['href']; ?>">មើលទាំងអស់ ➧</a>
            </div>
            <!-- START::Report News-->
            <div class="popular-news">
    
            <?php
        
                extract(shortcode_atts( array(
                    'post_type' => 'post_type',
                    'post_status' => 'post_status',
                    'category__in' => 'category__in',
                    'order' => 'order',
                    'posts_per_page' => 'posts_per_page',
                ), $atts));
                
                
                $options = array(
                    'post_type' => $post_type,
                    'post_status' => $post_status,
                    'category__in' => $category__in,
                    'order' => $order,
                    'posts_per_page' => $posts_per_page,
                );
                
                $loop = new WP_Query( $options );
                    
                if($loop->have_posts()) :
                    while($loop->have_posts()) : $loop->the_post();
                        ?>
                            <div class="container-latest-news">
                                <a class="latest-news" href="<?= the_permalink();?>">
                                    <?php the_post_thumbnail(); ?>
                                    <div class="article">
                                        <p><?php the_title(); ?></p>
                                        <div class="row">
                                            <p class="category"><?php echo             get_the_category_list(', '); ?> 
                                            </p>
                                            <p class="date"> • <?php echo get_the_date(); ?></p> 
                                        </div>
                                        <p class="article-except"><?php echo get_the_excerpt(); ?></p>
                                    </div>
                                </a>
                            </div>
                        <?php
                    endwhile;
                    
                    
            		
                endif;
                
                wp_reset_query();
            ?>
        
        
        </div>
        <!-- END::Report News-->
        
        
    </section>
    
    <?php
        $myvariable = ob_get_clean();

        return $myvariable;
    ?>
            	
    <?php



    
}

add_shortcode('section-latest-news', 'section_latest_news');


?>