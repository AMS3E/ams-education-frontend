<?php



function pr_articles($atts){
    
    ob_start();
    
    ?>

    
    <section class="section-pr-articles">
        <div class="col-lg-12 panel-pr-articles">
            <div class="d-flex justify-content-between">
                <h2 class="section-title">អត្ថបទពាណិជ្ជកម្ម</h2>
                <a class="" href="https://economy.ams.com.kh/category/all-news/news-pr"style="font-weight:bold;">មើលទាំងអស់ ➧</a>
            </div>
            <!-- START::PR Articles-->
            <div class="pr_articles">
    
            <?php
        
                extract(shortcode_atts( array(
                    'post_type' => 'post_type',
                    'post_status' => 'post_status',
                    'category__in' => 'category__in',
                    'orderby' => 'orderby',
                    'posts_per_page' => 'posts_per_page',
                ), $atts));
                
                
                $options = array(
                    'post_type' => $post_type,
                    'post_status' => $post_status,
                    'category__in' => $category__in,
                    'orderby' => $orderby,
                    'posts_per_page' => $posts_per_page,
                );
                
                $loop = new WP_Query( $options );
                    
                if($loop->have_posts()) :
                    while($loop->have_posts()) : $loop->the_post();
                        ?>
                            <div class="container-pr-articles">
                                <a class="pr-articles" href="<?= the_permalink();?>">
                                    <?php the_post_thumbnail(); ?>
                                    <div class="article">
                                    <p><?php the_title(); ?></p>
                                        <div class="row">
                                            <p class="category"><?php echo             get_the_category_list(', '); ?> 
                                            </p>
                                            <p class="date"> • <?php echo get_the_date(); ?></p> 
                                        </div>
                                    </div>
                                </a>
                            </div>
                        <?php
                    endwhile;
                    
                    
            		
                endif;
                
                wp_reset_query();
            ?>
        
        
        </div>
        <!-- END::PR Articles-->
        
        
    </section>
    
    <?php
        $myvariable = ob_get_clean();

        return $myvariable;
    ?>
            	
    <?php



}

add_shortcode('pr-articles', 'pr_articles');


?>