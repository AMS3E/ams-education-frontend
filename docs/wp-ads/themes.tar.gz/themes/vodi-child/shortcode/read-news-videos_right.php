<?php



function ams_read_news_videos_right($atts){
    
    ob_start();
    
    ?>

    
    <section class="video-read-news-right">
        <div class="row panel-read-news-right">
            
            <div class="col-md-12">
                <div class="d-flex justify-content-between" style="padding-top:50px;">
                <h2 class="section-title">ព័ត៌មានទូទៅ</h2>
                <a class="btnReadNews" href="https://economy.ams.com.kh/economic/read-news"style="font-weight:bold;">មើលទាំងអស់ ➧</a>
                    </div>
                    <!-- START::Read News-->
                    <div class="read-news">
            
                    <?php
                
                        extract(shortcode_atts( array(
                            'post_type' => 'post_type',
                            'post_status' => 'post_status',
                            'tag_ID' => 'tag_ID',
                            'orderby' => 'orderby',
                            'posts_per_page' => 'posts_per_page',
                        ), $atts));
                        
                        
                        $options = array(
                            'post_type' => $post_type,
                            'post_status' => $post_status,
                            'tag_ID' => $tag_ID,
                            'orderby' => $orderby,
                            'posts_per_page' => $posts_per_page,
                        );
                        
                        $loop = new WP_Query( $options );
                            
                        if($loop->have_posts()) :
                            while($loop->have_posts()) : $loop->the_post();
                                ?>
                                    <div class="container-read-news">
                                        <a class="read-news" href="<?= the_permalink();?>">
                                            <?php the_post_thumbnail(); ?>
                                            <div class="article">
                                            <p><?php the_title(); ?></p>
                                                <button>< ទស្សនាឥឡូវនេះ</button>
                                            </div>
                                        </a>
                                    </div>
                                <?php
                            endwhile;
                            
                            
                    		
                        endif;
                        
                        wp_reset_query();
                    ?>
                
                
                </div>
                <!-- END::Read News-->
                
            </div>
            
            
            
            
            
        
    </section>
    
    <?php
        $myvariable = ob_get_clean();

        return $myvariable;
    ?>
            	
    <?php



}

add_shortcode('ams-read-news-videos-right', 'ams_read_news_videos_right');


?>