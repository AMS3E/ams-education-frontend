<?php



function inclusive_business_news($atts){
    
    ob_start();
    
    ?>
    
    <section class="panelLatestNews">
        <div class="col-lg-12 panel-latest-news">
            <div class="d-flex justify-content-between" style="padding-top:50px;">
                <h2 class="section-title">ព្រឹត្តិការណ៍ប្រចាំថ្ងៃ</h2>
                <a class="btnTodayNews txtSectionNews" href="javascript:void(0);"style="font-weight:bold;">ថ្ងៃនេះ</a>
                <a class="btnYesterdayNews txtSectionNews" href="javascript:void(0);">ម្សិលមិញ</a>
                <a class="btnBeforeYesterday txtSectionNews" href="javascript:void(0);">ម្សិលម្ងៃ</a>
            </div>
            <!-- START::Today News-->
            <div class="today-news">
    
            <?php
        
                extract(shortcode_atts( array(
                    'post_type' => 'post_type',
                    'post_status' => 'post_status',
                    'category__in' => 'category__in',
                    'order' => 'order',
                    'posts_per_page' => 'posts_per_page',
                ), $atts));
                
                
                $options = array(
                    'post_type' => $post_type,
                    'post_status' => $post_status,
                    'category__in' => $category__in,
                    'order' => $order,
                    'posts_per_page' => $posts_per_page,
                );
                
                $loop = new WP_Query( $options );
                    
                if($loop->have_posts()) :
                    while($loop->have_posts()) : $loop->the_post();
                        ?>
                            <div class="container-latest-news">
                                <a class="latest-news" href="<?= the_permalink();?>">
                                    <?php the_post_thumbnail(); ?>
                                    <p><?php the_title(); ?></p>
                                        <p class="category"><?php echo get_the_category_list(', '); ?></p>
                                </a>
                            </div>
                        <?php
                    endwhile;
                    
                    
            		
                endif;
                
                wp_reset_query();
            ?>
        
        
        </div>
        <!-- END::Today News-->
        
        <!-- START::Yesterday News-->
        <div class="yesterday-news" style="display:none;">
            <?php
            
                $options = array(
                    'post_type' => "post",
                    'post_status' => "publish",
                    'category__in' => 12034,
                    'order' => "DESC",
                    'posts_per_page' => 5,
                    'date_query' => array(
                        array(
                        'before' => '1 days ago',
                          )
                      )
                );
                
                $loop = new WP_Query( $options );
                
                if($loop->have_posts()) :
                    while($loop->have_posts()) : $loop->the_post();
                        ?>
                            <div class="container-latest-news">
                                <a class="latest-news" href="<?= the_permalink();?>">
                                    <?php the_post_thumbnail(); ?>
                                    <p><?php the_title(); ?></p>
                                        <p class="category"><?php echo get_the_category_list(', '); ?></p>
                                        <!--<p class="date"><?php echo get_the_date(); ?></p>-->
                                    
                                </a>
                            </div>
                        <?php
                    endwhile;
            		
                endif;
                
                wp_reset_query();
                
            ?>
            
   
        
        </div>
        <!-- END::Yesterday News-->
        
        <!-- START::Today Before Yesterday News-->
        
        <div class="before-yesterday-news" style="display:none;">
            <?php
                
                $options = array(
                    'post_type' => "post",
                    'post_status' => "publish",
                    'category__in' => 12034,
                    'order' => "DESC",
                    'posts_per_page' => 5,
                    'date_query' => array(
                        array(
                        'before' => '2 days ago',
                          )
                      )
                );
                
                $loop = new WP_Query( $options );
                
                if($loop->have_posts()) :
                    while($loop->have_posts()) : $loop->the_post();
                        ?>
                            <div class="container-latest-news">
                                <a class="latest-news" href="<?= the_permalink();?>">
                                    <?php the_post_thumbnail(); ?>
                                    <p><?php the_title(); ?></p>
                                        <p class="category"><?php echo get_the_category_list(', '); ?></p>
                                        <!--<p class="date"><?php echo get_the_date(); ?></p>-->
                                    
                                </a>
                            </div>
                        <?php
                    endwhile;
            		
                endif;
            
                
                wp_reset_query();
                
                

            		
            ?>
            
   
        
        </div>
        
        <!-- END::Today Before Yesterday News-->
        
        
    </section>
    
    <?php
        $myvariable = ob_get_clean();

    return $myvariable;
    ?>
            	
    <?php

    		

	  

            







}

add_shortcode('inclusive-business-news', 'inclusive_business_news');


?>