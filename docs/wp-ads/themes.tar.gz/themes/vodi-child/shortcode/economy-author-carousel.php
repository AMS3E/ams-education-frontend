<?php

function economy_carousel_single($atts){
     ob_start();
    
    ?>
    <section id="episode-carousel-cambodia360-single">
    	
    	<div class="epi-header">
    	    <h5 class="epi-title-header"><?php echo $atts['title']; ?></h5>
    	   
            
            <p class="epi-link-header"><a href="<?php echo $atts['href']; ?>">មើលទាំងអស់ ➧</a></p>
          
         </div>
          
          <div class="tabs">
  
              <div id="tabs-nav-carousel-cambodia360-single">
                  
                <div id="tabSingle" class="tab-content-carousel-cambodia360-single">
                      <div class="swiper-container">
                
        		<div class="swiper-wrapper">
        		    
        		    <?php
                        
                        $request = [
                            'publish_on' => 'economy',
                            'showing_position' => 'author',
                            'position_type' => 'carousel'
                        ];
                        
                        $authors = get_author_list($request);
                        
                        if ($authors->get_status() === 200) {
                            $data = $authors->get_data();
                            $results = $data['data'];
                            
                            foreach ($results as $author) {
                                ?>
                                    <div class="swiper-slide">
                                        <div class="card-episode">
                                            <a class="link-episode" href="">
                                                <img src="<?php echo $author->profile_eco; ?>">
                                                <div class="block-title">
                                                    <p class="epi-title" style="color:#fff;font-weight:bold;font-size:14px;"><?php echo $author->name_kh; ?></p>
                                                </div>
                                            </a>
                                        </div>
                                    </div>
                                <?php
                            }
                        }
                        

                        
        		    ?>
   
        		</div>  
        		
        	
    	         	<div class="swiper-button-prev"><img src="https://infotainment.ams.com.kh/wp-content/uploads/2023/04/left-arrow-1.png"></div>
                    <div class="swiper-button-next"><img src="https://infotainment.ams.com.kh/wp-content/uploads/2023/04/arrow-right.png"></div>
    		   
     
        	</div>
                </div>
                <!--END::Tab 1-->

                
              </div> <!-- END tabs-content -->
            </div> <!-- END tabs -->
            
          
          
        	

        		
	</section>
    
    <?php
        $myvariable = ob_get_clean();

        return $myvariable;
    ?>
            	
    <?php




}


add_shortcode('economy-carousel-author', 'economy_carousel_single');




?>