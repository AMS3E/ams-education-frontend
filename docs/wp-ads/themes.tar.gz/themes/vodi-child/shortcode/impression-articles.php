<?php



function impression_articles($atts){
    
    ob_start();
    
    ?>

    
    <section class="section-impression-articles">
        <div class="col-lg-12 panel-impression-articles">
            <div class="d-flex justify-content-between" style="padding-top:50px;">
                <h2 class="section-title">ចំណាប់អារម្មណ៍របស់ប្រិយមិត្ត</h2>
                <a class="" href="https://economy.ams.com.kh/category/all-news/"style="font-weight:bold;">មើលទាំងអស់ ➧</a>
            </div>
            <!-- START::Impression Articles-->
            <div class="impression-articles">
    
            <?php
        
                extract(shortcode_atts( array(
                    'post_type' => 'post_type',
                    'post_status' => 'post_status',
                    'category__in' => 'category__in',
                    'orderby' => 'orderby',
                    'posts_per_page' => 'posts_per_page',
                ), $atts));
                
                
                $options = array(
                    'post_type' => $post_type,
                    'post_status' => $post_status,
                    'category__in' => $category__in,
                    'orderby' => $orderby,
                    'posts_per_page' => $posts_per_page,
                );
                
                $loop = new WP_Query( $options );
                    
                if($loop->have_posts()) :
                    while($loop->have_posts()) : $loop->the_post();
                        ?>
                            <div class="container-impression-articles">
                                <a class="impression-articles" href="<?= the_permalink();?>">
                                    <?php the_post_thumbnail(); ?>
                                    <div class="article">
                                    <p><?php the_title(); ?></p>
                                        <div class="row">
                                            <p class="category"><?php echo             get_the_category_list(', '); ?> 
                                            </p>
                                            <p class="date"> • <?php echo get_the_date(); ?></p> 
                                        </div>
                                    </div>
                                </a>
                            </div>
                        <?php
                    endwhile;
                    
                    
            		
                endif;
                
                wp_reset_query();
            ?>
        
        
        </div>
        <!-- END::Impression Articles-->
        
        
    </section>
    
    <?php
        $myvariable = ob_get_clean();

        return $myvariable;
    ?>
            	
    <?php



}

add_shortcode('ams-impression_articles', 'impression_articles');


?>