
    function getCookie(cname) {
      let name = cname + "=";
      let decodedCookie = decodeURIComponent(document.cookie);
      let ca = decodedCookie.split(';');
      for(let i = 0; i <ca.length; i++) {
        let c = ca[i];
        while (c.charAt(0) == ' ') {
          c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
          return c.substring(name.length, c.length);
        }
      }
      return "";
    }
    
    
    function updateMode(mode) {
        
        const date = new Date();
        const time = date.getHours();
         
         if (mode == "light") {
            document.querySelectorAll('.dropdown-button').forEach(button => (button.querySelector('img').src = 'https://economy.ams.com.kh/wp-content/uploads/2023/08/soleil.svg') && (button.querySelector('img').style.filter = 'none'));
            localStorage.setItem('bgColor', '#fff');
            document.body.classList.remove("night");
            document.cookie = 'bgColor=#fff; expires=7; path=/';
            document.body.style.background = "#fff";
        } else if (mode == "dark") {
            document.querySelectorAll('.dropdown-button').forEach(button => (button.querySelector('img').src = 'https://economy.ams.com.kh/wp-content/uploads/2023/08/Night-02.svg') && (button.querySelector('img').style.filter = 'invert(1)'));
            localStorage.setItem('bgColor', '#1f1f1f');
            document.body.classList.add("night");
            document.cookie = 'bgColor=#1f1f1f; expires=7; path=/';
            document.body.style.background = "#1f1f1f";
        } else {
            
            if (time >= 18 || time < 5) { // Time is between 6 PM and 5 AM
                document.querySelectorAll('.dropdown-button').forEach(button => (button.querySelector('img').src = 'https://economy.ams.com.kh/wp-content/uploads/2023/08/Day-Time-02.svg') && (button.querySelector('img').style.filter = 'invert(1)'));
                localStorage.setItem('bgColor', '#1f1f1f');
                document.body.classList.add("night");
                document.cookie = 'bgColor=#1f1f1f; expires=7; path=/';
                document.body.style.background = "#1f1f1f";
                
            } else {
                document.querySelectorAll('.dropdown-button').forEach(button => (button.querySelector('img').src = 'https://economy.ams.com.kh/wp-content/uploads/2023/08/Day-Time-02.svg') && (button.querySelector('img').style.filter = 'none'));
                localStorage.setItem('bgColor', '#fff');
                document.body.classList.remove("night");
                document.cookie = 'bgColor=#fff; expires=7; path=/';
                document.body.style.background = "#fff";
                
            }
        }
         
    }
    
    
    jQuery(document).ready(function($) {
        
        const mode_local = localStorage.getItem('mode');
        
        updateMode(mode_local);
        
       $('.dropdown-button').click(function() {
          $(this).siblings('.dropdown-content').toggle();
        });
    
        $('.dropdown-item').click(function() {
          var dataId = $(this).data('id');
          
          localStorage.setItem('mode', dataId);
          updateMode(dataId);
          
          $('.dropdown-content').hide();
    
        //   var selectedItemIcon = $(this).find('img').prop('outerHTML');
        //   $('.dropdown-button').html(selectedItemIcon); // Change the button content
        });
    
        $(document).click(function(event) {
          var target = $(event.target);
          if (!target.closest('.dropdown-darkmode').length) {
            $('.dropdown-content').hide();
          }
        });
        
    
    });  
    
        
        

   