<?php
/**
 * Data + render helpers for the "Unlock The Life" watch page
 * (pages/template-unlock-the-life.php), shared with the AJAX handler below
 * so that switching season/episode swaps content in place instead of doing
 * a full page reload.
 */

if ( ! defined( 'UNLOCK_THE_LIFE_SHOW_SLUG' ) ) {
	define( 'UNLOCK_THE_LIFE_SHOW_SLUG', 'unlock-the-life' );
}

function utl_get_show() {
	$posts = get_posts( array(
		'post_type'      => 'tv_show',
		'name'           => UNLOCK_THE_LIFE_SHOW_SLUG,
		'post_status'    => 'publish',
		'posts_per_page' => 1,
	) );
	return ! empty( $posts ) ? $posts[0] : null;
}

function utl_vimeo_id_from_url( $url ) {
	if ( empty( $url ) ) {
		return '';
	}
	$id = substr( $url, 18 );
	if ( ! ctype_digit( $id ) && preg_match( '/(\d+)\/?$/', $url, $m ) ) {
		$id = $m[1];
	}
	return $id;
}

function utl_season_numerals() {
	return array( '១', '២', '៣', '៤', '៥', '៦', '៧', '៨', '៩', '១០' );
}

/**
 * Resolves the seasons list, current episode/season, and episodes-in-season
 * for a show, honoring explicit $requested_ep/$requested_season overrides.
 * Falls back to the latest episode overall, then to that episode's season -
 * same precedence the page has always used for direct links.
 */
function utl_resolve_watch_state( $tv_show_id, $requested_ep = 0, $requested_season = null ) {
	$state = array(
		'seasons'            => array(),
		'current_episode'    => null,
		'current_season'     => 0,
		'episodes_in_season' => array(),
	);

	if ( ! $tv_show_id ) {
		return $state;
	}

	global $wpdb;
	// Seasons are ordered by their most recently posted episode (not by
	// season number), so a season that just got a new upload jumps to the
	// top of the dropdown.
	$season_rows = $wpdb->get_results( $wpdb->prepare(
		"SELECT season.meta_value AS season_id, MAX(p.post_date) AS last_post_date
		 FROM {$wpdb->postmeta} season
		 INNER JOIN {$wpdb->postmeta} show ON show.post_id = season.post_id
		 INNER JOIN {$wpdb->posts} p ON p.ID = season.post_id
		 WHERE season.meta_key = '_tv_show_season_id'
		 AND show.meta_key = '_tv_show_id' AND show.meta_value = %d
		 AND p.post_status = 'publish'
		 GROUP BY season.meta_value
		 ORDER BY last_post_date DESC",
		$tv_show_id
	) );
	$state['seasons'] = array_map( function ( $row ) {
		return (int) $row->season_id;
	}, $season_rows );

	$current_episode = null;
	if ( $requested_ep ) {
		$maybe_episode = get_post( $requested_ep );
		if ( $maybe_episode && 'episode' === $maybe_episode->post_type && 'publish' === $maybe_episode->post_status
			&& (int) get_post_meta( $maybe_episode->ID, '_tv_show_id', true ) === $tv_show_id ) {
			$current_episode = $maybe_episode;
		}
	}

	if ( ! $current_episode ) {
		$latest = get_posts( array(
			'post_type'      => 'episode',
			'post_status'    => 'publish',
			'posts_per_page' => 1,
			'orderby'        => 'date',
			'order'          => 'DESC',
			'meta_query'     => array(
				array(
					'key'   => '_tv_show_id',
					'value' => $tv_show_id,
				),
			),
		) );
		$current_episode = ! empty( $latest ) ? $latest[0] : null;
	}

	$current_season = null !== $requested_season ? $requested_season
		: ( $current_episode ? (int) get_post_meta( $current_episode->ID, '_tv_show_season_id', true ) : 0 );

	$episodes_in_season = get_posts( array(
		'post_type'      => 'episode',
		'post_status'    => 'publish',
		'posts_per_page' => 100,
		'orderby'        => 'date',
		'order'          => 'DESC',
		'meta_query'     => array(
			'relation' => 'AND',
			array(
				'key'   => '_tv_show_id',
				'value' => $tv_show_id,
			),
			array(
				'key'   => '_tv_show_season_id',
				'value' => $current_season,
			),
		),
	) );

	$state['current_episode']    = $current_episode;
	$state['current_season']     = $current_season;
	$state['episodes_in_season'] = $episodes_in_season;

	return $state;
}

function utl_render_video_block( $current_episode ) {
	ob_start();
	?>
	<div class="video-wrapper">
		<div class="video-player">
			<?php if ( $current_episode ) :
				$vimeo_id = utl_vimeo_id_from_url( get_post_meta( $current_episode->ID, '_episode_url_link', true ) );
				?>
				<?php if ( $vimeo_id ) : ?>
					<iframe
						src="https://player.vimeo.com/video/<?php echo esc_attr( $vimeo_id ); ?>?title=0&byline=0&portrait=0"
						title="<?php echo esc_attr( get_the_title( $current_episode ) ); ?>"
						frameborder="0"
						allow="autoplay; fullscreen; picture-in-picture; clipboard-write; encrypted-media; web-share"
						allowfullscreen
					></iframe>
				<?php endif; ?>
			<?php endif; ?>
		</div>
	</div>

	<div class="video-meta">
		<h1 class="video-title"><?php echo $current_episode ? esc_html( get_the_title( $current_episode ) ) : esc_html__( 'No episode available yet', 'vodi-child' ); ?></h1>
		<?php if ( $current_episode ) :
			$duration = get_post_meta( $current_episode->ID, '_episode_duration_text', true );
			?>
			<p class="video-sub">
				<?php if ( $duration ) : ?><?php echo esc_html( $duration ); ?>&nbsp;|&nbsp;<?php endif; ?>
				Added: <?php echo esc_html( mysql2date( 'd.m.Y', $current_episode->post_date ) ); ?>
			</p>
		<?php endif; ?>
	</div>
	<?php
	return ob_get_clean();
}

function utl_render_description( $current_episode ) {
	ob_start();
	?>
	<h2 class="box-title">Description</h2>
	<p class="description-text">
		<?php echo $current_episode ? esc_html( wp_strip_all_tags( $current_episode->post_content ) ) : ''; ?>
	</p>
	<?php
	return ob_get_clean();
}

function utl_render_season_dropdown( $seasons, $current_season, $base_url = false ) {
	$season_numerals = utl_season_numerals();
	ob_start();
	foreach ( $seasons as $season_value ) :
		$is_active  = $season_value === $current_season;
		$season_url = add_query_arg( array( 'season' => $season_value ), remove_query_arg( 'ep', $base_url ) );
		?>
		<li class="<?php echo $is_active ? 'active' : ''; ?>">
			<a href="<?php echo esc_url( $season_url ); ?>" data-season="<?php echo esc_attr( $season_value ); ?>">
				រដូវកាលទី​ <?php echo esc_html( isset( $season_numerals[ $season_value ] ) ? $season_numerals[ $season_value ] : ( $season_value + 1 ) ); ?>
			</a>
		</li>
		<?php
	endforeach;
	return ob_get_clean();
}

function utl_render_episode_list( $episodes_in_season, $current_episode, $current_season, $default_asset_uri, $base_url = false ) {
	ob_start();
	foreach ( $episodes_in_season as $ep ) :
		$is_active   = $current_episode && $ep->ID === $current_episode->ID;
		$ep_url      = add_query_arg( array(
			'season' => $current_season,
			'ep'     => $ep->ID,
		), $base_url );
		$ep_duration = get_post_meta( $ep->ID, '_episode_duration_text', true );
		?>
		<li class="episode-item<?php echo $is_active ? ' active' : ''; ?>">
			<a href="<?php echo esc_url( $ep_url ); ?>" data-ep="<?php echo esc_attr( $ep->ID ); ?>" data-season="<?php echo esc_attr( $current_season ); ?>" style="display:flex;gap:10px;align-items:center;width:100%;">
				<?php $ep_thumb = get_the_post_thumbnail_url( $ep, 'medium' ); ?>
				<img class="episode-thumb" src="<?php echo esc_url( $ep_thumb ? $ep_thumb : $default_asset_uri . '/episode-thumb.svg' ); ?>" alt="" />
				<div class="episode-info">
					<p class="episode-title"><?php echo esc_html( get_the_title( $ep ) ); ?></p>
					<p class="episode-meta">
						<?php if ( $ep_duration ) : ?><?php echo esc_html( $ep_duration ); ?> | <?php endif; ?>
						Added: <?php echo esc_html( mysql2date( 'd.m.Y', $ep->post_date ) ); ?>
					</p>
				</div>
			</a>
		</li>
		<?php
	endforeach;
	return ob_get_clean();
}

function utl_season_label( $current_season ) {
	$season_numerals = utl_season_numerals();
	return 'រដូវកាលទី​ ' . ( isset( $season_numerals[ $current_season ] ) ? $season_numerals[ $current_season ] : ( $current_season + 1 ) );
}

function utl_enqueue_watch_assets() {
	if ( ! is_page_template( 'pages/template-unlock-the-life.php' ) ) {
		return;
	}
	wp_enqueue_script( 'unlock-the-life', get_stylesheet_directory_uri() . '/js/unlock-the-life.js', array(), '1.5', true );
	wp_localize_script( 'unlock-the-life', 'utlWatch', array(
		'restUrl' => rest_url( 'wp/v2/unlock-the-life-episode' ),
	) );
}
add_action( 'wp_enqueue_scripts', 'utl_enqueue_watch_assets' );

/**
 * Public, read-only endpoint (same pattern as the other wp/v2 routes in this
 * file) - deliberately not nonce-gated like admin-ajax.php would be, since
 * this just re-renders public page content and a stale/expired nonce (long
 * -lived tab, cached page) would otherwise make season/episode switching
 * silently fall back to a full page reload.
 */
add_action( 'rest_api_init', function () {
	register_rest_route( 'wp/v2', 'unlock-the-life-episode', array(
		'methods'             => 'GET',
		'callback'            => 'utl_rest_get_episode',
		'permission_callback' => '__return_true',
	) );
} );

function utl_rest_get_episode( $request ) {
	$tv_show = utl_get_show();
	if ( ! $tv_show ) {
		return new WP_Error( 'utl_no_show', 'Show not found.', array( 'status' => 404 ) );
	}

	$requested_ep     = absint( $request->get_param( 'ep' ) );
	$requested_season = null !== $request->get_param( 'season' ) ? absint( $request->get_param( 'season' ) ) : null;

	// Links rendered here need the actual page URL, not this REST endpoint's
	// own URL (which is what add_query_arg()/remove_query_arg() would default
	// to) - the client sends its current pathname for that.
	$base_url      = false;
	$client_path   = $request->get_param( 'page_url' );
	$parsed_path   = $client_path ? wp_parse_url( $client_path, PHP_URL_PATH ) : '';
	if ( $parsed_path ) {
		$base_url = $parsed_path;
	}

	$state = utl_resolve_watch_state( $tv_show->ID, $requested_ep, $requested_season );

	$default_asset_uri = get_stylesheet_directory_uri() . '/assets/unlock-the-life';

	return array(
		'video_html'           => utl_render_video_block( $state['current_episode'] ),
		'description_html'     => utl_render_description( $state['current_episode'] ),
		'episode_list_html'    => utl_render_episode_list( $state['episodes_in_season'], $state['current_episode'], $state['current_season'], $default_asset_uri, $base_url ),
		'season_dropdown_html' => utl_render_season_dropdown( $state['seasons'], $state['current_season'], $base_url ),
		'season_label'         => utl_season_label( $state['current_season'] ),
		'title'                => ( $state['current_episode'] ? get_the_title( $state['current_episode'] ) : esc_html__( 'No episode available yet', 'vodi-child' ) ) . ' - ' . get_bloginfo( 'name' ),
		'query'                => array(
			'season' => $state['current_season'],
			'ep'     => $state['current_episode'] ? $state['current_episode']->ID : 0,
		),
	);
}
