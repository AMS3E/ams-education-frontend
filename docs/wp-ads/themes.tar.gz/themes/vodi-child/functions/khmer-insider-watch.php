<?php
/**
 * Data + render helpers for the shared "watch page" template
 * (templates/movie-watch-page.php, forced via the template_include filter
 * below for every movie post linked to a tv_show via khi_show_id_for_movie()),
 * shared with the REST endpoint below so that switching season/episode swaps content in place
 * instead of doing a full page reload. Mirrors functions/unlock-the-life-watch.php
 * - see that file for the fuller rationale comments (nonce-free REST over
 * admin-ajax, sort-by-latest-post, base_url handling for AJAX-rendered
 * links, etc.).
 *
 * Despite the "khi_" prefix (kept from the original Khmer Insider-only
 * build), everything here is show-agnostic and driven by $show_id.
 */

/**
 * Which "tv_show" CPT post actually owns a given "movie" CPT post's
 * episodes, read from the '_khi_tv_show_id' postmeta set via the "Watch
 * Page: Linked TV Show" meta box below (add_meta_boxes hook, movie edit
 * screen). Can't resolve this by matching post_name - several shows have a
 * tv_show post whose slug doesn't match the movie's slug, so this has to be
 * an explicit per-movie link rather than derived from post_type alone.
 */
function khi_show_id_for_movie( $movie_id ) {
	return absint( get_post_meta( $movie_id, '_khi_tv_show_id', true ) );
}

/**
 * Lowercased/whitespace-collapsed title, used only for matching a movie to
 * its tv_show below - not for display.
 */
function khi_normalize_title_for_matching( $title ) {
	return strtolower( trim( preg_replace( '/\s+/', ' ', wp_strip_all_tags( $title ) ) ) );
}

/**
 * One-time migration: seeds '_khi_tv_show_id' for every 'movie' post that
 * doesn't have it yet, by matching it against every 'tv_show' post with the
 * same title (movie/tv_show pairs on this site are titled identically, e.g.
 * movie "The Legacy" <-> tv_show "The Legacy", even though their slugs often
 * differ - see khi_show_id_for_movie()). Gated by the
 * 'khi_tv_show_map_migrated' option so it only runs once; any pair this
 * can't match (title mismatch, or a movie that isn't a show hub at all -
 * see khi_render_video_block()'s standalone-movie branch) is still linked
 * (or left unlinked) via the "Watch Page: Linked TV Show" meta box.
 */
function khi_migrate_legacy_watch_show_map() {
	if ( get_option( 'khi_tv_show_map_migrated' ) ) {
		return;
	}

	$movie_ids = get_posts( array(
		'post_type'      => 'movie',
		'post_status'    => 'any',
		'posts_per_page' => -1,
		'fields'         => 'ids',
	) );

	$tv_shows_by_title = array();
	foreach ( get_posts( array(
		'post_type'      => 'tv_show',
		'post_status'    => 'any',
		'posts_per_page' => -1,
	) ) as $tv_show ) {
		$tv_shows_by_title[ khi_normalize_title_for_matching( $tv_show->post_title ) ] = $tv_show->ID;
	}

	foreach ( $movie_ids as $movie_id ) {
		if ( get_post_meta( $movie_id, '_khi_tv_show_id', true ) ) {
			continue;
		}
		$title = khi_normalize_title_for_matching( get_the_title( $movie_id ) );
		if ( isset( $tv_shows_by_title[ $title ] ) ) {
			update_post_meta( $movie_id, '_khi_tv_show_id', $tv_shows_by_title[ $title ] );
		}
	}

	update_option( 'khi_tv_show_map_migrated', 1 );
}
add_action( 'init', 'khi_migrate_legacy_watch_show_map' );

/**
 * "Watch Page: Linked TV Show" meta box on the movie edit screen - lets an
 * admin pick which tv_show post supplies this movie's watch-page episodes,
 * instead of that link being hardcoded in code (see khi_show_id_for_movie()).
 */
add_action( 'add_meta_boxes', function () {
	add_meta_box(
		'khi_tv_show_link',
		__( 'Watch Page: Linked TV Show', 'vodi-child' ),
		'khi_render_tv_show_link_meta_box',
		'movie',
		'side'
	);
} );

function khi_render_tv_show_link_meta_box( $post ) {
	wp_nonce_field( 'khi_save_tv_show_link', 'khi_tv_show_link_nonce' );
	$current = get_post_meta( $post->ID, '_khi_tv_show_id', true );

	// Episodes are matched by ID via '_tv_show_id' postmeta regardless of the
	// linked post's own post_type, and on this site some show hubs were
	// authored as 'movie' posts rather than 'tv_show' - so both are valid
	// link targets. Excludes the movie being edited to prevent self-linking.
	$shows = get_posts( array(
		'post_type'      => array( 'tv_show', 'movie' ),
		'post_status'    => 'any',
		'posts_per_page' => -1,
		'post__not_in'   => array( $post->ID ),
		'orderby'        => 'title',
		'order'          => 'ASC',
	) );
	?>
	<p><?php esc_html_e( "This movie's watch page pulls its episodes from:", 'vodi-child' ); ?></p>
	<select name="khi_tv_show_id" id="khi_tv_show_id" style="width:100%;">
		<option value=""><?php esc_html_e( '— None —', 'vodi-child' ); ?></option>
		<?php foreach ( $shows as $show ) : ?>
			<option value="<?php echo esc_attr( $show->ID ); ?>" <?php selected( $current, $show->ID ); ?>>
				<?php echo esc_html( $show->post_title . ' (' . $show->post_type . ' #' . $show->ID . ')' ); ?>
			</option>
		<?php endforeach; ?>
	</select>
	<?php
}

add_action( 'save_post_movie', function ( $post_id ) {
	if ( ! isset( $_POST['khi_tv_show_link_nonce'] ) || ! wp_verify_nonce( $_POST['khi_tv_show_link_nonce'], 'khi_save_tv_show_link' ) ) {
		return;
	}
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return;
	}
	if ( ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}

	$tv_show_id = isset( $_POST['khi_tv_show_id'] ) ? absint( $_POST['khi_tv_show_id'] ) : 0;
	if ( $tv_show_id ) {
		update_post_meta( $post_id, '_khi_tv_show_id', $tv_show_id );
	} else {
		delete_post_meta( $post_id, '_khi_tv_show_id' );
	}
} );

/**
 * Resolves the watch page's show_id from whichever post type is actually
 * being viewed - the movie hub page (linked to its tv_show via
 * '_khi_tv_show_id') or the tv_show post itself (already the show). Returns
 * 0 for a 'movie' post with no linked tv_show - the shared template still
 * renders for it (see the template_include filter below), just from the
 * movie's own video fields instead of an 'episode' CPT/season structure
 * (see the standalone-movie branch in templates/movie-watch-page.php).
 */
function khi_show_id_for_queried_object() {
	$queried = get_queried_object();
	if ( ! $queried ) {
		return 0;
	}
	if ( 'tv_show' === $queried->post_type ) {
		return $queried->ID;
	}
	if ( 'movie' === $queried->post_type ) {
		return khi_show_id_for_movie( $queried->ID );
	}
	return 0;
}

/**
 * Forces the shared watch-page template for every 'movie' and 'tv_show'
 * post sitewide, replacing MasVideos' own single templates for both CPTs.
 * Runs at priority 99 so it wins over MasVideos' own single_template
 * resolution.
 */
add_filter( 'template_include', function ( $template ) {
	if ( is_singular( 'movie' ) || is_singular( 'tv_show' ) ) {
		$override = get_stylesheet_directory() . '/templates/movie-watch-page.php';
		if ( file_exists( $override ) ) {
			return $override;
		}
	}
	return $template;
}, 99 );

function khi_embed_url_from_episode( $episode_id ) {
	$choice = get_post_meta( $episode_id, '_episode_choice', true );
	$url    = get_post_meta( $episode_id, '_episode_url_link', true );

	if ( ( 'episode_url' === $choice || '' === $choice ) && $url ) {
		if ( preg_match( '#vimeo\.com/(?:video/)?(\d+)#', $url, $m ) ) {
			return 'https://player.vimeo.com/video/' . $m[1] . '?title=0&byline=0&portrait=0';
		}
		if ( preg_match( '#youtu\.?be(?:\.com)?/(?:watch\?v=)?([A-Za-z0-9_-]{6,})#', $url, $m ) ) {
			// enablejsapi=1 lets khmer-insider-watch.js detect playback end
			// and show the "next episode" popup (see bindPlayerEnded()).
			return 'https://www.youtube.com/embed/' . $m[1] . '?enablejsapi=1&rel=0&origin=' . rawurlencode( home_url() );
		}
	}

	return '';
}

/**
 * Vimeo/YouTube URL -> embeddable player URL, matched from whichever raw URL
 * meta field the given source ($choice/$url, already read by the caller)
 * holds. Shared by khi_embed_url_from_episode() ('episode' CPT meta) and
 * khi_render_video_block()'s standalone-movie branch ('movie' CPT meta,
 * '_movie_choice'/'_movie_url_link') so both post types embed the same way.
 */
function khi_embed_url_from_link( $url ) {
	if ( ! $url ) {
		return '';
	}
	if ( preg_match( '#vimeo\.com/(?:video/)?(\d+)#', $url, $m ) ) {
		return 'https://player.vimeo.com/video/' . $m[1] . '?title=0&byline=0&portrait=0';
	}
	if ( preg_match( '#youtu\.?be(?:\.com)?/(?:watch\?v=)?([A-Za-z0-9_-]{6,})#', $url, $m ) ) {
		return 'https://www.youtube.com/embed/' . $m[1] . '?enablejsapi=1&rel=0&origin=' . rawurlencode( home_url() );
	}
	return '';
}

/**
 * Embed URL for whichever post is currently playing - an 'episode' (show
 * flow) or a standalone 'movie' with no linked tv_show, which supplies its
 * own video via MasVideos' '_movie_choice'/'_movie_url_link' meta instead.
 */
function khi_embed_url_from_post( $post ) {
	if ( ! $post ) {
		return '';
	}
	if ( 'movie' === $post->post_type ) {
		$choice = get_post_meta( $post->ID, '_movie_choice', true );
		$url    = get_post_meta( $post->ID, '_movie_url_link', true );
		return ( 'movie_url' === $choice || '' === $choice ) ? khi_embed_url_from_link( $url ) : '';
	}
	return khi_embed_url_from_episode( $post->ID );
}

/**
 * Which JS SDK khmer-insider-watch.js should use to detect the "video
 * ended" event for the "next episode" popup - Vimeo Player SDK or the
 * YouTube IFrame API, matched from the embed URL built above.
 */
function khi_embed_provider_from_url( $embed_url ) {
	if ( false !== strpos( $embed_url, 'player.vimeo.com' ) ) {
		return 'vimeo';
	}
	if ( false !== strpos( $embed_url, 'youtube.com/embed' ) ) {
		return 'youtube';
	}
	return '';
}

/**
 * Episode/show synopsis text lives in post_excerpt on this site (post_content
 * is often used for ad shortcodes instead), so prefer excerpt and fall back
 * to stripped content.
 */
function khi_synopsis_text( $post_id ) {
	$text = trim( wp_strip_all_tags( get_post_field( 'post_excerpt', $post_id ) ) );
	if ( '' === $text ) {
		$text = trim( wp_strip_all_tags( get_post_field( 'post_content', $post_id ) ) );
	}
	return $text;
}

/**
 * "About" box schedule line ("{year} | {run time} | {censor rating}") for
 * the currently-viewed movie post. Reuses MasVideos' own already-populated
 * 'movie' CPT meta - '_movie_release_date', '_movie_run_time',
 * '_movie_censor_rating' - the same fields the vodi/vodi-BK parent themes'
 * single-movie template tags render (see
 * inc/masvideos/template-tags/single-movie.php ->
 * masvideos_template_single_movie_release_year(),
 * vodi_template_single_movie_run_time(),
 * vodi_template_single_movie_censor_rating()). On this site editors already
 * repurpose run-time/censor-rating as free-text airing-schedule/production-
 * credit lines rather than a strict duration/rating, so both are echoed
 * as-is with no numeric formatting.
 */
function khi_show_schedule_text( $post_id ) {
	$parts = array();

	$release_date = get_post_meta( $post_id, '_movie_release_date', true );
	if ( $release_date ) {
		$parts[] = date_i18n( 'Y', strtotime( $release_date ) );
	}

	$run_time = get_post_meta( $post_id, '_movie_run_time', true );
	if ( $run_time ) {
		$parts[] = $run_time;
	}

	$censor_rating = get_post_meta( $post_id, '_movie_censor_rating', true );
	if ( $censor_rating ) {
		$parts[] = $censor_rating;
	}

	return implode( ' | ', $parts );
}

function khi_season_numerals() {
	return array( '១', '២', '៣', '៤', '៥', '៦', '៧', '៨', '៩', '១០' );
}

/**
 * Resolves the seasons list, current episode/season, and episodes-in-season
 * for a show. Seasons are ordered by their most recently posted episode (not
 * season number), and episodes by post date (not the _episode_number meta) -
 * so the most recently uploaded content always surfaces first.
 */
function khi_resolve_watch_state( $show_id, $requested_ep = 0, $requested_season = null ) {
	$state = array(
		'seasons'            => array(),
		'current_episode'    => null,
		'current_season'     => 0,
		'episodes_in_season' => array(),
	);

	if ( ! $show_id ) {
		return $state;
	}

	global $wpdb;
	// `show` is a reserved MySQL word, so the join alias must be backtick-quoted.
	$season_rows = $wpdb->get_results( $wpdb->prepare(
		"SELECT season.meta_value AS season_id, MAX(p.post_date) AS last_post_date
		 FROM {$wpdb->postmeta} season
		 INNER JOIN {$wpdb->postmeta} `show` ON `show`.post_id = season.post_id
		 INNER JOIN {$wpdb->posts} p ON p.ID = season.post_id
		 WHERE season.meta_key = '_tv_show_season_id'
		 AND `show`.meta_key = '_tv_show_id' AND `show`.meta_value = %d
		 AND p.post_status = 'publish'
		 GROUP BY season.meta_value
		 ORDER BY last_post_date DESC",
		$show_id
	) );
	$state['seasons'] = array_map( function ( $row ) {
		return (int) $row->season_id;
	}, $season_rows );

	$current_episode = null;
	if ( $requested_ep ) {
		$maybe_episode = get_post( $requested_ep );
		if ( $maybe_episode && 'episode' === $maybe_episode->post_type && 'publish' === $maybe_episode->post_status
			&& (int) get_post_meta( $maybe_episode->ID, '_tv_show_id', true ) === $show_id ) {
			$current_episode = $maybe_episode;
		}
	}

	if ( ! $current_episode ) {
		$latest = get_posts( array(
			'post_type'      => 'episode',
			'post_status'    => 'publish',
			'posts_per_page' => 1,
			'orderby'        => 'date',
			'order'          => 'DESC',
			'meta_query'     => array(
				array(
					'key'   => '_tv_show_id',
					'value' => $show_id,
				),
			),
		) );
		$current_episode = ! empty( $latest ) ? $latest[0] : null;
	}

	$current_season = null !== $requested_season ? $requested_season
		: ( $current_episode ? (int) get_post_meta( $current_episode->ID, '_tv_show_season_id', true ) : 0 );

	$episodes_in_season = get_posts( array(
		'post_type'      => 'episode',
		'post_status'    => 'publish',
		'posts_per_page' => 100,
		'orderby'        => 'date',
		'order'          => 'DESC',
		'meta_query'     => array(
			'relation' => 'AND',
			array(
				'key'   => '_tv_show_id',
				'value' => $show_id,
			),
			array(
				'key'   => '_tv_show_season_id',
				'value' => $current_season,
			),
		),
	) );

	$state['current_episode']    = $current_episode;
	$state['current_season']     = $current_season;
	$state['episodes_in_season'] = $episodes_in_season;

	return $state;
}

/**
 * Cached per-request "what's currently playing" context for the shared
 * watch page - used both by the template (movie-watch-page.php) and by
 * the SEO hooks below, so every ?season=&ep= URL can get episode-specific
 * <title>/description/canonical/OG tags and VideoObject schema instead of
 * the show's generic ones repeated identically on every episode.
 */
function khi_current_watch_context() {
	static $context = null;
	if ( null !== $context ) {
		return $context;
	}

	$context = array(
		'show_id'         => 0,
		'show'            => null,
		'current_episode' => null,
		'current_season'  => 0,
		'ep_requested'    => false,
	);

	if ( ! ( is_singular( 'movie' ) || is_singular( 'tv_show' ) ) ) {
		return $context;
	}

	$show_id = khi_show_id_for_queried_object();
	if ( ! $show_id ) {
		return $context;
	}

	$requested_ep     = isset( $_GET['ep'] ) ? absint( $_GET['ep'] ) : 0;
	$requested_season = isset( $_GET['season'] ) ? absint( $_GET['season'] ) : null;
	$state            = khi_resolve_watch_state( $show_id, $requested_ep, $requested_season );

	$context['show_id']         = $show_id;
	$context['show']            = get_post( $show_id );
	$context['current_episode'] = $state['current_episode'];
	$context['current_season']  = $state['current_season'];
	// Only true when the URL explicitly asked for this episode - the bare
	// show URL (default/latest episode) stays self-canonical instead of
	// pointing away to a query-string URL nobody requested.
	$context['ep_requested']    = $requested_ep && $state['current_episode'] && $requested_ep === $state['current_episode']->ID;

	return $context;
}

function khi_episode_seo_title( $ctx ) {
	$ep_title   = get_the_title( $ctx['current_episode'] );
	$show_title = $ctx['show'] ? $ctx['show']->post_title : '';
	return $show_title ? ( $ep_title . ' - ' . $show_title ) : $ep_title;
}

function khi_episode_seo_description( $ctx ) {
	$text = khi_synopsis_text( $ctx['current_episode']->ID );
	if ( '' === $text && $ctx['show'] ) {
		$text = khi_synopsis_text( $ctx['show']->ID );
	}
	return wp_trim_words( $text, 30, '…' );
}

/**
 * The episode's own indexable URL - the show's permalink plus the
 * season/ep query args that select it.
 */
function khi_episode_canonical_url( $ctx ) {
	$base = get_permalink( get_queried_object_id() );
	return add_query_arg( array(
		'season' => $ctx['current_season'],
		'ep'     => $ctx['current_episode']->ID,
	), $base );
}

/**
 * Best-effort "8:36 នាទី" / "1:08:36" style duration text -> ISO 8601
 * (schema.org VideoObject wants e.g. PT8M36S). Returns '' if unparseable.
 */
function khi_iso8601_duration_from_text( $text ) {
	if ( ! preg_match( '/(\d+):(\d{2})(?::(\d{2}))?/', (string) $text, $m ) ) {
		return '';
	}
	if ( isset( $m[3] ) && '' !== $m[3] ) {
		$hours   = (int) $m[1];
		$minutes = (int) $m[2];
		$seconds = (int) $m[3];
	} else {
		$hours   = 0;
		$minutes = (int) $m[1];
		$seconds = (int) $m[2];
	}
	$duration = 'PT';
	if ( $hours ) {
		$duration .= $hours . 'H';
	}
	if ( $minutes ) {
		$duration .= $minutes . 'M';
	}
	return $duration . $seconds . 'S';
}

/**
 * Per-episode SEO via Yoast's filters (confirmed active - see the
 * yoast-schema-graph JSON-LD block already on these pages), plus a
 * VideoObject schema block so individual episodes are eligible for
 * Google's video rich results, not just the show page as a whole.
 */
add_filter( 'wpseo_title', function ( $title ) {
	$ctx = khi_current_watch_context();
	return $ctx['current_episode'] ? khi_episode_seo_title( $ctx ) : $title;
} );

add_filter( 'wpseo_metadesc', function ( $desc ) {
	$ctx = khi_current_watch_context();
	return $ctx['current_episode'] ? khi_episode_seo_description( $ctx ) : $desc;
} );

add_filter( 'wpseo_opengraph_title', function ( $title ) {
	$ctx = khi_current_watch_context();
	return $ctx['current_episode'] ? khi_episode_seo_title( $ctx ) : $title;
} );

add_filter( 'wpseo_opengraph_desc', function ( $desc ) {
	$ctx = khi_current_watch_context();
	return $ctx['current_episode'] ? khi_episode_seo_description( $ctx ) : $desc;
} );

add_filter( 'wpseo_opengraph_image', function ( $image ) {
	$ctx = khi_current_watch_context();
	if ( ! $ctx['current_episode'] ) {
		return $image;
	}
	$thumb = get_the_post_thumbnail_url( $ctx['current_episode'], 'large' );
	return $thumb ? $thumb : $image;
} );

// Canonical/OG-url only move off the show's base URL once ?ep= is
// explicitly in the request - see the 'ep_requested' comment above.
add_filter( 'wpseo_canonical', function ( $canonical ) {
	$ctx = khi_current_watch_context();
	if ( ! $ctx['current_episode'] || ! $ctx['ep_requested'] ) {
		return $canonical;
	}
	return khi_episode_canonical_url( $ctx );
} );

add_filter( 'wpseo_opengraph_url', function ( $url ) {
	$ctx = khi_current_watch_context();
	if ( ! $ctx['current_episode'] || ! $ctx['ep_requested'] ) {
		return $url;
	}
	return khi_episode_canonical_url( $ctx );
} );

add_action( 'wp_head', function () {
	$ctx = khi_current_watch_context();
	if ( ! $ctx['current_episode'] ) {
		return;
	}
	$episode = $ctx['current_episode'];

	$thumbnail = get_the_post_thumbnail_url( $episode, 'large' );
	if ( ! $thumbnail && $ctx['show'] ) {
		$thumbnail = get_the_post_thumbnail_url( $ctx['show'], 'large' );
	}

	$schema = array(
		'@context'     => 'https://schema.org',
		'@type'        => 'VideoObject',
		'name'         => get_the_title( $episode ),
		'description'  => khi_episode_seo_description( $ctx ),
		'uploadDate'   => mysql2date( 'c', $episode->post_date ),
		'thumbnailUrl' => $thumbnail ? array( $thumbnail ) : null,
		'embedUrl'     => khi_embed_url_from_episode( $episode->ID ),
	);

	$duration = khi_iso8601_duration_from_text( get_post_meta( $episode->ID, '_episode_run_time', true ) );
	if ( $duration ) {
		$schema['duration'] = $duration;
	}

	if ( $ctx['show'] ) {
		$schema['partOfSeries'] = array(
			'@type' => 'TVSeries',
			'name'  => $ctx['show']->post_title,
		);
	}

	$schema = array_filter( $schema, function ( $value ) {
		return null !== $value && '' !== $value;
	} );

	echo '<script type="application/ld+json">' . wp_json_encode( $schema ) . '</script>' . "\n";
}, 20 );

/**
 * Renders the player + title/meta for whichever post is currently playing -
 * an 'episode' (show flow, via '_episode_choice' meta) or a standalone
 * 'movie' with no linked tv_show (via MasVideos' own '_movie_choice' meta).
 */
function khi_render_video_block( $current_episode ) {
	$is_movie = $current_episode && 'movie' === $current_episode->post_type;
	ob_start();
	?>
	<div class="video-wrapper">
		<div class="video-player">
			<?php if ( $current_episode ) :
				$embed_url = khi_embed_url_from_post( $current_episode );
				?>
				<?php if ( $embed_url ) : ?>
					<iframe
						id="khiPlayerFrame"
						data-provider="<?php echo esc_attr( khi_embed_provider_from_url( $embed_url ) ); ?>"
						src="<?php echo esc_url( $embed_url ); ?>"
						title="<?php echo esc_attr( get_the_title( $current_episode ) ); ?>"
						frameborder="0"
						allow="autoplay; fullscreen; picture-in-picture; clipboard-write; encrypted-media; web-share"
						allowfullscreen
					></iframe>
				<?php elseif ( $is_movie && function_exists( 'masvideos_get_the_movie' ) ) : ?>
					<?php echo masvideos_get_the_movie( $current_episode->ID ); ?>
				<?php elseif ( ! $is_movie && function_exists( 'masvideos_get_the_episode' ) ) : ?>
					<?php echo masvideos_get_the_episode( $current_episode->ID ); ?>
				<?php endif; ?>
			<?php endif; ?>
		</div>
	</div>

	<div class="video-meta">
		<h1 class="video-title"><?php echo $current_episode ? esc_html( get_the_title( $current_episode ) ) : esc_html__( 'No episode available yet', 'vodi-child' ); ?></h1>
		<?php if ( $current_episode ) :
			$duration = get_post_meta( $current_episode->ID, $is_movie ? '_movie_run_time' : '_episode_run_time', true );
			?>
			<p class="video-sub">
				<?php if ( $duration ) : ?><?php echo esc_html( $duration ); ?>&nbsp;|&nbsp;<?php endif; ?>
				Added: <?php echo esc_html( mysql2date( 'd.m.Y', $current_episode->post_date ) ); ?>
			</p>
		<?php endif; ?>
	</div>
	<?php
	return ob_get_clean();
}

/**
 * Empty video-block shell for the show-based branch of
 * templates/movie-watch-page.php, rendered instead of
 * khi_render_video_block( null ) while the real episode is still being
 * fetched via AJAX (see khi_rest_get_episode() / loadState() in
 * khmer-insider-watch.js). khi_render_video_block( null )'s "No episode
 * available yet" text is reserved for a show that genuinely has none -
 * this shell must not show that message, since it'd flash before the AJAX
 * response replaces it. The spinner itself is pure CSS, keyed off the
 * #khiVideoBlock.is-loading class already toggled by loadState() (see
 * khmer-insider-watch-template.css).
 */
function khi_render_video_block_loading() {
	ob_start();
	?>
	<div class="video-wrapper">
		<div class="video-player"></div>
	</div>
	<div class="video-meta">
		<h1 class="video-title">&nbsp;</h1>
	</div>
	<?php
	return ob_get_clean();
}

function khi_render_description( $current_episode ) {
	ob_start();
	?>
	<h2 class="box-title">Description</h2>
	<p class="description-text">
		<?php echo $current_episode ? esc_html( khi_synopsis_text( $current_episode->ID ) ) : ''; ?>
	</p>
	<?php
	return ob_get_clean();
}

function khi_render_season_dropdown( $seasons, $current_season, $base_url = false ) {
	$season_numerals = khi_season_numerals();
	ob_start();
	foreach ( $seasons as $season_value ) :
		$is_active  = $season_value === $current_season;
		$season_url = add_query_arg( array( 'season' => $season_value ), remove_query_arg( 'ep', $base_url ) );
		?>
		<li class="<?php echo $is_active ? 'active' : ''; ?>">
			<a href="<?php echo esc_url( $season_url ); ?>" data-season="<?php echo esc_attr( $season_value ); ?>">
				រដូវកាលទី​ <?php echo esc_html( isset( $season_numerals[ $season_value ] ) ? $season_numerals[ $season_value ] : ( $season_value + 1 ) ); ?>
			</a>
		</li>
		<?php
	endforeach;
	return ob_get_clean();
}

function khi_render_episode_list( $episodes_in_season, $current_episode, $current_season, $default_asset_uri, $base_url = false ) {
	ob_start();
	foreach ( $episodes_in_season as $ep ) :
		$is_active   = $current_episode && $ep->ID === $current_episode->ID;
		$ep_url      = add_query_arg( array(
			'season' => $current_season,
			'ep'     => $ep->ID,
		), $base_url );
		$ep_duration = get_post_meta( $ep->ID, '_episode_run_time', true );
		?>
		<li class="episode-item<?php echo $is_active ? ' active' : ''; ?>">
			<a href="<?php echo esc_url( $ep_url ); ?>" data-ep="<?php echo esc_attr( $ep->ID ); ?>" data-season="<?php echo esc_attr( $current_season ); ?>" style="display:flex;gap:10px;align-items:center;width:100%;">
				<?php $ep_thumb = get_the_post_thumbnail_url( $ep, 'medium' ); ?>
				<img class="episode-thumb" src="<?php echo esc_url( $ep_thumb ? $ep_thumb : $default_asset_uri . '/episode-thumb.svg' ); ?>" alt="<?php echo esc_attr( get_the_title( $ep ) ); ?>" />
				<div class="episode-info">
					<p class="episode-title"><?php echo esc_html( get_the_title( $ep ) ); ?></p>
					<p class="episode-meta">
						<?php if ( $ep_duration ) : ?><?php echo esc_html( $ep_duration ); ?> | <?php endif; ?>
						Added: <?php echo esc_html( mysql2date( 'd.m.Y', $ep->post_date ) ); ?>
					</p>
				</div>
			</a>
		</li>
		<?php
	endforeach;
	return ob_get_clean();
}

function khi_season_label( $current_season ) {
	$season_numerals = khi_season_numerals();
	return 'រដូវកាលទី​ ' . ( isset( $season_numerals[ $current_season ] ) ? $season_numerals[ $current_season ] : ( $current_season + 1 ) );
}

function khi_enqueue_watch_assets() {
	$show_id = ( is_singular( 'movie' ) || is_singular( 'tv_show' ) ) ? khi_show_id_for_queried_object() : 0;
	if ( ! $show_id ) {
		return;
	}

	$js_path = get_stylesheet_directory() . '/js/khmer-insider-watch.js';

	// Loaded as dependencies so they've at least been requested/executed
	// before khmer-insider-watch.js runs its "next episode" popup logic
	// (see bindPlayerEnded() there).
	wp_enqueue_script( 'vimeo-player-sdk', 'https://player.vimeo.com/api/player.js', array(), null, true );
	wp_enqueue_script( 'youtube-iframe-api', 'https://www.youtube.com/iframe_api', array(), null, true );

	wp_enqueue_script(
		'khmer-insider-watch',
		get_stylesheet_directory_uri() . '/js/khmer-insider-watch.js',
		array( 'vimeo-player-sdk', 'youtube-iframe-api' ),
		file_exists( $js_path ) ? filemtime( $js_path ) : '1.0',
		true
	);
	wp_localize_script( 'khmer-insider-watch', 'khiWatch', array(
		'restUrl' => rest_url( 'wp/v2/khmer-insider-episode' ),
		'showId'  => $show_id,
	) );
}
add_action( 'wp_enqueue_scripts', 'khi_enqueue_watch_assets' );

/**
 * Public, read-only endpoint - same pattern as the other wp/v2 routes in this
 * theme, deliberately not nonce-gated (see unlock-the-life-watch.php).
 */
add_action( 'rest_api_init', function () {
	register_rest_route( 'wp/v2', 'khmer-insider-episode', array(
		'methods'             => 'GET',
		'callback'            => 'khi_rest_get_episode',
		'permission_callback' => '__return_true',
	) );
} );

function khi_rest_get_episode( $request ) {
	$show_id = absint( $request->get_param( 'show_id' ) );
	if ( ! $show_id ) {
		return new WP_Error( 'khi_no_show', 'Show not found.', array( 'status' => 404 ) );
	}

	$requested_ep     = absint( $request->get_param( 'ep' ) );
	$requested_season = null !== $request->get_param( 'season' ) ? absint( $request->get_param( 'season' ) ) : null;

	$base_url    = false;
	$client_path = $request->get_param( 'page_url' );
	$parsed_path = $client_path ? wp_parse_url( $client_path, PHP_URL_PATH ) : '';
	if ( $parsed_path ) {
		$base_url = $parsed_path;
	}

	$state = khi_resolve_watch_state( $show_id, $requested_ep, $requested_season );

	$default_asset_uri = get_stylesheet_directory_uri() . '/assets/unlock-the-life';

	return array(
		'video_html'           => khi_render_video_block( $state['current_episode'] ),
		'description_html'     => khi_render_description( $state['current_episode'] ),
		'episode_list_html'    => khi_render_episode_list( $state['episodes_in_season'], $state['current_episode'], $state['current_season'], $default_asset_uri, $base_url ),
		'season_dropdown_html' => khi_render_season_dropdown( $state['seasons'], $state['current_season'], $base_url ),
		'season_label'         => khi_season_label( $state['current_season'] ),
		'title'                => ( $state['current_episode'] ? get_the_title( $state['current_episode'] ) : esc_html__( 'No episode available yet', 'vodi-child' ) ) . ' - ' . get_bloginfo( 'name' ),
		'query'                => array(
			'season' => $state['current_season'],
			'ep'     => $state['current_episode'] ? $state['current_episode']->ID : 0,
		),
	);
}
