<?php

 function generate_user_token($user_id) {
    // Generate a unique token for the user
    $token = wp_generate_password(256, false);

    // Calculate the token expiration timestamp (1 month from now)
    $expiration = strtotime('+1 month');

    // Store the token and expiration timestamp in user meta
    update_user_meta($user_id, 'user_token', $token);
    update_user_meta($user_id, 'user_token_expiration', $expiration);

    return $token;
}

function login_endpoint(WP_REST_Request $request) {
    $username = $request->get_param('username');
    $password = $request->get_param('password');

    // Example login logic using WordPress functions
    $user = wp_authenticate($username, $password);

    if (is_wp_error($user)) {
        return new WP_REST_Response(['status'=>'ERROR','message'=>'Invalid credentials'],401);
    }

    // Generate a token for the user
    $token = generate_user_token($user->ID);

    // Get the email and profile picture of the user
    $display_name = $user->display_name;
    $email = $user->user_email;
    $profile_picture = get_avatar_url($user->ID);

    // Return the token in the response
    $response = array(
        'id' => $user->ID,
        'display_name' => $display_name,
        'email' => $email,
        'profile_picture' => $profile_picture,
        'token' => $token,
    );

    return new WP_REST_Response(['status'=>'OK','message'=>'Login success','data'=>$response], 200);
}


function get_user_info(WP_REST_Request $request) {
    
    $token = get_bearer_token($request);

    if (!$token) {
        return new WP_REST_Response(['status' => 'ERROR', 'message' => 'Invalid token'], 401);
    }

    $user_id = get_user_id_from_token($token);

    if (!$user_id) {
        return new WP_REST_Response(['status' => 'ERROR', 'message' => 'Invalid token'], 401);
    }

    // Get the user object
    $user = get_user_by('ID', $user_id);
    
    $display_name = $user->display_name;
    $email = $user->user_email;
    $profile_picture = get_avatar_url($user->ID);

    // Return the token in the response
    $response = array(
        'id' => $user->ID,
        'display_name' => $display_name,
        'email' => $email,
        'profile_picture' => $profile_picture,
    );

    return new WP_REST_Response(['status'=>'OK','message'=>'Login success','data'=>$response], 200);

}




function update_user_information_endpoint(WP_REST_Request $request) {
    $token = get_bearer_token($request);

    if (!$token) {
        return new WP_REST_Response(['status' => 'ERROR', 'message' => 'Invalid token'], 401);
    }

    $user_id = get_user_id_from_token($token);

    if (!$user_id) {
        return new WP_REST_Response(['status' => 'ERROR', 'message' => 'Invalid token'], 401);
    }

    // Get the user object
    $user = get_user_by('ID', $user_id);

    // Update the user information
    $user_fields = $request->get_params();

    if (isset($user_fields['first_name'])) {
        $first_name = sanitize_text_field($user_fields['first_name']);
        if (!empty($first_name)) {
            update_user_meta($user_id, 'first_name', $first_name);
        }
    }

    if (isset($user_fields['last_name'])) {
        $last_name = sanitize_text_field($user_fields['last_name']);
        if (!empty($last_name)) {
            update_user_meta($user_id, 'last_name', $last_name);
        }
    }

    if (isset($user_fields['gender'])) {
        $gender = sanitize_text_field($user_fields['gender']);
        update_user_meta($user_id, 'gender', $gender);
    }
    
    if (isset($user_fields['dob'])) {
        $dob = sanitize_text_field($user_fields['dob']);
        update_user_meta($user_id, 'dob', $dob);
    }

    if (isset($user_fields['description'])) {
        $description = sanitize_textarea_field($user_fields['description']);
        update_user_meta($user_id, 'description', $description);
    }

    if (isset($user_fields['phone_number'])) {
        $phone_number = sanitize_text_field($user_fields['phone_number']);
        
        $stored_phone = get_user_meta($user_id, 'phone_number', true );
        
        if($stored_phone == $phone_number){
            update_user_meta($user_id, 'phone_number', $phone_number);
        }else{
            $existing_users = get_users(array(
                'meta_query' => array(
                    array(
                        'key' => 'phone_number',
                        'value' => $phone_number,
                    )
                )
            ));
            if($existing_users){
                return new WP_REST_Response(['status' => 'ERROR', 'message' => 'Phone number already existed'], 400);
            }else{

                $phone_number = str_replace(' ', '', $phone_number);
                // Check if the phone number contains only digits and has at least 9 digits
                if (!empty($phone_number) && ctype_digit($phone_number) && strlen($phone_number) >= 9) {
                    update_user_meta($user_id, 'phone_number', $phone_number);
                } else {
                    return new WP_REST_Response(['status' => 'ERROR', 'message' => 'Invalid phone number. Please enter a valid phone number with at least 9 digits.'], 400);
                }
            }
            
            
            
            
        }

        

    }
    
        // Email verification with OTP
    if (isset($user_fields['email'])) {
        $new_email = sanitize_email($user_fields['email']);
        $stored_email = $user->user_email;

        if ($new_email !== $stored_email) {
            // Check if the new email is already registered
            $existing_user = get_user_by('email', $new_email);
            if ($existing_user) {
                return new WP_REST_Response(['status' => 'ERROR', 'message' => 'Email address is already registered'], 400);
            }
                
            // Generate OTP
            $otp = generate_otp();
            $expiration = strtotime('+1 minute'); // OTP expiration time (e.g., 5 minutes)

            // Store OTP and expiration in user meta
            update_user_meta($user_id, 'email_otp', $otp);
            update_user_meta($user_id, 'email_otp_expiration', $expiration);

			// Send the OTP to the user's email
            $body = "
                <html>
                    <body>
                        <p>Your OTP for email verification:</p> <h3>$otp<h3>
                    </body>
                </html>";
            $to = $stored_email;
            $subject = 'Infotainment - Change email';
            $headers = array('Content-Type: text/html; charset=UTF-8');
            // Send the email
            $email_sent = wp_mail($to, $subject, $body, $headers);
        
            if (!$email_sent) {
                return new WP_REST_Response(['status' => 'ERROR', 'message' => 'Failed to send OTP email'], 500);
            }

            return new WP_REST_Response(['status' => 'SendOTP', 'message' => 'Check your email to verif OTP code.']);
        }
    }
    

    if (isset($_FILES['profile_picture']) && !empty($_FILES['profile_picture']['name'])) {
        $profile_picture_file = $_FILES['profile_picture'];
        $profile_picture = upload_profile_picture($profile_picture_file);
        if ($profile_picture) {
            $existing_profile_picture = get_user_meta($user_id, 'profile_picture', true);
            // Compare the new profile picture URL with the existing one
            if ($existing_profile_picture !== $profile_picture) {
                // Delete the existing profile picture if it's different
                if (!empty($existing_profile_picture)) {
                    // Get the path of the existing profile picture file
                    $existing_profile_picture_path = str_replace(wp_get_upload_dir()['baseurl'], wp_get_upload_dir()['basedir'], $existing_profile_picture);
                    // Delete the file from the uploads directory
                    if (file_exists($existing_profile_picture_path)) {
                        unlink($existing_profile_picture_path);
                    }
                }
                update_user_meta($user_id, 'profile_picture', $profile_picture);
            }
        } else {
            return new WP_REST_Response(['status' => 'ERROR', 'message' => 'Failed to upload profile picture'], 400);
        }
    }

    // Return the updated user information
    $response = array(
        'id' => $user->ID,
        'fname' => $user->first_name,
        'lname' => $user->last_name, 
        'gender' => get_user_meta($user_id, 'gender', true),
        'dob' => get_user_meta($user_id, 'dob', true),
        'display_name' => $user->display_name,
        'email' => $user->user_email,
        'description' => get_user_meta($user_id, 'description', true),
        'phone_number' => $user->phone_number,
        'profile_picture' => get_user_meta($user_id, 'profile_picture', true),
    );

    return new WP_REST_Response(['status' => 'OK', 'message' => 'User information updated', 'data' => $response], 200);
}


if (!function_exists('get_bearer_token')) {
    function get_bearer_token($request) {
        $authorization_header = $request->get_header('Authorization');

        if ($authorization_header && preg_match('/Bearer\s+(.*)/', $authorization_header, $matches)) {
            return $matches[1];
        }

        return null;
    }
}

function generate_otp() {
    // Generate a random OTP here (e.g., using random number generation algorithms)
    $otp = mt_rand(100000, 999999);
    return $otp;
}

function get_user_id_from_token($token) {
    $user_query = new WP_User_Query(array(
        'meta_key' => 'user_token',
        'meta_value' => $token,
    ));

    $users = $user_query->get_results();
    if (empty($users)) {
        return false;
    }

    $user = $users[0];
    $expiration = get_user_meta($user->ID, 'user_token_expiration', true);

    if ($expiration && time() > $expiration) {
        // Token has expired, remove it from user meta
        delete_user_meta($user->ID, 'user_token');
        delete_user_meta($user->ID, 'user_token_expiration');
        return false;
    }

    return $user->ID;
}

function upload_profile_picture($file) {
    $allowed_types = ['image/jpeg', 'image/png'];
    $max_size = 5 * 1024 * 1024; // 5MB

    if (!in_array($file['type'], $allowed_types)) {
        return false;
    }

    if ($file['size'] > $max_size) {
        return false;
    }

    $upload_dir = wp_upload_dir();
    $target_dir = $upload_dir['path'] . '/';
    $file_name = uniqid() . '_' . $file['name'];
    $target_file = $target_dir . $file_name;

    if (move_uploaded_file($file['tmp_name'], $target_file)) {
        return $upload_dir['url'] . '/' . $file_name;
    } else {
        return false;
    }
}

function otp_email(WP_REST_Request $request){
    $token = get_bearer_token($request);

    if (!$token) {
        return new WP_REST_Response(['status' => 'ERROR', 'message' => 'Invalid token'], 401);
    }

    $user_id = get_user_id_from_token($token);

    if (!$user_id) {
        return new WP_REST_Response(['status' => 'ERROR', 'message' => 'Invalid token'], 401);
    }
    
    // Get the user object
    $user = get_user_by('ID', $user_id);

    // Update the user information
    $user_fields = $request->get_params();
    
	// OTP validation and email update
    if (isset($user_fields['otp'])) {
        $input_otp = sanitize_text_field($user_fields['otp']);
        $stored_otp = get_user_meta($user_id, 'email_otp', true);
        $expiration = get_user_meta($user_id, 'email_otp_expiration', true);

        if ($input_otp === $stored_otp && $expiration >= time()) {
            
            $new_email = sanitize_email($user_fields['email']);
            $update = wp_update_user(['ID' => $user_id, 'user_email' => $new_email]);
            // Delete the email OTP meta data
            // delete_user_meta($user_id, 'email_otp');
            // delete_user_meta($user_id, 'email_otp_expiration');
        } else {
            return new WP_REST_Response(['status' => 'ERROR', 'message' => 'Invalid or expired OTP'], 400);
        }
        
        return new WP_REST_Response(['status' => 'OK', 'message' => 'Update email successfully', 'data'=>$update], 200);

        
    }
    
}

function update_user_fav_endpoint(WP_REST_Request $request){
    $token = get_bearer_token($request);

    if (!$token) {
        return new WP_REST_Response(['status' => 'ERROR', 'message' => 'Invalid token'], 401);
    }

    $user_id = get_user_id_from_token($token);

    if (!$user_id) {
        return new WP_REST_Response(['status' => 'ERROR', 'message' => 'Invalid token'], 401);
    }

    // Get the user object
    $user = get_user_by('ID', $user_id);
    
    $user_fields = $request->get_params();
    
    if (isset($user_fields['fav_author'])) {
        $fav_author = $user_fields['fav_author'];
        if (!empty($fav_author) && is_array($fav_author)) {
            $sanitized_authors = array_map('sanitize_text_field', $fav_author);
            update_user_meta($user_id, 'fav_author', $sanitized_authors);
        }
    }

    
    if (isset($user_fields['fav_keyword'])) {
        $fav_keyword = sanitize_text_field($user_fields['fav_keyword']);
        if (!empty($fav_keyword)) {
            update_user_meta($user_id, 'fav_keyword', $fav_keyword);
        }
    }
    
    $response = array(
        'fav_author' => get_user_meta($user_id, 'fav_author', true),
        'fav_keyword' => get_user_meta($user_id, 'fav_keyword', true),
    );
    
    return new WP_REST_Response(['status' => 'OK', 'message' => 'User favourite updated', 'data' => $response], 200);
    
    
}

function get_user_fav_endpoint(WP_REST_Request $request){
    $token = get_bearer_token($request);

    if (!$token) {
        return new WP_REST_Response(['status' => 'ERROR', 'message' => 'Invalid token'], 401);
    }

    $user_id = get_user_id_from_token($token);

    if (!$user_id) {
        return new WP_REST_Response(['status' => 'ERROR', 'message' => 'Invalid token'], 401);
    }
    
    $fav_author_ids = get_user_meta($user_id, 'fav_author', true);
    $fav_authors = [];

    if ($fav_author_ids && is_array($fav_author_ids)) {
        foreach ($fav_author_ids as $author_id) {
            $author_name = get_author_name($author_id); // Function to retrieve author name based on author ID
            $fav_authors[] = [
                'id' => $author_id,
                'author_name' => $author_name
            ];
        }
    }
    
    $response = array( 
        'id' => $user_id,
        'fav_author' => $fav_authors,
        'fav_keyword' => get_user_meta($user_id, 'fav_keyword', true)
    );

    return new WP_REST_Response(['status' => 'OK', 'message' => 'Get User Favourite', 'data' => $response], 200);
    
    
}


add_action('rest_api_init', function () {
    register_rest_route('api/v2', '/login-user', array(
        'methods' => 'POST',
        'callback' => 'login_endpoint',
        'permission_callback' => '__return_true',
    ));

    register_rest_route('api/v2', '/update-user-information', array(
        'methods' => 'POST',
        'callback' => 'update_user_information_endpoint',
        'permission_callback' => '__return_true',
    ));
    
    register_rest_route('api/v2', '/otp-email', array(
        'methods' => 'POST',
        'callback' => 'otp_email',
        'permission_callback' => '__return_true',
    ));
    
    register_rest_route('api/v2', '/update-user-fav', array(
        'methods' => 'POST',
        'callback' => 'update_user_fav_endpoint',
        'permission_callback' => '__return_true',
    ));
    
    register_rest_route('api/v2', '/get-user-fav', array(
        'methods' => 'GET',
        'callback' => 'get_user_fav_endpoint',
        'permission_callback' => '__return_true',
    ));
    
    register_rest_route('api/v2', '/get-user-info', array(
        'methods' => 'GET',
        'callback' => 'get_user_info',
        'permission_callback' => '__return_true',
    ));
    
   
    
    
    
});





?>