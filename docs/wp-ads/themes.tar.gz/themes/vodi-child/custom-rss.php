<?php
header("Content-Type: application/rss+xml; charset=UTF-8");
echo '<?xml version="1.0" encoding="UTF-8"?>';
?>


<?php
$args = array(
    "id" => 80919,
    'post_type' => 'post',
    'post_status' => 'publish',
    // 'posts_per_page' => 1,
    'category_name' => 'news'
);
$query = new WP_Query($args);
?>


<rss version="2.0"
     xmlns:content="http://purl.org/rss/1.0/modules/content/"
     xmlns:wfw="http://wellformedweb.org/CommentAPI/"
     xmlns:dc="http://purl.org/dc/elements/1.1/"
     xmlns:atom="http://www.w3.org/2005/Atom"
     xmlns:sy="http://purl.org/rss/1.0/modules/syndication/"
     xmlns:slash="http://purl.org/rss/1.0/modules/slash/"
     xmlns:itunes="http://www.itunes.com/dtds/podcast-1.0.dtd"
>
<channel>
    <title>My Custom RSS Feed</title>
    <description>A custom RSS feed for my website</description>
    <link>https://www.example.com</link>
    <language>en-us</language>
    <pubDate><?php echo date('D, d M Y H:i:s O'); ?></pubDate>
    <lastBuildDate><?php echo date('D, d M Y H:i:s O'); ?></lastBuildDate>
    <generator>WordPress</generator>
    <itunes:author>My Podcast Author</itunes:author>
    <itunes:summary>A summary of my podcast.</itunes:summary>
    <itunes:owner>
        <itunes:name>My Podcast Owner</itunes:name>
        <itunes:email>owner@example.com</itunes:email>
    </itunes:owner>
    <itunes:image href="<?php echo get_template_directory_uri() . '/images/podcast-logo.jpg'; ?>" />
    <?php while ($query->have_posts()) : $query->the_post(); ?>
        <item>
            <title><?php the_title_rss(); ?></title>
            <link><?php the_permalink_rss(); ?></link>
            <pubDate><?php echo get_post_time('D, d M Y H:i:s O', true); ?></pubDate>
            <dc:creator><?php the_author(); ?></dc:creator>
            <category><?php the_category_rss(); ?></category>
            <guid isPermaLink="false"><?php the_guid(); ?></guid>
            <description><![CDATA[<?php the_excerpt_rss(); ?>]]></description>
            <content:encoded><![CDATA[<?php the_content_feed('rss2'); ?>]]></content:encoded>
            <?php
            $audio_url = get_field('audio_file');
            if ($audio_url) : ?>
                <enclosure url="<?php echo $audio_url; ?>"
                           length="<?php echo filesize(get_attached_file(get_field('audio_file'))) ?>"
                           type="audio/mpeg" />
            <?php endif; ?>
            <itunes:author>My Podcast Author</itunes:author>
            <itunes:subtitle>A subtitle for my podcast.</itunes:subtitle>
            <itunes:summary>A summary of this episode.</itunes:summary>
            <itunes:duration><?php echo get_field('audio_duration'); ?></itunes:duration>
            <itunes:explicit>No</itunes:explicit>
        </item>
    <?php endwhile;
    wp_reset_postdata(); ?>
</channel>
</rss>

