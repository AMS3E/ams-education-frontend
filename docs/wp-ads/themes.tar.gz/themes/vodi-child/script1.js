function applyRealEstateImageSize() {
  const images = document.querySelectorAll(
    '#content .container .site-content__inner #primary #main ' +
    '.hentry .page__content .wp-block-columns .wp-block-column ' +
    '.section-real_estate .panel-real_estate .real_estate ' +
    '.container-real_estate .real_estate .wp-post-image'
  );

  const width = window.innerWidth;

  images.forEach(img => {
    if (width <= 768) {
      img.style.width = '89%';
      img.style.height = '27vw';
    } else {
      img.style.width = '';
      img.style.height = '';
    }
  });
}

// Run on load and resize
window.addEventListener('load', applyRealEstateImageSize);
window.addEventListener('resize', applyRealEstateImageSize);