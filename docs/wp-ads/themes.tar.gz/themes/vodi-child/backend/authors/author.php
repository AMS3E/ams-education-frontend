<?php

function author_menu(){
    add_menu_page(
        __('Authors', 'my-textdomain'),
        __('AMS Teams', 'my-textdomain'),
        'manage_options',
        'admin-author',
        'author_content',
        'dashicons-businessperson',
        3
    );
}

add_action('admin_menu', 'author_menu');

function author_content(){
    ?>
        <section class="container-head" style="margin-top:25px;">
            <div class="d-flex">
                <h1 style="font-size:26px;">AMS Teams</h1>
                <button type="button" class="btn btn-info btn-sm" id="btn-add-team" style="margin-left:25px;">Add Team</button>    
            </div>
            
            
        </section>
        
        <section class="container-table" style="margin-top:25px;">
            <table id="author_lists" style="font-family:Kantumruy; width:100%;">
                <thead>
                    <tr>
                        <th class="text-center">No</th>
                        <th>Profile</th>
                        <th>Username</th>
                        <th class="text-center">Publish on Website</th>
                        <th class="text-center">Showing Position</th>
                        <th class="text-center">Position Type</th>
                        <th class="text-center">Publish</th>
                        <th class="text-center">Action</th>
                    </tr>
                </thead>
                    
                <tbody>
                </tbody>
            </table>
        </section>
        
        
      <!-- Modal -->
        <div class="modal fade" id="modal_author" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
          <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
            <div class="modal-content">
                
              <div id="loadingSpinner">
                <div class="lds-spinner">
                  <div></div>
                  <div></div>
                  <div></div>
                  <div></div>
                  <div></div>
                  <div></div>
                  <div></div>
                  <div></div>
                  <div></div>
                  <div></div>
                  <div></div>
                  <div></div>
                </div>
              </div>
  
  
              <div class="modal-header">
                <h5 class="modal-title" id="titleModal">Add Team</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>
              <form id="dataForm" method="POST" enctype="multipart/form-data">
                  <div class="modal-body">
                        <div class="row">
                            <div class="col-sm-6">
                                <input type="hidden" name="id" id="id">
                                <label>Name in Khmer <span style="color:red;">*</span></label>
                                <input type="text" id="name_kh" name="name_kh" class="form-control" style="font-family:kantumruy;" require>
                            </div>
                            <div class="col-sm-6">
                                <label>Name in English <span style="color:red;">*</span></label>
                                <input type="text" id="name_en" name="name_en" class="form-control" require>
                            </div>
                        </div>
                        
                        <div class="row mt-3">
                            <div class="col-sm-6">
                                <label>Publish on Websites <span style="color:red;">*</span></label><br>
                                <select class="form-control" style="width:100%;" id="publish_on" name="publish_on" multiple require>
                                    <option value="Economy">ECONOMY</option>
                                    <option value="Education">EDUCATION</option>
                                    <option value="Infotainment">INFOTAINMENT</option>
                                </select>
                            </div>
                            <div class="col-sm-6">
                                <label>Department</label>
                                <input type="text" id="dep_level" name="dep_level" class="form-control" require>
                            </div>
                        </div>
                        
                        <div class="row mt-3">
                            <div class="col-sm-4">
                                <label>Author Economy ID</label>
                                <select class="form-control" style="width:100%;height:38px;" id="author_eco_id" name="author_eco_id" require>
                                </select>
                            </div>
                            <div class="col-sm-4">
                                 <label>Author Education ID</label>
                                <select id="author_edu_id" name="author_edu_id" class="form-control" style="width:100%;" require>
                                </select>
                            </div>
                            <div class="col-sm-4">
                                 <label>Author Infotainment ID</label>
                                <select id="author_info_id" name="author_info_id" class="form-control" style="width:100%;" require>
                                </select>
                            </div>
                        </div>
                        
                        <div class="row mt-3">
                            <div class="col-sm-6">
                                <label>Showing Position <span style="color:red;">*</span></label>
                                <select class="form-control" id="showing_position" name="showing_position" style="width:100%;" multiple required>
                                    <option value="Author">Author</option>
                                    <option value="Producer">Producer</option>
                                    <option value="Production">Production</option>
                                    <option value="Digital Maketing">Digital Marketing</option>
                                    <option value="UI/UX Design">UI/UX Design</option>
                                    <option value="Web Develper">Web Developer</option>
                                    <option value="Top Management">Top Management</option>
                                </select>
                            </div>
                            <div class="col-sm-6">
                                <div class="row">
                                    <div class="col-sm-6">
                                        <label>Position Type</label>
                                        <select class="form-control" id="position_type" name="position_type">
                                            <option value="Carousel">Carousel</option>
                                            <option value="Top Section">Top Section</option>
                                        </select>
                                    </div>
                                    
                                    <div class="col-sm-6">
                                        <label>Publish</label>
                                        <select class="form-control" id="is_publish" name="is_publish">
                                            <option value="1">Active</option>
                                            <option value="0">Deactive</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="row mt-3">
                            <div class="col-sm-12">
                                <label>Description <span style="color:red;">*</span></label>
                                <textarea name="description" id="description" class="form-control"></textarea>
                            </div>
                        </div>
                        
                        <div class="row mt-3">
                            <div class="col-sm-4">
                                <label>Prfile ECO</label>
                                <div class="image-preview" id="imagePreviewEco" ></div>
                                <input type="file" name="profile_eco" id="prfofile_eco" accept="image/jpeg, image/png, image/jpg" class="profile-input" style="width:100%;margin-top:15px;font-size:13px;">
                            </div>
                            <div class="col-sm-4">
                                <label>Prfile EDU</label>
                                <div class="image-preview" id="imagePreviewEdu"></div>
                                <input type="file" name="profile_edu" id="prfofile_edu" accept="image/jpeg, image/png, image/jpg" class="profile-input" style="width:100%;margin-top:15px;font-size:13px;">
                            </div>
                            <div class="col-sm-4">
                                <label>Prfile INFO</label>
                                <div class="image-preview" id="imagePreviewInfo"></div>
                                <input type="file" name="profile_info" id="prfofile_info" accept="image/jpeg, image/png, image/jpg" class="profile-input" style="width:100%;margin-top:15px;font-size:13px;">
                            </div>
                        </div>
                        
                    
                  </div>
                  <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary" id="btnSubmit">Save Author</button>
                  </div>
              </form>
            </div>
          </div>
        </div>

        
    <?php
}


// Register a custom REST API endpoint for media uploads
add_action('rest_api_init', 'register_media_upload_endpoint');

function register_media_upload_endpoint() {
    register_rest_route('api/v2', '/save-author', array(
        'methods' => 'POST',
        'callback' => 'save_ams_author',
        'permission_callback' => '__return_true',
    ));
    
    register_rest_route(
        'api/v2',
        '/list-ams-teams',
        array(
            'methods' => 'GET',
            'callback' => 'get_ams_teams',
        )
    );
    
    
    register_rest_route(
        'api/v2',
        '/ams-teams-info',
        array(
            'methods' => 'GET',
            'callback' => 'get_ams_info',
        )
    );
    
    
    register_rest_route(
        'api/v2',
        '/is-publish-author',
        array(
            'methods' => 'POST',
            'callback' => 'is_publish_author',
        )
    );
    
    register_rest_route(
        'api/v2',
        '/list-user-by-roles',
        array(
            'methods' => 'GET',
            'callback' => 'list_user_by_roles',
        )
    );
    
    register_rest_route(
        'api/v2',
        '/get-author-list',
        array(
            'methods' => 'GET',
            'callback' => 'get_author_list',
        )
    );
    
    register_rest_route(
        'api/v2',
        '/get-team-info',
        array(
            'methods' => 'GET',
            'callback' => 'get_team_detail',
        )
    );
    
    
}

// Handle media upload
function save_ams_author($request) {
    $media = $request->get_file_params();

    // Check file size (in bytes)
    $max_file_size = 10 * 1024 * 1024; // 10MB
    if ($media['profile_eco']['size'] > $max_file_size || $media['profile_edu']['size'] > $max_file_size || $media['profile_info']['size'] > $max_file_size) {
        return new WP_Error('file_size_exceeded', 'File size exceeds the allowed limit', array('status' => 400));
    }

    global $wpdb;
    $table_name = $wpdb->prefix . 'ams_authors';

    $params = $request->get_params();
    
    // Update the field if ID is available
    $id = $request->get_param('id');

    $name_kh = sanitize_text_field($params['name_kh']);
    $name_en = sanitize_text_field($params['name_en']);
    $description = sanitize_text_field($params['description']);
    $dep_level = sanitize_text_field($params['dep_level']);
    $publish_on_val = $request->get_param('publish_on');
    $showing_position_val = $request->get_param('showing_position');
    $position_type = $request->get_param('position_type');
    $author_eco_id = $request->get_param('author_eco_id');
    $author_edu_id = $request->get_param('author_edu_id');
    $author_info_id = $request->get_param('author_info_id');
    $is_publish = sanitize_text_field($params['is_publish']);
    
    $publish_on = implode(',', $publish_on_val);
    $showing_position = implode(',', $showing_position_val);

    // Process and update profile_eco
    if (!empty($media['profile_eco'])) {
        $profile_eco = wp_handle_upload($media['profile_eco'], array('test_form' => false));

        if (!isset($profile_eco['error'])) {
            $attachment = array(
                'post_mime_type' => $profile_eco['type'],
                'post_title' => preg_replace('/\.[^.]+$/', '', basename($profile_eco['file'])),
                'post_content' => '',
                'post_status' => 'inherit',
            );

            $attachment_id = wp_insert_attachment($attachment, $profile_eco['file']);

            if (!is_wp_error($attachment_id)) {
                require_once(ABSPATH . 'wp-admin/includes/image.php');

                // Generate attachment metadata and update the attachment
                $attachment_data = wp_generate_attachment_metadata($attachment_id, $profile_eco['file']);
                wp_update_attachment_metadata($attachment_id, $attachment_data);

                $profile_eco_url = wp_get_attachment_url($attachment_id);

                $wpdb->update(
                    $table_name,
                    array('profile_eco' => $profile_eco_url),
                    array('id' => $id),
                    array('%s'),
                    array('%d')
                );
            }
        }
    }

    // Process and update profile_edu
    if (!empty($media['profile_edu'])) {
        $profile_edu = wp_handle_upload($media['profile_edu'], array('test_form' => false));

        if (!isset($profile_edu['error'])) {
            $attachment = array(
                'post_mime_type' => $profile_edu['type'],
                'post_title' => preg_replace('/\.[^.]+$/', '', basename($profile_edu['file'])),
                'post_content' => '',
                'post_status' => 'inherit',
            );

            $attachment_id = wp_insert_attachment($attachment, $profile_edu['file']);

            if (!is_wp_error($attachment_id)) {
                require_once(ABSPATH . 'wp-admin/includes/image.php');

                // Generate attachment metadata and update the attachment
                $attachment_data = wp_generate_attachment_metadata($attachment_id, $profile_edu['file']);
                wp_update_attachment_metadata($attachment_id, $attachment_data);

                $profile_edu_url = wp_get_attachment_url($attachment_id);

                $wpdb->update(
                    $table_name,
                    array('profile_edu' => $profile_edu_url),
                    array('id' => $id),
                    array('%s'),
                    array('%d')
                );
            }
        }
    }

    // Process and update profile_info
    if (!empty($media['profile_info'])) {
        $profile_info = wp_handle_upload($media['profile_info'], array('test_form' => false));

        if (!isset($profile_info['error'])) {
            $attachment = array(
                'post_mime_type' => $profile_info['type'],
                'post_title' => preg_replace('/\.[^.]+$/', '', basename($profile_info['file'])),
                'post_content' => '',
                'post_status' => 'inherit',
            );

            $attachment_id = wp_insert_attachment($attachment, $profile_info['file']);

            if (!is_wp_error($attachment_id)) {
                require_once(ABSPATH . 'wp-admin/includes/image.php');

                // Generate attachment metadata and update the attachment
                $attachment_data = wp_generate_attachment_metadata($attachment_id, $profile_info['file']);
                wp_update_attachment_metadata($attachment_id, $attachment_data);

                $profile_info_url = wp_get_attachment_url($attachment_id);

                $wpdb->update(
                    $table_name,
                    array('profile_info' => $profile_info_url),
                    array('id' => $id),
                    array('%s'),
                    array('%d')
                );
            }
        }
    }

    // Continue with updating or inserting data
    if (!empty($id)) {
        $wpdb->update(
            $table_name,
            array(
                'name_kh' => $name_kh,
                'name_en' => $name_en,
                'description' => $description,
                'dep_level' => $dep_level,
                'publish_on' => $publish_on,
                'showing_position' => $showing_position,
                'position_type' => $position_type,
                'author_eco_id' => $author_eco_id,
                'author_edu_id' => $author_edu_id,
                'author_info_id' => $author_info_id,
                'is_publish' => $is_publish
            ),
            array('id' => $id),
            array(
                '%s',
                '%s',
                '%s',
                '%s',
                '%s',
                '%s',
                '%s',
                '%s',
                '%s',
                '%s',
                '%s',
                '%s',
                '%s',
            ),
            array('%d')
        );

        return array(
            'status' => 'OK',
            'message' => 'Update data successfully',
        );
    } else {
        // Save new record if ID is not available
        $wpdb->insert(
            $table_name,
            array(
                'name_kh' => $name_kh,
                'name_en' => $name_en,
                'profile_eco' => isset($profile_eco_url) ? $profile_eco_url : '',
                'profile_edu' => isset($profile_edu_url) ? $profile_edu_url : '',
                'profile_info' => isset($profile_info_url) ? $profile_info_url : '',
                'description' => $description,
                'dep_level' => $dep_level,
                'publish_on' => $publish_on,
                'showing_position' => $showing_position,
                'position_type' => $position_type,
                'author_eco_id' => $author_eco_id,
                'author_edu_id' => $author_edu_id,
                'author_info_id' => $author_info_id,
                'is_publish' => $is_publish
            ),
            array(
                '%s',
                '%s',
                '%s',
                '%s',
                '%s',
                '%s',
                '%s',
                '%s',
                '%s',
                '%s',
                '%s',
                '%s',
                '%s',
            )
        );

        return array(
            'status' => 'OK',
            'message' => 'Save data successfully',
        );
    }
}


// START::GET AMS Team
function get_ams_teams(){
    global $wpdb;

    // Get the current page number from the request
    $page = isset($request['page']) ? intval($request['page']) : 1;

    // Set the number of records to display per page
    $recordsPerPage = 1000;

    // Calculate the offset for the database query
    $offset = ($page - 1) * $recordsPerPage;

    // Query the database to fetch the records for the current page
    $table = $wpdb->prefix . 'ams_authors';
    $results = $wpdb->get_results("SELECT * FROM $table LIMIT $offset, $recordsPerPage");

    // Fetch the total number of records in the table
    $totalRecords = $wpdb->get_var("SELECT COUNT(*) FROM $table");

    // Prepare the response data
    $response = array(
        "draw" => isset($request['draw']) ? intval($request['draw']) : 1,
        "recordsTotal" => intval($totalRecords),
        "recordsFiltered" => intval($totalRecords),
        "data" => $results,
    );

    return rest_ensure_response($response);
    
}




// END::GET AMS Team

function get_ams_info($request){
    global $wpdb;
    
    $table = $wpdb->prefix . 'ams_authors';
    
    $id = $request["id"] ? $request["id"] : null;
    
        $results = $wpdb->get_results("SELECT * FROM $table WHERE id = $id");
    
    // $arrayData = [];
    
    // foreach($results as $r){
    //     $arrayData[] = (object) [
    //       "id" => $r->id,
    //       "name_kh" => $r->name_kh,
    //       "name_en" => $r->name_en,
    //       "description" => $r->description,
		  //"dep_level" => $r->dep_level,
		  //"publish_on" => $r->publish_on,
		  //"roles" => $r->roles,
		  //"author_eco_id" => $r->author_eco_id,
		  //"author_edu_id" => $r->author_edu_id,
		  //"author_info_id" => $r->author_info_id,
		  //"is_publish" => $r->is_publish,
		  //"profile_eco" => $r->profile_eco,
		  //"profile_edu" => $r->profile_edu,
		  //"profile_info" => $r->profile_info,
    //     ];
    // }

    $response = new WP_REST_Response(['status' => 'OK', 'data' => $results]);
    $response->set_status(200);

    return $response;
    
}



function is_publish_author($request){
    global $wpdb;
    
    $table_name = $wpdb->prefix . 'ams_authors';
    
    $id = $request->get_param('id');
    $is_publish = $request->get_param('is_publish');
    
    $wpdb->update(
        $table_name,
        array(
            'is_publish' => $is_publish
        ),
        array('id' => $id),
        array(
            '%s',
        ),
        array('%d')
    );
    
    $response = new WP_REST_Response(['status' => 'OK', 'message' => 'Update data successfully']);
    $response->set_status(200);

    return $response;
}



function list_user_by_roles(){
    $roles = array( 'administrator' , 'contributor', 'editor', 'author', 'wpseo_editor', 'wpseo_manager', 'translator' );

    // Set up the query arguments
    $args = array(
        'role__in' => $roles,
        'number'   => -1, // Retrieve all users
    );
    
    $users = get_users( $args );

       $users_data = array();

    // Loop through the retrieved users
    foreach ( $users as $user ) {
        // Get the user's data
        $user_data = array(
            'id'           => $user->ID,
            'display_name' => $user->display_name
        );

        $users_data[] = $user_data;
    }
    
    $response = new WP_REST_Response(['status' => 'OK', 'data' => $users_data]);
    $response->set_status(200);

    return $response;
    
}



function get_author_list($request) {
    global $wpdb;

    $table_name = $wpdb->prefix . 'ams_authors';

    $publishOn = '%' . $wpdb->esc_like($request['publish_on']) . '%';
    $showingPosition = '%' . $wpdb->esc_like($request['showing_position']) . '%';
    $positionType = '%' . $wpdb->esc_like($request['position_type']) . '%';
    $orderby = $request['orderby'];
    $limit = $request['limit'];

    $query = $wpdb->prepare(
        "SELECT * FROM $table_name WHERE publish_on LIKE %s AND showing_position LIKE %s AND position_type LIKE %s AND is_publish = 1 ORDER BY $orderby limit $limit",
        $publishOn,
        $showingPosition,
        $positionType
    );

    $results = $wpdb->get_results($query);

    $response = new WP_REST_Response(['status' => 'OK', 'data' => $results]);
    $response->set_status(200);

    return $response;
}



function get_team_detail($request) {
    
    global $wpdb;

    $table_name = $wpdb->prefix . 'ams_authors';
    
    $id = $request->get_param('id');

    $query = $wpdb->prepare("SELECT id, name_kh, name_en, profile_eco, profile_edu, profile_info, description FROM $table_name WHERE id = $id");

    $results = $wpdb->get_results($query);

    $response = new WP_REST_Response(['status' => 'OK', 'data' => $results]);
    $response->set_status(200);

    return $response;
}















?>