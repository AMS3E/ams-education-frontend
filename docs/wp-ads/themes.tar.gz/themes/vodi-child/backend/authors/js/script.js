
jQuery(document).ready(function($){
    
    var table = $('#author_lists').DataTable({
        // processing: true,
        // serverSide: true,
        ajax: {
          url: 'https://economy.ams.com.kh/wp-json/api/v2/list-ams-teams',
          type: 'GET',
        },
        // Define your table columns and other options
        columns: [
              { 
                data: 'id',
                className: 'text-center'
              },
              { 
                  data: null,
                  render: function(data, type, row) {
                    if(row.profile_eco == null){
                        return '<img src="' + row.profile_eco + '" alt="'+ row.profile_eco +'" style="height:50px; border-radius:50px;width:50px;"></img>';
                    }else{
                        return '<img src="' + row.profile_edu + '" alt="'+ row.profile_edu +'" style="height:50px; border-radius:50px;width:50px;"></img>';                        
                    }

                  }
              },
              { 
                data: null,
                render: function(data, type, row) {
                    return row.name_kh + ' | ' + row.name_en;
                }
              },
              { data: 'publish_on',
                className: 'text-center'
              },
              { data: 'showing_position',
                className: 'text-center'
              },
              { data: 'position_type',
                className: 'text-center'
              },
              {
                    data: null,
                    className: 'text-center',
                    render: function(data, type, row) {
                        var checkbox = '<input type="checkbox" class="is_publish_toggle" id="is_publish_toggle" value="' + row.id + '"';
                        checkbox += row.is_publish == 1 ? ' checked' : '';
                        checkbox += ' data-toggle="toggle" data-onstyle="success" data-offstyle="danger" data-height="15">';
                        return checkbox;
                    }
              },
              {
                    data: null,
                    className: 'text-center',
                    render: function(data, type, row) {
                        return '<button class="bg-transparent border-0 btn-edit" id="'+row.id+'"><img src="https://economy.ams.com.kh/wp-content/uploads/2023/06/icons8-edit-32.png" style="height:25px;"></img></button>';
                    }
              }
            ],
            order: [
                [0, 'desc']
            ],
            drawCallback: function() {
                $('.is_publish_toggle').bootstrapToggle();
            },
    });
    
    
    
    $(document).on('click', '.btn-edit', function(){
        let id = $(this).attr('id');
        $.ajax({
            url: `https://economy.ams.com.kh/wp-json/api/v2/ams-teams-info?id=${id}`,
            method: 'GET',
            dataType: 'json',
            success: function(data) {
                let d = data.data;
                if (data.status == "OK") {
                    let value_publish_on = d[0].publish_on;
                    let value_author_eco = d[0].author_eco_id;
                    let value_author_edu = d[0].author_edu_id;
                    let value_author_info = d[0].author_info_id;
                    let value_showing_position = d[0].showing_position;
    
                    $("#modal_author").modal();
                    $("#titleModal").html("Edit Author");
                    $("#btnSubmit").html("Edit Author");
                    $("#id").val(d[0].id);
                    $("#name_kh").val(d[0].name_kh);
                    $("#name_en").val(d[0].name_en);
                    $("#dep_level").val(d[0].dep_level);
                    
                    $("#position_type").val(d[0].position_type);
                    $("#is_publish").val(d[0].is_publish);
                    $("#description").val(d[0].description);
    
                    $("#imagePreviewEco").empty().append("<img src='" + d[0].profile_eco + "' style='width: 150px;' />");
                    $("#imagePreviewEdu").empty().append("<img src='" + d[0].profile_edu + "' style='width: 150px;' />");
                    $("#imagePreviewInfo").empty().append("<img src='" + d[0].profile_info + "' style='width: 150px;' />");
    
                    let selectedValues = value_publish_on.split(',').map(function(value) {
                        return value.trim();
                    });
    
                    let selectedShowingPosition = value_showing_position.split(',').map(function(value) {
                        return value.trim();
                    });
    
                    $('#publish_on').val(selectedValues).trigger('change');
                    $('#author_eco_id').val(value_author_eco).trigger('change');
                    $('#author_edu_id').val(value_author_edu).trigger('change');
                    $('#author_info_id').val(value_author_info).trigger('change');
                    $('#showing_position').val(selectedShowingPosition).trigger('change');
                }
            },
            error: function(error) {
                console.error('Error:', error);
            }
        });
    });
    

    
    
          
    // Function to handle form submission
    function submitForm(event) {
      event.preventDefault(); // Prevent the form from submitting normally
    
      // Show loading spinner
      $('#loadingSpinner').css('display', 'block');
    
      // Get form element
      let form = $('#dataForm')[0];
    
      // Create FormData object to store form data
      let formData = new FormData(form);
    
      let publishOnValues = $('#publish_on').val();
      if (publishOnValues) {
        formData.append('publish_on[]', publishOnValues);
      }
      let showingPosition = $("#showing_position").val();
      if(showingPosition){
          formData.append('showing_position[]', showingPosition);
      }
      // Get file inputs
      let profileEcoFile = $('#prfofile_eco')[0].files[0];
      let profileEduFile = $('#prfofile_edu')[0].files[0];
      let profileInfoFile = $('#prfofile_info')[0].files[0];
    
      // Append files to FormData object
      if (profileEcoFile) {
        formData.append('profile_eco', profileEcoFile);
      }
      if (profileEduFile) {
        formData.append('profile_edu', profileEduFile);
      }
      if (profileInfoFile) {
        formData.append('profile_info', profileInfoFile);
      }
    
      $.ajax({
        url: 'https://economy.ams.com.kh/wp-json/api/v2/save-author',
        method: 'POST',
        data: formData,
        processData: false,
        contentType: false,
        success: function(response) {
          // Hide loading spinner
          $('#loadingSpinner').css('display', 'none');
          
          // Handle response
          if (response.status === "OK") {
            $('#author_lists').DataTable().ajax.reload();
            Swal.fire({
              position: 'top-end',
              icon: 'success',
              title: 'Author saved successfully.',
              showConfirmButton: false,
              timer: 1500
            })
            clearAuthorForm();
          } else {
            console.error('Form submission failed');
          }
        },
        error: function(error) {
          $('#loadingSpinner').css('display', 'none');
          console.error('Error:', error);
        }
      });
    }
    
    // Add event listener to the form's submit button
    $('#dataForm').find('button[type="submit"]').on('click', submitForm);
    
    
    function clearAuthorForm(){
        let form = $('#dataForm')[0];
        form.reset();
        $('#publish_on').val(null).trigger('change');
        $('#author_eco_id').val(null).trigger('change');
        $('#author_edu_id').val(null).trigger('change');
        $('#author_info_id').val(null).trigger('change');
        $('#showing_position').val(null).trigger('change');
        $("#imagePreviewEco").empty();
        $("#imagePreviewEdu").empty();
        $("#imagePreviewInfo").empty();
    }
    
    

    
    
    $("#btn-add-team").on("click", function(){
       clearAuthorForm()
       $("#modal_author").modal();
    });
    
    

    // START::Publish AMS Team
    $(document).on('change', '#is_publish_toggle', function() {
        let id = $(this).val();
      if ($(this).is(':checked')) {
            let data = {
              id: id,
              is_publish: 1
            };
            
            let url = 'https://economy.ams.com.kh/wp-json/api/v2/is-publish-author/';
            
            fetch(url, {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json'
              },
              body: JSON.stringify(data)
            })
              .then(response => response.json())
              .then(responseData => {
                console.log(responseData);
              })
              .catch(error => {
                console.error(error);
              });
      } else {
            let deactive_data = {
              id: id,
              is_publish: 0
            };
            
            let url = 'https://economy.ams.com.kh/wp-json/api/v2/is-publish-author/';
            
            fetch(url, {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json'
              },
              body: JSON.stringify(deactive_data)
            })
              .then(response => response.json())
              .then(responseData => {
                console.log(responseData);
              })
              .catch(error => {
                console.error(error);
              });
      }
    });
    // END::Publish AMS Team
    
    $('#author_eco_id').select2({
        dropdownParent: $('#modal_author'),
    });
    
    $('#author_edu_id').select2({
        dropdownParent: $('#modal_author'),
    });
    
    $('#author_info_id').select2({
        dropdownParent: $('#modal_author'),
    });
    
    // START::Load Select2 Author Economy
    function load_author_economy(){
         $.ajax({
            url: 'https://economy.ams.com.kh/wp-json/api/v2/list-user-by-roles',
            type: 'GET',
            dataType: 'json',
            success: function(data) {
              // Populate Select2 with options
              $.each(data.data, function(index, item) {
                var option = new Option(item.display_name, item.id);
                $('#author_eco_id').append(option);
              });
    
              // Trigger Select2 to update the UI
              $('#author_eco_id').trigger('change');
            },
            error: function(xhr, textStatus, errorThrown) {
              console.log('Error:', errorThrown);
            }
          });
    }
    
    load_author_economy();
    // END::Load Select2 Author Economy
    
    // START::Load Select2 Author Education
    function load_author_education(){
         $.ajax({
            url: 'https://education.ams.com.kh/wp-json/api/v2/list-user-by-roles',
            type: 'GET',
            dataType: 'json',
            success: function(data) {
              // Populate Select2 with options
              $.each(data.data, function(index, item) {
                var option = new Option(item.display_name, item.id);
                $('#author_edu_id').append(option);
              });
    
              // Trigger Select2 to update the UI
              $('#author_edu_id').trigger('change');
            },
            error: function(xhr, textStatus, errorThrown) {
              console.log('Error:', errorThrown);
            }
          });
    }
    
    load_author_education();
    // END::Load Select2 Author Education
    
    // START::Load Select2 Author Infotainment
    function load_author_infotainment(){
         $.ajax({
            url: 'https://infotainment.ams.com.kh/wp-json/api/v2/list-user-by-roles',
            type: 'GET',
            dataType: 'json',
            success: function(data) {
              // Populate Select2 with options
              $.each(data.data, function(index, item) {
                var option = new Option(item.display_name, item.id);
                $('#author_info_id').append(option);
              });
    
              // Trigger Select2 to update the UI
              $('#author_info_id').trigger('change');
            },
            error: function(xhr, textStatus, errorThrown) {
              console.log('Error:', errorThrown);
            }
          });
    }
    
    load_author_infotainment();
    // END::Load Select2 Author Infotainment
    
   
  
    
    $('#publish_on').select2({
        minimumResultsForSearch: -1 // Disable the search functionality
    });
      
    $('#showing_position').select2({
        minimumResultsForSearch: -1 // Disable the search functionality
    });
      
      

      
      
      

     // Get the input element and the preview element
    const prfofile_eco = document.getElementById('prfofile_eco');
    const imagePreviewEco = document.getElementById('imagePreviewEco');
    
    const prfofile_edu = document.getElementById('prfofile_edu');
    const imagePreviewEdu = document.getElementById('imagePreviewEdu');
    
    const prfofile_info = document.getElementById('prfofile_info');
    const imagePreviewInfo = document.getElementById('imagePreviewInfo');

    // Add an event listener to the input element ECONOMY
    prfofile_eco.addEventListener('change', function(e) {
      // Check if any file is selected
      if (e.target.files && e.target.files[0]) {
        // Create a new FileReader object
        const reader = new FileReader();
    
        // Set up the reader to load the image
        reader.onload = function(e) {
          // Create a new image element
          const img = document.createElement('img');
          img.src = e.target.result;
          
          // Set the width of the image to 150 pixels
          img.style.width = '150px';
    
          // Append the image to the preview element
          imagePreviewEco.innerHTML = '';
          imagePreviewEco.appendChild(img);
        };
    
        // Read the image file as a data URL
        reader.readAsDataURL(e.target.files[0]);
      }
    });
    
    // Add an event listener to the input element EDUCATION
    prfofile_edu.addEventListener('change', function(e) {
      // Check if any file is selected
      if (e.target.files && e.target.files[0]) {
        // Create a new FileReader object
        const reader = new FileReader();
    
        // Set up the reader to load the image
        reader.onload = function(e) {
          // Create a new image element
          const img = document.createElement('img');
          img.src = e.target.result;
          
          // Set the width of the image to 150 pixels
          img.style.width = '150px';
    
          // Append the image to the preview element
          imagePreviewEdu.innerHTML = '';
          imagePreviewEdu.appendChild(img);
        };
    
        // Read the image file as a data URL
        reader.readAsDataURL(e.target.files[0]);
      }
    });
    
    // Add an event listener to the input element INFOTAINMENT
    prfofile_info.addEventListener('change', function(e) {
      // Check if any file is selected
      if (e.target.files && e.target.files[0]) {
        // Create a new FileReader object
        const reader = new FileReader();
    
        // Set up the reader to load the image
        reader.onload = function(e) {
          // Create a new image element
          const img = document.createElement('img');
          img.src = e.target.result;
          
          // Set the width of the image to 150 pixels
          img.style.width = '150px';
    
          // Append the image to the preview element
          imagePreviewInfo.innerHTML = '';
          imagePreviewInfo.appendChild(img);
        };
    
        // Read the image file as a data URL
        reader.readAsDataURL(e.target.files[0]);
      }
    });
    

  
    

});