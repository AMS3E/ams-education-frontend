<?php
// Api Funtion
function readapi($q, $page, $limit, $tab, $site_slug)
{

    // sanitize inputs
    $q         = urlencode(sanitize_text_field($q));
    $page      = intval($page);
    $limit     = intval($limit);
    $tab       = sanitize_text_field($tab);
    $site_slug = sanitize_text_field($site_slug);

    // build URL safely
    if ($tab === "images") {
        $url = "https://search.ams.com.kh/api/search?limit=20&q={$q}&site_slug={$site_slug}&page={$page}";
    } else {
        $url = "https://searchapi.amscloud.cc/search?q={$q}&page={$page}&limit={$limit}&tab={$tab}&site_slug={$site_slug}";
    }

    // request with timeout
    $response = wp_remote_get($url, array(
        'timeout' => 15,
        'headers' => array(
            'Accept' => 'application/json'
        )
    ));

    // check error
    if (is_wp_error($response)) {
        return array(
            'error' => true,
            'message' => $response->get_error_message()
        );
    }

    // get body
    $body = wp_remote_retrieve_body($response);

    if (!$body) {
        return array(
            'error' => true,
            'message' => 'Empty response'
        );
    }

    // decode JSON
    $data = json_decode($body, true);

    if (json_last_error() !== JSON_ERROR_NONE) {
        return array(
            'error' => true,
            'message' => 'Invalid JSON'
        );
    }

    return $data;
}

// Corver date to khmer date 
function khmer_date($datetime_string)
{
    // Khmer months
    $khmer_months = [1 => 'មករា', 2 => 'កុម្ភៈ',   3 => 'មីនា',  4 => 'មេសា',  5 => 'ឧសភា', 6 => 'មិថុនា', 7 => 'កក្កដា', 8 => 'សីហា', 9 => 'កញ្ញា', 10 => 'តុលា', 11 => 'វិច្ឆិកា', 12 => 'ធ្នូ'];
    // Convert Arabic numbers to Khmer
    $khmer_number = function ($number) {
        $khmer_digits = ['0' => '០', '1' => '១', '2' => '២', '3' => '៣', '4' => '៤', '5' => '៥', '6' => '៦', '7' => '៧', '8' => '៨', '9' => '៩'];
        return strtr($number, $khmer_digits);
    };

    // Create DateTime object
    $date = new DateTime($datetime_string);

    // Format day, month, year
    $day = $khmer_number($date->format('d'));
    $month = $khmer_months[intval($date->format('m'))];
    $year = $khmer_number($date->format('Y'));

    // Return Khmer date
    return "$day $month $year";
}


function ams_build_search_page_url($q, $tab, $site_slug, $limit, $page, $site_filter_applied = false)
{
    $args = [
        'q' => $q,
        'tab' => $tab ?: 'all',
        'page' => max(1, (int) $page),
        'limit' => max(1, (int) $limit),
        'site_slug' => $site_slug,
    ];

    if ($site_filter_applied) {
        $args['site_filter_applied'] = '1';
    }

    return add_query_arg($args, site_url('/searchs'));
}

function ams_get_pagination_window($current_page, $total_pages)
{
    $start = max(2, $current_page - 2);
    $end = min($total_pages - 1, $current_page + 2);

    if ($current_page <= 3) {
        $end = min($total_pages - 1, 5);
    }

    if ($current_page >= $total_pages - 2) {
        $start = max(2, $total_pages - 4);
    }

    return [$start, $end];
}

//page nation 
function build_pagination($current_page, $total_pages, $q, $tab = 'all', $site_slug = '', $limit = 10, $site_filter_applied = false)
{
    $current_page = max(1, (int) $current_page);
    $total_pages = max(1, (int) $total_pages);
    $current_page = min($current_page, $total_pages);
    $pages = [];

    // Previous page
    if ($current_page > 1) {
        $pages[] = [
            'label' => 'មុន',
            'page' => $current_page - 1,
            'url' => ams_build_search_page_url($q, $tab, $site_slug, $limit, $current_page - 1, $site_filter_applied)
        ];
    }

    // First page
    $pages[] = [
        'label' => 1,
        'page' => 1,
        'url' => ams_build_search_page_url($q, $tab, $site_slug, $limit, 1, $site_filter_applied)
    ];

    [$start, $end] = ams_get_pagination_window($current_page, $total_pages);

    // Ellipsis if needed
    if ($start > 2) {
        $pages[] = ['label' => '...'];
    }

    // Pages around current page
    for ($i = $start; $i <= $end; $i++) {
        $pages[] = [
            'label' => $i,
            'page' => $i,
            'url' => ams_build_search_page_url($q, $tab, $site_slug, $limit, $i, $site_filter_applied)
        ];
    }

    // Ellipsis at end
    if ($end < $total_pages - 1) {
        $pages[] = ['label' => '...'];
    }

    // Last page
    if ($total_pages > 1) {
        $pages[] = [
            'label' => $total_pages,
            'page' => $total_pages,
            'url' => ams_build_search_page_url($q, $tab, $site_slug, $limit, $total_pages, $site_filter_applied)
        ];
    }

    // Next page
    if ($current_page < $total_pages) {
        $pages[] = [
            'label' => 'បន្ទាប់',
            'page' => $current_page + 1,
            'url' => ams_build_search_page_url($q, $tab, $site_slug, $limit, $current_page + 1, $site_filter_applied)
        ];
    }

    return $pages;
}

function build_search_pagination($current_page, $total_pages, $q, $tab = 'all', $site_slug = '', $limit = 10, $site_filter_applied = false)
{
    $current_page = max(1, (int) $current_page);
    $total_pages = max(1, (int) $total_pages);
    $current_page = min($current_page, $total_pages);
    $pages = [];

    if ($total_pages <= 1) {
        return [[
            'label' => 1,
            'page' => 1,
            'type' => 'page',
            'url' => ams_build_search_page_url($q, $tab, $site_slug, $limit, 1, $site_filter_applied)
        ]];
    }

    $pages[] = [
        'label' => '&#124;&lsaquo;',
        'page' => 1,
        'type' => 'first',
        'disabled' => $current_page <= 1,
        'url' => $current_page > 1 ? ams_build_search_page_url($q, $tab, $site_slug, $limit, 1, $site_filter_applied) : ''
    ];
    $pages[] = [
        'label' => '&lsaquo;',
        'page' => max(1, $current_page - 1),
        'type' => 'prev',
        'disabled' => $current_page <= 1,
        'url' => $current_page > 1 ? ams_build_search_page_url($q, $tab, $site_slug, $limit, $current_page - 1, $site_filter_applied) : ''
    ];

    if ($current_page > 1) {
        $pages[] = [
            'label' => 1,
            'page' => 1,
            'type' => 'page',
            'url' => ams_build_search_page_url($q, $tab, $site_slug, $limit, 1, $site_filter_applied)
        ];
    }
    else {
        $pages[] = [
            'label' => 1,
            'page' => 1,
            'type' => 'page',
            'url' => ams_build_search_page_url($q, $tab, $site_slug, $limit, 1, $site_filter_applied)
        ];
    }

    [$start, $end] = ams_get_pagination_window($current_page, $total_pages);

    if ($start > 2) {
        $pages[] = [
            'label' => '...',
            'type' => 'ellipsis'
        ];
    }

    for ($i = $start; $i <= $end; $i++) {
        $pages[] = [
            'label' => $i,
            'page' => $i,
            'type' => 'page',
            'url' => ams_build_search_page_url($q, $tab, $site_slug, $limit, $i, $site_filter_applied)
        ];
    }

    if ($end < $total_pages - 1) {
        $pages[] = [
            'label' => '...',
            'type' => 'ellipsis'
        ];
    }

    $pages[] = [
        'label' => $total_pages,
        'page' => $total_pages,
        'type' => 'page',
        'url' => ams_build_search_page_url($q, $tab, $site_slug, $limit, $total_pages, $site_filter_applied)
    ];

    $pages[] = [
        'label' => '&rsaquo;',
        'page' => min($total_pages, $current_page + 1),
        'type' => 'next',
        'disabled' => $current_page >= $total_pages,
        'url' => $current_page < $total_pages ? ams_build_search_page_url($q, $tab, $site_slug, $limit, $current_page + 1, $site_filter_applied) : ''
    ];
    $pages[] = [
        'label' => '&rsaquo;&#124;',
        'page' => $total_pages,
        'type' => 'last',
        'disabled' => $current_page >= $total_pages,
        'url' => $current_page < $total_pages ? ams_build_search_page_url($q, $tab, $site_slug, $limit, $total_pages, $site_filter_applied) : ''
    ];

    return $pages;
}

//khmer duration
if (!function_exists('khmer_duration')) {
    function khmer_duration($duration)
    {
        if (empty($duration)) return '—';

        $duration = trim($duration);
        $duration = preg_replace('/\bdelete\b/i', '', $duration);
        $duration = trim($duration);

        // If seconds number
        if (is_numeric($duration)) {
            $seconds = (int)$duration;
            $h = floor($seconds / 3600);
            $m = floor(($seconds % 3600) / 60);
            $s = $seconds % 60;
        } else {
            $parts = explode(':', $duration);

            if (count($parts) === 3) {
                list($h, $m, $s) = $parts;
            } elseif (count($parts) === 2) {
                $h = 0;
                list($m, $s) = $parts;
            } else {
                return esc_html($duration);
            }
        }

        $h = str_pad((int)$h, 2, '0', STR_PAD_LEFT);
        $m = str_pad((int)$m, 2, '0', STR_PAD_LEFT);
        $s = str_pad((int)$s, 2, '0', STR_PAD_LEFT);

        $map = [
            '0'=>'០','1'=>'១','2'=>'២','3'=>'៣','4'=>'៤',
            '5'=>'៥','6'=>'៦','7'=>'៧','8'=>'៨','9'=>'៩'
        ];

        $h = strtr($h, $map);
        $m = strtr($m, $map);
        $s = strtr($s, $map);

        return "{$h}ម៉ោង: {$m}នាទី: {$s}វិនាទី";
    }
}



if (!function_exists('ams_get_sites_api')) {
function ams_get_sites_api() {
    $apiurl = 'https://searchapi.amscloud.cc/sites';

    $response = wp_remote_get($apiurl, [
        'timeout' => 15,
        'headers' => [
            'Accept' => 'application/json',
        ],
    ]);

    // Check WP error
    if (is_wp_error($response)) {
        return false;
    }

    // Check HTTP status
    $status = wp_remote_retrieve_response_code($response);
    if ($status !== 200) {
        return false;
    }

    // Get response body
    $body = wp_remote_retrieve_body($response);
    if (empty($body)) {
        return false;
    }

    // Decode JSON
    $data = json_decode($body, true);
    if (json_last_error() !== JSON_ERROR_NONE) {
        return false;
    }

    return $data;
}
}
 // GET KHMER SLUGS
if (!function_exists('get_khmer_slugs')) {
function get_khmer_slugs($slug)
{
    $label_kh = [
        'central'  => 'សង់ត្រាល',
        'chivilize' => 'អរិយធម៌',
        'economy'  => 'សេដ្ឋកិច្ច',
        'education' => 'អប់រំ',
        'infotainment'  => 'ព័ត៌មានកម្សាន្ត',
        'radio'  => 'វិទ្យុអប្សរា',
        'sport'  => 'កីឡា',
    ];
    return $label_kh[$slug];
}
}
