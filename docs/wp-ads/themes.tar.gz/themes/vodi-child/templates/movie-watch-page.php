<?php
/**
 * Shared watch page (video player + season dropdown + episode sidebar),
 * forced via the template_include filter in functions/khmer-insider-watch.php
 * for every 'movie' and 'tv_show' post sitewide, replacing MasVideos' own
 * single templates for both CPTs. Originally built for Khmer Insider
 * (post_name: khmer-insider, ID 2930) from the Figma export at
 * D:\video page\index.html; now shared by every show with the same
 * "hub page pulls episodes from a tv_show post" structure, plus every
 * standalone movie (see the branch below).
 *
 * Local variables here are deliberately prefixed khi_* (not $tv_show/$movie)
 * because MasVideos itself relies on `global $tv_show` in many of its own
 * template functions (masvideos-tv-show-template-functions.php etc.) - a
 * plain $tv_show here gets silently clobbered by get_header()'s hooks.
 *
 * Content model, same as pages/template-unlock-the-life.php:
 * - episode CPT (MasVideos), filtered by post meta:
 *     _tv_show_id         -> the tv_show post's ID
 *     _tv_show_season_id  -> season index, 0-based (season 1 = 0)
 *     _episode_number     -> display/sort number
 *     _episode_choice     -> 'episode_url' | 'episode_embed' | 'episode_file'
 *     _episode_url_link   -> Vimeo/YouTube URL when choice = episode_url
 *     _episode_run_time   -> display duration text, e.g. "8:36 នាទី"
 * - current episode selected via ?season=&ep= query args, defaulting to
 *   the latest episode.
 * - a 'movie' post with no '_khi_tv_show_id' link has no season/episode
 *   structure at all - it plays its own video straight from MasVideos'
 *   '_movie_choice'/'_movie_url_link' meta instead (see the standalone
 *   branch below and khi_render_video_block()'s $is_movie handling).
 *
 * Show-based pages (khi_show_id truthy) render an empty shell here rather
 * than calling khi_resolve_watch_state() - that runs a custom SQL query plus
 * two get_posts() calls, so it's deferred to the khi_rest_get_episode REST
 * endpoint, fetched by khmer-insider-watch.js right after page load (same
 * endpoint/JS path already used for season/episode switching - see
 * loadState()'s initial call there). Standalone movies below skip the round
 * trip entirely since they have nothing to fetch - get_queried_object() is
 * already free.
 */

$khi_show_id = khi_show_id_for_queried_object();
$khi_show    = $khi_show_id ? get_post( $khi_show_id ) : null;

$default_asset_uri = get_stylesheet_directory_uri() . '/assets/unlock-the-life';

$requested_season = isset( $_GET['season'] ) ? absint( $_GET['season'] ) : null;

if ( $khi_show_id ) {
	$seasons            = array();
	$current_episode    = null;
	$current_season     = $requested_season ?: 0;
	$episodes_in_season = array();
} else {
	// Standalone 'movie' post (no linked tv_show) - it supplies its own
	// video/description directly, so there's no season/episode sidebar.
	$seasons            = array();
	$current_episode    = get_queried_object();
	$current_season     = 0;
	$episodes_in_season = array();
}
get_header();
?>

<div class="khmer-insider-watch-page">

	<main class="container">

		<div class="content-row">

			<div class="main-column">

				<section class="video-block">

					<div id="khiVideoBlock"<?php echo $khi_show_id ? ' class="is-loading"' : ''; ?>><?php echo $khi_show_id ? khi_render_video_block_loading() : khi_render_video_block( $current_episode ); ?></div>

				</section>

				<section class="lower-content">

					<div class="description-box" id="khiDescriptionBox"><?php echo khi_render_description( $current_episode ); ?></div>

					<?php if ( $khi_show ) : ?>
						<div class="about-box">
							<div class="about-inner">
								<?php
								$about_thumb = get_the_post_thumbnail_url( get_queried_object_id(), 'large' );
								if ( ! $about_thumb ) {
									$about_thumb = get_the_post_thumbnail_url( $khi_show, 'large' );
								}
								?>
								<img class="about-thumb" src="<?php echo esc_url( $about_thumb ? $about_thumb : $default_asset_uri . '/about-thumbnail.png' ); ?>" alt="<?php echo esc_attr( $khi_show->post_title ); ?>" />
								<div class="about-head">
									<h2 class="box-title">អំពី <?php echo esc_html( $khi_show->post_title ); ?></h2>
									<?php $khi_schedule = khi_show_schedule_text( get_queried_object_id() ); ?>
									<?php if ( $khi_schedule ) : ?>
										<p class="about-schedule"><?php echo esc_html( $khi_schedule ); ?></p>
									<?php endif; ?>
								</div>
								<p class="about-text"><?php echo esc_html( khi_synopsis_text( $khi_show->ID ) ); ?></p>
							</div>
						</div>
					<?php endif; ?>

				</section>

			</div>

			<?php if ( $khi_show_id ) : ?>
			<aside class="sidebar">
				<div class="season-select">
					<button class="season-select-btn" id="seasonSelectBtn">
						<span id="seasonSelectLabel"><?php echo $khi_show_id ? esc_html__( 'កំពុងផ្ទុក...', 'vodi-child' ) : esc_html( khi_season_label( $current_season ) ); ?></span>
						<img class="chevron" src="<?php echo esc_url( $default_asset_uri . '/icon-chevron.svg' ); ?>" alt="" />
					</button>
					<ul class="season-dropdown" id="seasonDropdown"><?php echo khi_render_season_dropdown( $seasons, $current_season ); ?></ul>
				</div>

				<div class="episode-panel">
					<div class="episode-panel-head">
						<h2 class="show-title"><?php echo $khi_show ? esc_html( $khi_show->post_title ) : ''; ?></h2>
						<button class="episode-panel-toggle" id="episodePanelToggle" type="button" aria-expanded="true" aria-label="បង្ហាញតិច">
							<img class="chevron" src="<?php echo esc_url( $default_asset_uri . '/icon-chevron.svg' ); ?>" alt="" />
						</button>
					</div>

					<ul class="episode-list" id="episodeList"><?php
						if ( $khi_show_id ) {
							echo '<li class="episode-loading">' . esc_html__( 'កំពុងផ្ទុក...', 'vodi-child' ) . '</li>';
						} else {
							echo khi_render_episode_list( $episodes_in_season, $current_episode, $current_season, $default_asset_uri );
						}
					?></ul>
				</div>
			</aside>
			<?php endif; ?>

		</div>
	</main>

	<!-- Ad banner -->
	<div class="ads-banner">
		<?php
		$ads_output = ( $khi_show_id && shortcode_exists( 'ads-layout-five-fullwidth' ) )
			? do_shortcode( '[ads-layout-five-fullwidth layout_id="5" position_id="1" tvshow_id="' . absint( $khi_show_id ) . '" ads_size="1"]' )
			: '';
		if ( '' === trim( $ads_output ) ) :
			?>
			<?php echo khi_watch_ads_banner_fallback(); ?>
		<?php else : ?>
			<?php echo $ads_output; ?>
		<?php endif; ?>
	</div>

</div>

<?php get_footer(); ?>
